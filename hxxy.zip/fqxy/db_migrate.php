<?php
// 数据库全量迁移入口。必须使用 config/app.php 中的 gm_secret 作为 key。
require_once __DIR__ . '/../tools/migrate_ini_to_db.php';
