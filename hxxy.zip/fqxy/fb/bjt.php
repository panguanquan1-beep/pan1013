<?php
/**
 * 冰晶塔·塔阶入口功能行（按参考服录屏）
 * [国家挑战副本]
 * ❗激活【冰晶塔】副本（每日）
 * 【如意传送门】
 * 方丈的灵魂（兑换）
 */
require_once __DIR__ . '/../../lib/IceTower.php';
require_once __DIR__ . '/../../lib/RefImg.php';

echo '<font color=#8B0000>[国家挑战副本]</font><br/>';

$bang = RefImg::th();
if ($bang === '') $bang = '<font color=red>！</font>';

$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 768;
$npc[] = 0;
echo $bang . "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>激活【冰晶塔】副本（每日）</font></a><br/>";

$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 770;
$npc[] = 0;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=red>【如意传送门】</font></a><br/>";

$cmid = $cmid + 1;
$cdid[] = $cmid;
$clj[] = 771;
$npc[] = 0;
echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>方丈的灵魂（兑换）</font></a><br/>";
