<?php
// 通天水府 普通 / 困难 双档激活入口
$fb = 'ttsf';
$fbid1 = 49;
$fbid2 = 50;
$fbid3 = 51;
$fbid4 = 52;
include('./ini/fb_ini.php');
$__tiers = array(
    array('fbid' => 49, 'label' => '普通', 'status' => 37, 'done' => 38),
    array('fbid' => 50, 'label' => '困难', 'status' => 39, 'done' => 40),
);
$__today = date('Y-m-d');
foreach ($__tiers as $__t) {
    $__fb = $__t['fbid'];
    $__gwbl = $iniFile->getCategory($__fb);
    $__done = ($__gwbl['怪物1'] == 2 && $__gwbl['怪物2'] == 2 && $__gwbl['怪物3'] == 2 && $__gwbl['怪物4'] == 2) || $__gwbl['完成情况'] == 3;
    $__code = $__t['status'];
    if ($__done) {
        if ($__gwbl['完成情况'] == 1) {
            $cmid = $cmid + 1; $cdid[] = $cmid; $clj[] = 87; $npc[] = $__fb;
            echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>领取通天水府副本【" . $__t['label'] . "】奖励</font></a><br>";
            continue;
        }
        $__tm = substr((string)$__gwbl['激活时间'], 0, 10);
        if ($__tm != $__today && $__tm != '') {
            $cmid = $cmid + 1; $cdid[] = $cmid; $clj[] = 85; $npc[] = $__fb;
        } else {
            $__code = $__t['done'];
            $cmid = $cmid + 1; $cdid[] = $cmid; $clj[] = 88; $npc[] = $__code;
        }
    } else {
        if ($__gwbl['完成情况'] == 1) {
            $cmid = $cmid + 1; $cdid[] = $cmid; $clj[] = 88; $npc[] = $__code;
        } else {
            $cmid = $cmid + 1; $cdid[] = $cmid; $clj[] = 85; $npc[] = $__fb;
        }
    }
    echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>激活通天水府副本【" . $__t['label'] . "】</font></a><br>";
}
?>
