<?php
// 通天水府 金鳞大王（过道）
$fb = 'ttsf';
$fbid1 = 49; $fbid2 = 50; $fbid3 = 51; $fbid4 = 52;
include('./ini/fb_ini.php');
$__today = date('Y-m-d');
$__tiers = array(
    array('fbid' => $fbid1, 'npc' => 968, 'label' => '【金鳞大王】(普通)'),
    array('fbid' => $fbid2, 'npc' => 969, 'label' => '【金鳞大王】(困难)'),
    array('fbid' => $fbid3, 'npc' => 970, 'label' => '【金鳞大王】(梦魇)'),
    array('fbid' => $fbid4, 'npc' => 971, 'label' => '【金鳞大王】(地狱)'),
);
foreach ($__tiers as $__t) {
    $__gw = $iniFile->getItem($__t['fbid'], '怪物4');
    $__wc = $iniFile->getItem($__t['fbid'], '完成情况');
    $__tm = $iniFile->getItem($__t['fbid'], '激活时间');
    if ($__wc == 1 && $__gw == 1 && substr((string)$__tm, 0, 10) === $__today) {
        $cmid = $cmid + 1;
        $cdid[] = $cmid;
        $clj[] = 10;
        $npc[] = $__t['npc'];
        echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>" . $__t['label'] . "</font></a>" . "<br>";
    }
}
?>
