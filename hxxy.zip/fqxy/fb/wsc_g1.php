<?php
// 枉死城 鬼面判官（轻生狱）
$fb = 'wsc';
$fbid1 = 25; $fbid2 = 26; $fbid3 = 27; $fbid4 = 39;
include('./ini/fb_ini.php');
$__today = date('Y-m-d');
$__tiers = array(
    array('fbid' => $fbid1, 'npc' => 594, 'label' => '【鬼面判官】(普通)'),
    array('fbid' => $fbid2, 'npc' => 597, 'label' => '【鬼面判官】(困难)'),
    array('fbid' => $fbid3, 'npc' => 600, 'label' => '【鬼面判官】(梦魇)'),
    array('fbid' => $fbid4, 'npc' => 686, 'label' => '【鬼面判官】(地狱)'),
);
foreach ($__tiers as $__t) {
    $__gw = $iniFile->getItem($__t['fbid'], '怪物1');
    $__wc = $iniFile->getItem($__t['fbid'], '完成情况');
    $__tm = $iniFile->getItem($__t['fbid'], '激活时间');
    if ($__wc == 1 && $__gw == 1 && substr((string)$__tm, 0, 10) === $__today) {
        $cmid = $cmid + 1;
        $cdid[] = $cmid;
        $clj[] = 10;
        $npc[] = $__t['npc'];
        echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>" . $__t['label'] . "</font></a>" . "<br>";
    }
}
?>
