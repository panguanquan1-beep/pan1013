<?php
// 枉死城 夜叉王（怨崖）
$fb = 'wsc';
$fbid1 = 25; $fbid2 = 26; $fbid3 = 27; $fbid4 = 39;
include('./ini/fb_ini.php');
$__today = date('Y-m-d');
$__tiers = array(
    array('fbid' => $fbid1, 'npc' => 596, 'label' => '【夜叉王】(普通)'),
    array('fbid' => $fbid2, 'npc' => 599, 'label' => '【夜叉王】(困难)'),
    array('fbid' => $fbid3, 'npc' => 602, 'label' => '【夜叉王】(梦魇)'),
    array('fbid' => $fbid4, 'npc' => 688, 'label' => '【夜叉王】(地狱)'),
);
foreach ($__tiers as $__t) {
    $__gw = $iniFile->getItem($__t['fbid'], '怪物3');
    $__wc = $iniFile->getItem($__t['fbid'], '完成情况');
    $__tm = $iniFile->getItem($__t['fbid'], '激活时间');
    if ($__wc == 1 && $__gw == 1 && substr((string)$__tm, 0, 10) === $__today) {
        $cmid = $cmid + 1;
        $cdid[] = $cmid;
        $clj[] = 10;
        $npc[] = $__t['npc'];
        echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>" . $__t['label'] . "</font></a>" . "<br>";
    }
}
?>
