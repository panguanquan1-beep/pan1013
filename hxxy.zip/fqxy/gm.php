<?php
header("Content-type: text/html; charset=utf-8");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" /> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>小轩GM管理平台</title>
<style> 
#search{ width:235px; height:32px; border-radius:10px; margin-top:5px; margin-bottom:5px; border:1px solid#ccc; background-color:transparent; transition:border-color ease-in-out .15s,box-shadow ease-in-out .15s; }
#search1{ width:82px; height:38px; background:#0086DB; border:0; border-radius:10px; margin-top:5px; color:white; font-size:16px; cursor:pointer; }
input:focus{ border-color:#66AFE9!important; outline:0; box-shadow:inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgba(102,175,233,0.6); }
::-webkit-input-placeholder{ text-indent:20px; font-size:16px; }
::-moz-input-placeholder{ text-indent:20px; font-size:16px; }
</style>
</head>
<body>
<div style='width: device-width;display:block;word-break: break-all;word-wrap: break-word;'>

<?php
ini_set("error_reporting","E_ALL & ~E_NOTICE");//防止报错代码
ini_set("date.timezone","PRC");//时间效准代码

// 安全接收所有 GET 参数，防止报错
$wjiddd = isset($_GET['wjid']) ? $_GET['wjid'] : '';
$password = isset($_GET['pass']) ? $_GET['pass'] : '';
$gid = isset($_GET['gid']) ? $_GET['gid'] : '';
$wjid = isset($_GET['user']) ? $_GET['user'] : '';
$wpid = isset($_GET['wpid']) ? $_GET['wpid'] : '';
$wpsl = isset($_GET['wpsl']) ? $_GET['wpsl'] : '';
$wpmz = isset($_GET['wpmz']) ? $_GET['wpmz'] : '';
$wpfl = isset($_GET['wpfl']) ? $_GET['wpfl'] : '';
$wjname = isset($_GET['wjname']) ? $_GET['wjname'] : '';
$hbid = isset($_GET['hbid']) ? $_GET['hbid'] : '';

// 【核心修改】放弃读取 ini 文件，直接判断 URL 中是否携带了密码
require_once __DIR__ . "/../class/gm_auth.php";
$gmAuthId = gm_check();
if ($gmAuthId) { // 服务器端校验 GM 身份
    if (!defined('XY_GM_ROUTER_AUTH')) define('XY_GM_ROUTER_AUTH', true);
    include_once("./class/iniclass.php"); // 加载 ini 操作类，修复找不到类的报错
    
    echo "<h3>当前GM页面ID：".$gid."</h3>";
    
    // 根据 gid 引入对应的 admin 文件
    if ($gid == 1) {
        include("admin/gm01.php");
    } elseif ($gid == 2) {   
        include("admin/gm02.php");
    } elseif ($gid == 3) {   
        include("admin/gm03.php");
    } elseif ($gid == 4) {   
        include("admin/gm04.php");
    } elseif ($gid == 5) {   
        include("admin/gm05.php");
    } elseif ($gid == 6) {   
        include("admin/gm06.php");
    } elseif ($gid == 7) {   
        include("admin/gm07.php");
    } elseif ($gid == 8) {   
        include("admin/gm08.php");
    } elseif ($gid == 9) {   
        include("admin/gm09.php");
    } elseif ($gid == 10) {   
        include("admin/gm10.php");
    } elseif ($gid == 11) {   
        include("admin/gm11.php");
    } elseif ($gid == 12) {   
        include("admin/gm12.php");
    } elseif ($gid == 13) {   
        include("admin/gm13.php");
    } elseif ($gid == 14) {   
        include("admin/gm14.php");
    } elseif ($gid == 15) {   
        include("admin/gm15.php");
    } elseif ($gid == 16) {   
        include("admin/gm16.php");
    } elseif ($gid == 17) {   
        include("admin/gm17.php");
    } elseif ($gid == 18) {   
        include("admin/gm18.php");
    } elseif ($gid == 19) {   
        include("admin/gm19.php");
    } elseif ($gid == 20) {   
        include("admin/gm20.php");
    } elseif ($gid == 21) {   
        include("admin/gm21.php");
    } elseif ($gid == 22) {   
        include("admin/gm22.php");
    } elseif ($gid == 23) {   
        include("admin/gm23.php");
    } elseif ($gid == 24) {   
        include("admin/gm24.php");
    } elseif ($gid == 26) {   
        include("admin/gm26.php");
    } elseif ($gid == 27) {   
        include("admin/gm27.php");
    } elseif ($gid == 28) {   
        include("admin/gm28.php");
    } elseif ($gid == 29) {   
        include("admin/gm29.php");
    } elseif ($gid == 30) {   
        include("admin/gm30.php");
    } elseif ($gid == 31) {   
        include("admin/gm31.php");
    } elseif ($gid == 32) {   
        include("admin/gm32.php");
    } elseif ($gid == 33) {   
        include("admin/gm33.php");
    } elseif ($gid == 34) {   
        include("admin/gm34.php");
    } elseif ($gid == 35) {   
        include("admin/gm35.php");
    } elseif ($gid == 36) {   
        include("admin/gm36.php");
    } elseif ($gid == 37) {   
        include("admin/gm37.php");
    } elseif ($gid == 38) {   
        include("admin/gm38.php");
    } elseif ($gid == 39) {   
        include("admin/gm39.php");
    } elseif ($gid == 40) {   
        include("admin/gm40.php");
    } elseif ($gid == 41) {   
        include("admin/gm41.php");
    } elseif ($gid == 42) {   
        include("admin/gm42.php");
    } elseif ($gid == 43) {   
        include("admin/gm43.php");
    } elseif ($gid == 44) {   
        include("admin/gm44.php");
    } elseif ($gid == 45) {   
        include("admin/gm45.php");
    } elseif ($gid == 46) {   
        include("admin/gm46.php");
    } elseif ($gid == 47) {   
        include("admin/gm47.php");
    } elseif ($gid == 48) {   
        include("admin/gm48.php");
    } elseif ($gid == 49) {   
        include("admin/gm49.php");
    } elseif ($gid == 50) {   
        include("admin/gm50.php");
    } elseif ($gid == 51) {   
        include("admin/gm51.php");
    } elseif ($gid == 52) {   
        include("admin/gm52.php");
    } elseif ($gid == 53) {   
        include("admin/gm53.php");
    } elseif ($gid == 54) {   
        include("admin/gm54.php");
    } elseif ($gid == 55) {   
        include("admin/gm55.php");
    } elseif ($gid == 56) {   
        include("admin/gm56.php");
    } elseif ($gid == 57) {   
        include("admin/gm57.php");
    } elseif ($gid == 58) {   
        include("admin/gm58.php");
    } elseif ($gid == 59) {   
        include("admin/gm59.php");
    } elseif ($gid == 60) {   
        include("admin/gm60.php");
    } elseif ($gid == 61) {   
        include("admin/gm61.php");
    } elseif ($gid == 62) {   
        include("admin/gm62.php");
    } elseif ($gid == 63) {   
        include("admin/gm63.php");
    } elseif ($gid == 64) {   
        include("admin/gm64.php");
    } else {
        // 如果没有传 gid，默认显示主页
        if($gid == ""){
            include("admin/gm01.php");
        }
    } 

} else {
    // 验证失效
    echo "<font color=red>当前验证信息失效,请重新登录</font><br>";
    echo "<a href='../admin/login.php'><font color=blue>返回GM登录</font></a><br>";
}
?>
</div>
</body>
</html>