《西游踏凌霄》独立 GM 管理系统
版本：1.0
适用：PHP 5.6+、MySQL 5.6+、KSWEB
安装目录：htdocs/fqxy/gm_admin/
访问地址：http://你的域名或IP/fqxy/gm_admin/

一、安装
1. 将压缩包内 fqxy/gm_admin/ 整个目录，按原目录结构复制到服务器：
   htdocs/fqxy/gm_admin/
2. 确认原项目的 htdocs/config/app.php 存在，并且其中 hxxy 数据库连接配置正确。
   本后台直接读取原项目 config/app.php，不需要再次填写数据库账号密码。
3. 浏览器访问：
   http://你的域名或IP/fqxy/gm_admin/
4. 第一次打开会进入“初始化 GM 后台”。自己设置管理员账号和密码。
   账号：4～50 位英文字母、数字、下划线。
   密码：至少 8 位。没有默认账号或默认密码。
5. 创建后自动进入登录页，使用刚设置的账号密码登录。

二、数据库
后台首次启动时会自动创建以下独立管理表：
- xy_gm_admin：GM 账号、密码哈希、角色、启用状态
- xy_gm_log：登录与管理操作日志
- xy_house_def：住宅定义
- xy_player_house：玩家住宅归属
- xy_furniture_def：家具定义
- xy_furniture_attr：家具各等级属性
- xy_player_furniture：玩家家具库存
- xy_house_furniture：住宅家具摆放

因此不需要手动导入本补丁的 SQL。压缩包另附 gm_admin_schema.sql，仅供需要手动建表时参考。

三、后台功能
1. 总览：显示已安装数据表中的数量概览。
2. 玩家管理：搜索玩家 ID/名称；查看角色字段；发放背包物品；增加银两、旧商城金豆（玩家 wp表的物品 ID 127）、经验；设置 VIP 等级。
3. 物品管理：添加/编辑物品定义；启用/停用；删除未被玩家持有的定义；编辑物品属性。
4. 住宅与家具：添加普通住宅、豪宅、官宅；添加家具；配置家具每一级的 HP、MP、攻击、防御、速度、暴击、闪避等属性；启用/停用。
   官宅只有 official 一个分类，不区分仙魔，不自动增加任何后缀。
5. NPC 管理：新增、编辑 NPC 定义；被地图引用的 NPC 不允许直接删除。
6. 任务管理：新增、编辑任务；已有玩家任务记录的任务不允许直接删除。
7. 世界公告：调用游戏现有 msg_queue.txt / sys_history.txt 消息机制发布公告。
8. GM 账号：超级管理员创建账号、设置角色、停用/启用、重置密码。
9. 操作日志：记录登录和关键新增、修改、删除、发放等操作。

四、权限
- super_admin：超级管理员，可管理 GM 账号和所有后台模块。
- admin：管理员，可操作游戏管理模块，不能管理 GM 账号。
- editor：编辑员，可操作游戏管理模块，不能管理 GM 账号。
- viewer：只读账号。

首次安装创建的第一个账号自动为 super_admin。

五、重要说明
1. 不依赖原版 admin/login.php、admin/index.php、xxjyindex.php、user2.ini 或旧 GM 的 pass 参数。
2. 不覆盖或修改原版 fqxy/gm.php，也不改变玩家登录流程。
3. 玩家银两、经验和 VIP 写入原项目 PlayerDb/PlayerStore / zt.ini 数据层；金豆按原版 wp玩家ID 表中 wpid=127、wpfl=4 的记录增加；物品发放使用 ItemDb::give。
4. 玩家搜索优先读取 player_char；若没有找到玩家或该表没有角色记录，会尝试 all_zt。角色属性迁移表不存在时，玩家相关功能会显示提示。
5. 物品模块需要新物品系统的 item_def、item_category、item_attr、player_item 等表。NPC/任务模块需要项目已有的 npc_def、quest_def 等迁移表。缺少相关表时对应模块会显示提示或保存失败，不会自动伪造数据。
6. 房屋定义表自动建立为空表。不会自动恢复任何旧住宅、官宅或家具数据；所有住宅与家具需要从后台重新添加。
7. 删除有玩家引用的数据时会进行拦截；建议优先使用停用。
8. 请勿将 config/app.php、数据库密码或 GM 密码截图公开。首次安装密码由管理员自行设置。
9. 当前压缩包经过 PHP 语法检查。此构建环境没有连接你的 KSWEB/MariaDB 实例，因此数据库实际读写还需在你的服务器首次登录后验证。

六、出现数据库连接失败
检查：
- htdocs/config/app.php 是否存在；
- db.host、db.user、db.pass、db.port、db.game_db 是否与 KSWEB 一致；
- PHP 是否启用 mysqli；
- 数据库账号是否有 CREATE、SELECT、INSERT、UPDATE、DELETE 权限；
- 项目现有 ItemDb.php 使用 mysqli_stmt::get_result，因此需要 KSWEB 的 mysqli/mysqlnd 支持。

七、更新与安全
- 覆盖后台代码不会删除 xy_gm_admin、xy_gm_log 或玩家数据。
- 不要删除 bootstrap.php；所有管理页依赖它进行登录、CSRF 和数据库初始化。
- 若需停止某个管理员，使用“GM 账号”里的停用按钮，不要直接改玩家账号表。
