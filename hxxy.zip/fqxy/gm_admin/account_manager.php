<?php
require_once __DIR__ . '/extra_layout.php';

function gm_account_query_rows($sql, $types, $params)
{
    $db = gm_user_db();
    if (!$db) return array();
    $st = $db->prepare($sql);
    if (!$st) return array();
    if ($types !== '') {
        $refs = array($types);
        foreach ($params as $i => $v) $refs[] = &$params[$i];
        call_user_func_array(array($st, 'bind_param'), $refs);
    }
    if (!$st->execute()) { $st->close(); return array(); }
    $res = $st->get_result();
    $out = array();
    while ($res && ($r = $res->fetch_assoc())) $out[] = $r;
    $st->close();
    return $out;
}

$columns = gm_user_columns('o_user_list');
$hasDb = gm_user_db() !== null;
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    gm_extra_post_guard();
    if (!gm_current_user() || gm_current_user()['role'] !== 'super_admin') { http_response_code(403); die('只有超级管理员可以重置社区账号密码。'); }
    $uid = isset($_POST['uid']) ? (int)$_POST['uid'] : 0;
    $password = isset($_POST['new_password']) ? (string)$_POST['new_password'] : '';
    $confirm = isset($_POST['confirm_password']) ? (string)$_POST['confirm_password'] : '';
    if (!$hasDb || !$columns) {
        gm_set_flash('error', '账号库不可用，或 xxjyuser.o_user_list 表不存在。');
    } elseif (!isset($columns['uid'], $columns['password'])) {
        gm_set_flash('error', '账号表缺少 uid 或 password 字段，不能重置密码。');
    } elseif ($uid <= 0) {
        gm_set_flash('error', '账号 UID 无效。');
    } elseif (strlen($password) < 6 || strlen($password) > 30) {
        gm_set_flash('error', '新密码长度必须为 6～30 个字符。');
    } elseif ($password !== $confirm) {
        gm_set_flash('error', '两次输入的新密码不一致。');
    } else {
        $db = gm_user_db();
        $found = gm_account_query_rows('SELECT uid FROM o_user_list WHERE uid=? LIMIT 1', 'i', array($uid));
        if (!$found) {
            gm_set_flash('error', '没有找到该账号，未修改任何数据。');
        } else {
            // 与游戏 fqxy/login.php 的正式验证方式一致：md5(明文密码 + ALL_PS)。
            $hash = md5($password . 'ALL_PS');
            if (isset($columns['ma'])) {
                $st = $db->prepare('UPDATE o_user_list SET password=?, ma=? WHERE uid=?');
                if ($st) $st->bind_param('ssi', $hash, $hash, $uid);
            } else {
                $st = $db->prepare('UPDATE o_user_list SET password=? WHERE uid=?');
                if ($st) $st->bind_param('si', $hash, $uid);
            }
            $ok = $st && $st->execute();
            if ($st) $st->close();
            if ($ok) {
                gm_log('account_password_reset', '账号 UID ' . $uid, '通过 GM 后台重置登录密码；未记录明文密码');
                gm_set_flash('success', '账号密码已重置。该账号下次登录请使用新密码。');
            } else {
                gm_set_flash('error', '密码更新失败，请检查账号库写入权限。');
            }
        }
    }
    $redirect = 'account_manager.php';
    if (isset($_POST['q']) && $_POST['q'] !== '') $redirect .= '?q=' . rawurlencode((string)$_POST['q']);
    gm_extra_redirect($redirect);
}

$q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$accounts = array();
if ($hasDb && $columns && isset($columns['uid'])) {
    $select = array('uid');
    foreach (array('name', 'username', 'sqid', 'm_id') as $field) if (isset($columns[$field])) $select[] = $field;
    foreach (array('y', 'm', 'd', 'h', 'i', 's') as $field) if (isset($columns[$field])) $select[] = $field;
    $where = '';
    $types = '';
    $params = array();
    if ($q !== '') {
        $clauses = array();
        if (ctype_digit($q)) {
            $numeric = (int)$q;
            $clauses[] = 'uid=?'; $types .= 'i'; $params[] = $numeric;
            $clauses[] = 'CAST(uid AS CHAR) LIKE ?'; $types .= 's'; $params[] = '%' . $q . '%';
            if ($numeric >= 10000000) { $clauses[] = 'uid=?'; $types .= 'i'; $params[] = $numeric - 10000000; }
        }
        foreach (array('username', 'name', 'sqid') as $field) {
            if (isset($columns[$field])) { $clauses[] = '`' . $field . '` LIKE ?'; $types .= 's'; $params[] = '%' . $q . '%'; }
        }
        if ($clauses) $where = ' WHERE (' . implode(' OR ', $clauses) . ')';
    }
    $sql = 'SELECT ' . implode(',', array_map(function($x){ return '`' . $x . '`'; }, $select)) . ' FROM o_user_list' . $where . ' ORDER BY uid DESC LIMIT 100';
    $accounts = gm_account_query_rows($sql, $types, $params);
}

gm_extra_header('社区账号管理', 'account_manager.php');
?>
<div class="panel extra-panel">
 <div class="panel-head"><h2>账号查询</h2><span class="muted">读取独立数据库 xxjyuser，不修改玩家角色资料</span></div>
 <?php if (!$hasDb): ?><div class="notice warn">账号数据库连接失败。请确认 config/app.php 中 user_db 指向正确的社区账号库。</div>
 <?php elseif (!$columns): ?><div class="notice warn">没有找到 xxjyuser.o_user_list，无法管理账号。</div>
 <?php else: ?>
 <form method="get" class="search-row"><input name="q" value="<?php echo gm_h($q); ?>" placeholder="输入账号 UID、登录账号、昵称或区服 sqid"><button class="btn primary">查询账号</button><a class="btn" href="account_manager.php">显示最近账号</a></form>
 <p class="extra-note">账号 UID 对应游戏角色 ID = UID + 10000000。搜索框也支持直接输入游戏角色 ID 反查账号。密码重置沿用游戏登录规则 md5(密码 + ALL_PS)，不会记录明文密码。此处不提供删除账号、改 UID 或直接修改区服绑定，避免破坏角色关联。</p>
 <?php endif; ?>
</div>
<?php if ($hasDb && $columns): ?>
<div class="panel"><div class="panel-head"><h2>账号列表</h2><span class="muted">最多显示 100 条；密码字段不会被读取或展示</span></div>
<div class="table-wrap"><table class="extra-table"><thead><tr><th>社区 UID</th><th>对应游戏角色 ID</th><?php if(isset($columns['username'])): ?><th>登录账号</th><?php endif; ?><?php if(isset($columns['name'])): ?><th>昵称</th><?php endif; ?><?php if(isset($columns['sqid'])): ?><th>区服绑定 sqid</th><?php endif; ?><?php if(isset($columns['m_id'])): ?><th>社区 M_ID</th><?php endif; ?><th>玩家资料</th><th>密码管理</th></tr></thead><tbody>
<?php foreach ($accounts as $a): $uid=(int)$a['uid']; ?>
<tr><td><?php echo $uid; ?></td><td><?php echo $uid + 10000000; ?></td><?php if(isset($columns['username'])): ?><td><?php echo gm_h(isset($a['username'])?$a['username']:''); ?></td><?php endif; ?><?php if(isset($columns['name'])): ?><td><?php echo gm_h(isset($a['name'])?$a['name']:''); ?></td><?php endif; ?><?php if(isset($columns['sqid'])): ?><td><?php echo gm_h(isset($a['sqid'])?$a['sqid']:''); ?></td><?php endif; ?><?php if(isset($columns['m_id'])): ?><td><?php echo gm_h(isset($a['m_id'])?$a['m_id']:''); ?></td><?php endif; ?>
<td><a class="text-link" href="player_tools.php?player_id=<?php echo $uid+10000000; ?>">打开该角色资料</a></td><td><?php if(gm_current_user() && gm_current_user()['role']==='super_admin'): ?><details><summary class="text-link">重置密码</summary><form method="post" style="min-width:220px;padding:8px 0"><?php echo gm_token_field(); ?><input type="hidden" name="uid" value="<?php echo $uid; ?>"><input type="hidden" name="q" value="<?php echo gm_h($q); ?>"><label>新密码<input type="password" name="new_password" minlength="6" maxlength="30" autocomplete="new-password" required></label><label>确认新密码<input type="password" name="confirm_password" minlength="6" maxlength="30" autocomplete="new-password" required></label><button class="btn primary" onclick="return confirm('确定重置该账号的登录密码？');">确认重置</button></form></details><?php else: ?>仅超级管理员可重置<?php endif; ?></td></tr>
<?php endforeach; ?><?php if(!$accounts): ?><tr><td colspan="8" class="empty">没有找到匹配账号。</td></tr><?php endif; ?>
</tbody></table></div></div>
<?php endif; ?>
<?php gm_extra_footer(); ?>
