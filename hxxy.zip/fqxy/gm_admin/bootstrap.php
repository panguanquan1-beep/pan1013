<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/**
 * 《西游踏凌霄》独立 GM 后台公共层
 * PHP 5.6+ / mysqli / MySQL 5.6+
 */
@ini_set('display_errors', '1');
@ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

if (session_id() === '') {
    @ini_set('session.use_only_cookies', '1');
    @ini_set('session.use_strict_mode', '1');
    @ini_set('session.cookie_httponly', '1');
    $gmSecureCookie = !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';
    @session_set_cookie_params(0, '/', '', $gmSecureCookie, true);
    @session_name('XYGMSESSID');
    @session_start();
}

if (!defined('XYGM_ROOT')) define('XYGM_ROOT', dirname(dirname(__DIR__)));
if (!defined('XYGM_GAME_ROOT')) define('XYGM_GAME_ROOT', dirname(__DIR__));

function gm_config()
{
    static $cfg = null;
    if ($cfg === null) {
        $file = XYGM_ROOT . '/config/app.php';
        $exists = class_exists('DbIniStore', false) ? DbIniStore::isFile($file) : is_file($file);
        if (!$exists) die('找不到 config/app.php，请确认 GM 后台放在 htdocs/fqxy/gm_admin/。查找路径：' . $file);
        $cfg = include $file;
        if (!is_array($cfg)) die('config/app.php 没有返回配置数组。');
    }
    return $cfg;
}

function gm_db()
{
    static $db = null;
    if ($db === null) {
        $cfg = gm_config();
        if (!isset($cfg['db']['host'], $cfg['db']['user'], $cfg['db']['pass'], $cfg['db']['game_db'])) {
            die('config/app.php 数据库配置不完整。');
        }
        mysqli_report(MYSQLI_REPORT_OFF);
        $db = @new mysqli($cfg['db']['host'], $cfg['db']['user'], $cfg['db']['pass'], $cfg['db']['game_db'], isset($cfg['db']['port']) ? (int)$cfg['db']['port'] : 3306);
        if ($db->connect_errno) {
            error_log('XYGM DB connection failed: ' . $db->connect_error);
            die('游戏数据库连接失败，请检查 config/app.php。');
        }
        $db->set_charset(isset($cfg['db']['charset']) ? $cfg['db']['charset'] : 'utf8mb4');
    }
    return $db;
}

function gm_last_db_error()
{
    return isset($GLOBALS['xygm_last_db_error']) ? (string)$GLOBALS['xygm_last_db_error'] : '';
}

function gm_stmt($sql, $types, $params)
{
    $GLOBALS['xygm_last_db_error'] = '';
    $db = gm_db();
    $st = $db->prepare($sql);
    if (!$st) {
        $GLOBALS['xygm_last_db_error'] = $db->error;
        error_log('XYGM prepare failed: ' . $db->error . ' SQL=' . $sql);
        return false;
    }
    if ($types !== '') {
        $bind = array($types);
        foreach ($params as $i => $value) $bind[] = &$params[$i];
        if (!call_user_func_array(array($st, 'bind_param'), $bind)) {
            $GLOBALS['xygm_last_db_error'] = $st->error;
            error_log('XYGM bind failed: ' . $st->error . ' SQL=' . $sql);
            $st->close();
            return false;
        }
    }
    if (!$st->execute()) {
        $GLOBALS['xygm_last_db_error'] = $st->error;
        error_log('XYGM execute failed: ' . $st->error . ' SQL=' . $sql);
        $st->close();
        return false;
    }
    return $st;
}

function gm_rows($sql, $types, $params)
{
    $st = gm_stmt($sql, $types, $params);
    if (!$st) return array();
    // mysqlnd 才有 get_result；没有时调用会直接致命，页面空白
    if (method_exists($st, 'get_result')) {
        $res = $st->get_result();
        if ($res instanceof mysqli_result) {
            $rows = array();
            while ($row = $res->fetch_assoc()) $rows[] = $row;
            $st->close();
            return $rows;
        }
    }
    $meta = $st->result_metadata();
    if (!$meta) { $st->close(); return array(); }
    $row = array();
    $bind = array();
    while ($field = $meta->fetch_field()) {
        $row[$field->name] = null;
        $bind[] = &$row[$field->name];
    }
    call_user_func_array(array($st, 'bind_result'), $bind);
    $rows = array();
    while ($st->fetch()) {
        $copy = array();
        foreach ($row as $k => $v) $copy[$k] = $v;
        $rows[] = $copy;
    }
    $meta->free();
    $st->close();
    return $rows;
}

function gm_one($sql, $types, $params)
{
    $rows = gm_rows($sql, $types, $params);
    return count($rows) ? $rows[0] : null;
}

function gm_exec($sql, $types, $params)
{
    $st = gm_stmt($sql, $types, $params);
    if (!$st) return false;
    $affected = $st->affected_rows;
    $st->close();
    return $affected;
}

function gm_table_exists($table)
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    $r = gm_one('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1', 's', array($table));
    return $r !== null;
}

function gm_columns($table)
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !gm_table_exists($table)) return array();
    $rows = gm_rows('SHOW COLUMNS FROM `' . $table . '`', '', array());
    $out = array();
    foreach ($rows as $r) $out[$r['Field']] = $r;
    return $out;
}

function gm_install_tables()
{
    $sql = array();
    $sql[] = "CREATE TABLE IF NOT EXISTS xy_gm_admin (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        username VARCHAR(50) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(24) NOT NULL DEFAULT 'admin',
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        last_login DATETIME NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), UNIQUE KEY uk_xy_gm_username (username)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    $sql[] = "CREATE TABLE IF NOT EXISTS xy_gm_log (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        admin_id INT UNSIGNED NOT NULL DEFAULT 0,
        username VARCHAR(50) NOT NULL DEFAULT '',
        action VARCHAR(64) NOT NULL,
        target VARCHAR(100) NOT NULL DEFAULT '',
        detail TEXT NULL,
        ip VARCHAR(45) NOT NULL DEFAULT '',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY idx_gm_log_time (created_at), KEY idx_gm_log_admin (admin_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    // 房屋/家具业务表由住宅系统迁移文件 027_house_system.sql 唯一管理。
    // GM 初始化不得创建旧版 xy_house_def / xy_player_house 结构，避免与新系统冲突。

    foreach ($sql as $query) {
        if (!gm_db()->query($query)) {
            error_log('XYGM schema error: ' . gm_db()->error);
            return false;
        }
    }
    return true;
}

if (!gm_install_tables()) die('GM 数据表初始化失败，请检查 MySQL 权限和错误日志。');

function gm_h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function gm_token()
{
    if (empty($_SESSION['xygm_token'])) {
        if (function_exists('random_bytes')) {
            try { $_SESSION['xygm_token'] = bin2hex(random_bytes(24)); }
            catch (Exception $e) { $_SESSION['xygm_token'] = sha1(uniqid(mt_rand(), true)); }
        } else {
            $_SESSION['xygm_token'] = sha1(uniqid(mt_rand(), true) . mt_rand());
        }
    }
    return $_SESSION['xygm_token'];
}

function gm_token_field()
{
    return '<input type="hidden" name="_token" value="' . gm_h(gm_token()) . '">';
}

function gm_token_valid()
{
    return isset($_POST['_token'], $_SESSION['xygm_token']) && function_exists('hash_equals')
        ? hash_equals($_SESSION['xygm_token'], (string)$_POST['_token'])
        : (isset($_POST['_token'], $_SESSION['xygm_token']) && $_POST['_token'] === $_SESSION['xygm_token']);
}

function gm_current_user()
{
    return isset($_SESSION['xygm_user']) && is_array($_SESSION['xygm_user']) ? $_SESSION['xygm_user'] : null;
}

function gm_require_login()
{
    if (!gm_current_user()) {
        header('Location: login.php');
        exit;
    }
}

function gm_can_write()
{
    $u = gm_current_user();
    return $u && $u['role'] !== 'viewer';
}

function gm_require_super()
{
    $u = gm_current_user();
    if (!$u || $u['role'] !== 'super_admin') {
        http_response_code(403);
        die('没有权限执行此操作。');
    }
}

function gm_log($action, $target, $detail)
{
    $u = gm_current_user();
    $id = $u ? (int)$u['id'] : 0;
    $name = $u ? $u['username'] : 'system';
    $ip = isset($_SERVER['REMOTE_ADDR']) ? substr($_SERVER['REMOTE_ADDR'], 0, 45) : '';
    gm_exec('INSERT INTO xy_gm_log (admin_id,username,action,target,detail,ip) VALUES (?,?,?,?,?,?)',
        'isssss', array($id, $name, (string)$action, (string)$target, (string)$detail, $ip));
}

function gm_set_flash($type, $message)
{
    $_SESSION['xygm_flash'] = array('type' => $type, 'message' => $message);
}

function gm_take_flash()
{
    if (!isset($_SESSION['xygm_flash'])) return null;
    $f = $_SESSION['xygm_flash'];
    unset($_SESSION['xygm_flash']);
    return $f;
}

function gm_redirect($page, $extra = null)
{
    $url = 'index.php?page=' . rawurlencode($page);
    if (is_array($extra)) {
        foreach ($extra as $k => $v) {
            if ($v === '' || $v === null) continue;
            $url .= '&' . rawurlencode($k) . '=' . rawurlencode((string)$v);
        }
    }
    header('Location: ' . $url);
    exit;
}

function gm_list_q()
{
    return isset($_GET['q']) ? trim((string)$_GET['q']) : '';
}

function gm_list_p()
{
    $p = isset($_GET['p']) ? (int)$_GET['p'] : 1;
    return $p < 1 ? 1 : $p;
}

function gm_pager_data($total, $perPage, $pageNum)
{
    $total = (int)$total;
    $perPage = (int)$perPage;
    if ($perPage < 1) $perPage = 20;
    $pages = $total > 0 ? (int)ceil($total / $perPage) : 1;
    if ($pageNum < 1) $pageNum = 1;
    if ($pageNum > $pages) $pageNum = $pages;
    return array(
        'total' => $total,
        'per' => $perPage,
        'page' => $pageNum,
        'pages' => $pages,
        'offset' => ($pageNum - 1) * $perPage,
    );
}

function gm_page_url($pageKey, $pageNum, $q, $extra = null)
{
    $parts = array('page=' . rawurlencode($pageKey));
    if ((int)$pageNum > 1) $parts[] = 'p=' . (int)$pageNum;
    if ($q !== '') $parts[] = 'q=' . rawurlencode($q);
    if (is_array($extra)) {
        foreach ($extra as $k => $v) {
            if ($v === '' || $v === null) continue;
            if ($k === 'page' || $k === 'p' || $k === 'q') continue;
            $parts[] = rawurlencode($k) . '=' . rawurlencode((string)$v);
        }
    }
    return 'index.php?' . implode('&', $parts);
}

function gm_pager_html($pageKey, $pg, $q, $extra = null)
{
    if (!$pg || (int)$pg['total'] <= 0) return '';
    $page = (int)$pg['page'];
    $pages = (int)$pg['pages'];
    $html = '<div class="pager"><span class="pager-info">共 ' . (int)$pg['total'] . ' 条';
    if ($pages > 1) $html .= '，第 ' . $page . '/' . $pages . ' 页';
    $html .= '</span>';
    if ($pages <= 1) {
        $html .= '</div>';
        return $html;
    }
    if ($page > 1) {
        $html .= '<a href="' . gm_h(gm_page_url($pageKey, $page - 1, $q, $extra)) . '">上一页</a>';
    }
    $start = $page - 3;
    if ($start < 1) $start = 1;
    $end = $start + 6;
    if ($end > $pages) $end = $pages;
    $start = $end - 6;
    if ($start < 1) $start = 1;
    if ($start > 1) {
        $html .= '<a href="' . gm_h(gm_page_url($pageKey, 1, $q, $extra)) . '">1</a>';
        if ($start > 2) $html .= '<span class="pager-info">…</span>';
    }
    for ($i = $start; $i <= $end; $i++) {
        if ($i == $page) $html .= '<span class="pager-current">' . $i . '</span>';
        else $html .= '<a href="' . gm_h(gm_page_url($pageKey, $i, $q, $extra)) . '">' . $i . '</a>';
    }
    if ($end < $pages) {
        if ($end < $pages - 1) $html .= '<span class="pager-info">…</span>';
        $html .= '<a href="' . gm_h(gm_page_url($pageKey, $pages, $q, $extra)) . '">' . $pages . '</a>';
    }
    if ($page < $pages) {
        $html .= '<a href="' . gm_h(gm_page_url($pageKey, $page + 1, $q, $extra)) . '">下一页</a>';
    }
    $html .= '</div>';
    return $html;
}

function gm_clean_text($v, $max)
{
    $v = trim((string)$v);
    $v = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $v);
    if (function_exists('mb_substr')) return mb_substr($v, 0, $max, 'UTF-8');
    return substr($v, 0, $max);
}

function gm_safe_int($v, $min, $max, $default)
{
    if (!is_numeric($v)) return $default;
    $n = (int)$v;
    if ($n < $min) $n = $min;
    if ($n > $max) $n = $max;
    return $n;
}

function gm_has_table($table, $message = '')
{
    if (gm_table_exists($table)) return true;
    echo '<div class="notice warn">缺少数据表 <code>' . gm_h($table) . '</code>。' . gm_h($message) . '</div>';
    return false;
}


/**
 * 读取游戏正式的如意回馈数据。
 * 正式来源：player_kv.ruyi_points / player_kv.ruyi_vip_lv，等级算法直接调用 lib/RuyiDb.php。
 * 不读取 all_zt.vip、player_char.vip 或 player_state_kv.vip等级（这些是旧 VIP 字段）。
 */
function gm_player_ruyi_data($pid)
{
    static $cache = array();
    $pid = (int)$pid;
    if (isset($cache[$pid])) return $cache[$pid];

    $out = array(
        'available' => false,
        'points' => null,
        'level' => null,
        'stored_level' => null,
        'claimed_tiers' => '',
        'next_points' => null,
        'error' => ''
    );

    if ($pid < 10000000) {
        $out['error'] = '玩家编号无效';
        return $cache[$pid] = $out;
    }
    if (!gm_table_exists('player_kv')) {
        $out['error'] = '缺少 player_kv 数据表';
        return $cache[$pid] = $out;
    }
    $ruyiFile = XYGM_ROOT . '/lib/RuyiDb.php';
    if (!is_file($ruyiFile)) {
        $out['error'] = '找不到游戏核心文件 lib/RuyiDb.php';
        return $cache[$pid] = $out;
    }

    try {
        require_once $ruyiFile;
        if (!class_exists('RuyiDb') || !class_exists('PlayerDb')) {
            $out['error'] = '如意回馈核心类未能加载';
            return $cache[$pid] = $out;
        }
        $out['points'] = (int)RuyiDb::getPoints($pid);
        $out['level'] = (int)RuyiDb::getVipLevel($pid);
        $out['stored_level'] = (int)PlayerDb::get($pid, 'ruyi_vip_lv', '0');
        $out['claimed_tiers'] = (string)PlayerDb::get($pid, 'ruyi_tier_claimed', '');
        if ($out['level'] < 22) {
            $out['next_points'] = (int)RuyiDb::needPoints($out['level'] + 1);
        }
        $out['available'] = true;
    } catch (Exception $e) {
        $out['error'] = '读取如意回馈数据失败：' . $e->getMessage();
    }
    return $cache[$pid] = $out;
}

/** 在玩家列表中附加如意回馈等级与积分，不读取旧 VIP 字段。 */
function gm_attach_ruyi_rows($rows)
{
    foreach ($rows as $i => $row) {
        $d = gm_player_ruyi_data(isset($row['player_id']) ? (int)$row['player_id'] : 0);
        $rows[$i]['ruyi_level'] = $d['available'] ? (int)$d['level'] : null;
        $rows[$i]['ruyi_points'] = $d['available'] ? (int)$d['points'] : null;
    }
    return $rows;
}
