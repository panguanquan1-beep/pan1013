<?php
require_once __DIR__ . '/extra_layout.php';
$allowed=array(
 'all_zt'=>'玩家基础信息','all_yl'=>'玩家银两','player_char'=>'统一角色信息','item_def'=>'物品定义','player_item'=>'玩家背包/仓库/装备','item_log'=>'物品流水',
 'npc_def'=>'NPC 定义','map_zone'=>'地图区域','map_loc'=>'地图地点','map_exit'=>'地图出口','map_npc'=>'地图 NPC 放置',
 'monster_def'=>'怪物定义','monster_drop'=>'怪物掉落','quest_def'=>'任务定义','player_quest'=>'玩家任务进度',
 'title_def'=>'称号定义','player_title'=>'玩家称号','achievement_def'=>'成就定义','player_achievement'=>'玩家成就'
);
$table=isset($_GET['table'],$allowed[$_GET['table']])?$_GET['table']:'all_zt';$exists=gm_table_exists($table);$cols=$exists?gm_columns($table):array();$rows=array();if($exists){$order=isset($cols['id'])?'id':(isset($cols['player_id'])?'player_id':(isset($cols['wjid'])?'wjid':array_keys($cols)[0]));$rows=gm_rows('SELECT * FROM `'.$table.'` ORDER BY `'.$order.'` DESC LIMIT 50','',array());}
gm_extra_header('数据库查看中心','db_explorer.php');
?>
<div class="panel extra-panel"><div class="panel-head"><h2>选择数据表</h2><span class="muted">只读模式，不提供任意 SQL 执行</span></div><form method="get" class="search-row"><select name="table"><?php foreach($allowed as $t=>$label): ?><option value="<?php echo gm_h($t); ?>"<?php echo $table===$t?' selected':''; ?>><?php echo gm_h($label.'（'.$t.'）'); ?></option><?php endforeach; ?></select><button class="btn primary">查看数据</button></form><p class="extra-note">为了防止误删或误改，本页面只能查看预先列出的核心表，每次最多显示 50 条。编辑操作请回到对应的玩家、物品、地图或任务管理页面。</p></div>
<div class="panel"><div class="panel-head"><h2><?php echo gm_h($allowed[$table]); ?> <small>(<?php echo gm_h($table); ?>)</small></h2><span class="muted"><?php echo count($rows); ?> 条记录（最多 50 条）</span></div><?php if(!$exists): ?><div class="notice warn">数据库中不存在此表。</div><?php else: ?><div class="table-wrap"><table class="extra-table"><thead><tr><?php foreach($cols as $name=>$col): ?><th><?php echo gm_h($name); ?><br><small><?php echo gm_h($col['Type']); ?></small></th><?php endforeach; ?></tr></thead><tbody><?php foreach($rows as $row): ?><tr><?php foreach($cols as $name=>$col): $val=isset($row[$name])?(string)$row[$name]:'NULL';if(strlen($val)>140)$val=substr($val,0,140).'…'; ?><td><?php echo gm_h($val); ?></td><?php endforeach; ?></tr><?php endforeach; ?><?php if(!$rows): ?><tr><td colspan="<?php echo max(1,count($cols)); ?>" class="empty">表中暂无记录。</td></tr><?php endif; ?></tbody></table></div><?php endif; ?></div>
<?php gm_extra_footer(); ?>
