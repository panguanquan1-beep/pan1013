<?php
require_once __DIR__ . '/bootstrap.php';
gm_require_login();
function gm_extra_header($title, $active)
{
    $u = gm_current_user();
    $links = array(
        array('index.php?page=dashboard','总览'),
        array('index.php?page=players','玩家管理'),
        array('player_tools.php','玩家资料中心'),
        array('index.php?page=items','物品管理'),
        array('index.php?page=npcs','NPC 管理'),
        array('index.php?page=quests','任务管理'),
        array('index.php?page=drops','怪物属性+掉落'),
        array('map_editor.php','地图编辑管理'),
        array('content_editor.php','怪物 / 称号 / 成就'),
        array('system_check.php','系统体检'),
        array('db_explorer.php','数据库查看'),
        array('index.php?page=houses','住宅与家具'),
        array('index.php?page=notice','世界公告'),
        array('index.php?page=admins','GM 账号'),
        array('index.php?page=logs','操作日志')
    );
    echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>西游踏凌霄 - '.gm_h($title).'</title><link rel="stylesheet" href="assets/gm.css"><style>.extra-main{max-width:1500px}.extra-form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}.extra-form-grid label{display:block}.extra-form-grid input,.extra-form-grid select,.extra-form-grid textarea,.extra-field input,.extra-field textarea,.extra-field select{width:100%;box-sizing:border-box}.extra-field{margin:10px 0}.extra-field small{display:block;color:#788397;margin:3px 0}.extra-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.extra-note{font-size:13px;color:#657187;line-height:1.7}.extra-table td{vertical-align:top}.extra-table code{overflow-wrap:anywhere}.extra-panel{margin-bottom:16px}.extra-wide{min-width:0}.extra-textarea{min-height:90px}.extra-danger{color:#b42318}.extra-inline{display:inline-block;margin:0 4px 4px 0}@media(max-width:800px){.app-shell{display:block}.sidebar{position:relative;width:auto;height:auto}.sidebar nav{display:flex;flex-wrap:wrap}.main-area{margin:0;padding:14px}.topbar{margin-bottom:14px}}</style></head><body><div class="app-shell"><aside class="sidebar"><div class="side-brand"><span class="brand-mark small">XY</span><div><b>西游踏凌霄</b><small>独立 GM 管理系统</small></div></div><nav>';
    foreach ($links as $link) {
        $is = ($active === $link[0]) || ($active !== '' && strpos($link[0], $active) !== false);
        echo '<a class="nav-link'.($is?' active':'').'" href="'.gm_h($link[0]).'"><span class="nav-dot"></span>'.gm_h($link[1]).'</a>';
    }
    echo '</nav><div class="side-foot"><div class="admin-chip"><b>'.gm_h($u['username']).'</b><small>'.($u['role']==='super_admin'?'超级管理员':($u['role']==='viewer'?'只读管理员':'管理人员')).'</small></div><a class="logout-link" href="logout.php">退出登录</a></div></aside><main class="main-area extra-main"><header class="topbar"><div><div class="eyebrow">GAME MASTER CONSOLE</div><h1>'.gm_h($title).'</h1></div><div class="top-user"><span class="status-dot"></span>'.gm_h($u['username']).'</div></header>';
    $f = gm_take_flash();
    if ($f) echo '<div class="notice '.gm_h($f['type']).'">'.gm_h($f['message']).'</div>';
    if (!gm_can_write()) echo '<div class="notice warn">当前账号为只读权限，不能执行新增、修改或删除。</div>';
}
function gm_extra_footer()
{
    echo '<footer class="footer">西游踏凌霄 · GM 管理与调试中心 · PHP 5.6 兼容</footer></main></div></body></html>';
}
function gm_extra_post_guard()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    if (!gm_token_valid()) { http_response_code(400); die('页面验证已过期，请返回上一页刷新后重试。'); }
    if (!gm_can_write()) { http_response_code(403); die('当前账号只有查看权限。'); }
}
function gm_extra_redirect($url)
{
    header('Location: '.$url);
    exit;
}
?>
