<?php
// GM 表单辅助：物品按 item_def 字段排列；任务对白按段编辑（游戏里点「继续」翻段）

function gm_quest_split_pages($text)
{
    $text = str_replace("\r\n", "\n", (string)$text);
    $text = trim($text);
    if ($text === '') return array('');
    $parts = preg_split('/\n---+\n/', $text);
    $out = array();
    foreach ($parts as $p) {
        $p = trim($p);
        if ($p !== '') $out[] = $p;
    }
    return $out ? $out : array('');
}

function gm_quest_join_pages($pages)
{
    $out = array();
    if (!is_array($pages)) $pages = array($pages);
    foreach ($pages as $p) {
        $p = trim((string)$p);
        if ($p !== '') $out[] = $p;
    }
    return implode("\n---\n", $out);
}

function gm_quest_pages_from_post($name)
{
    if (isset($_POST[$name . '_page']) && is_array($_POST[$name . '_page'])) {
        return gm_quest_join_pages($_POST[$name . '_page']);
    }
    return isset($_POST[$name]) ? (string)$_POST[$name] : '';
}

function gm_quest_pages_html($name, $label, $hint, $value)
{
    $pages = gm_quest_split_pages($value);
    if (!$pages) $pages = array('');
    if (trim((string)end($pages)) !== '') $pages[] = '';
    $html = '<div class="wide quest-pages" data-name="' . gm_h($name) . '">';
    $html .= '<div class="quest-pages-head"><strong>' . gm_h($label) . '</strong>';
    if ($hint !== '') $html .= '<span class="muted">' . gm_h($hint) . '</span>';
    $html .= '</div>';
    foreach ($pages as $i => $p) {
        $n = $i + 1;
        $html .= '<label class="quest-page-item">第' . $n . '段<textarea name="' . gm_h($name) . '_page[]" rows="4">' . gm_h($p) . '</textarea></label>';
    }
    $html .= '<p class="muted quest-pages-add"><button type="button" class="btn small js-add-quest-page">再加一段</button> 游戏里每段之后只出现「继续」，点一下进入下一段。空段不会保存。</p>';
    $html .= '</div>';
    return $html;
}

function gm_save_row($table, $id, $fields, $typeMap, $idColumn)
{
    $columns = gm_columns($table);
    if (!$columns) return false;
    $exists = null;
    if ($id > 0) {
        $exists = gm_one('SELECT `' . $idColumn . '` FROM `' . $table . '` WHERE `' . $idColumn . '`=? LIMIT 1', 'i', array((int)$id));
    }
    if ($id > 0 && !$exists) {
        $data = array();
        $fields[$idColumn] = (int)$id;
        $typeMap[$idColumn] = 'i';
        foreach ($fields as $key => $value) {
            if (isset($columns[$key])) $data[$key] = $value;
        }
        if (!$data) return false;
        $types = '';
        $params = array();
        $names = array();
        foreach ($data as $key => $value) {
            $names[] = '`' . $key . '`';
            $types .= isset($typeMap[$key]) ? $typeMap[$key] : 's';
            $params[] = $value;
        }
        $sql = 'INSERT INTO `' . $table . '` (' . implode(',', $names) . ') VALUES (' . implode(',', array_fill(0, count($data), '?')) . ')';
        return gm_exec($sql, $types, $params) !== false;
    }
    return gm_dynamic_save($table, $id, $fields, $typeMap, $idColumn);
}

function gm_item_field_meta()
{
    return array(
        'id' => array('label' => '物品 ID', 'hint' => '数字编号。添加时请自己指定，不要跟已有 ID 重复。编辑时不能改。', 'type' => 'id'),
        'legacy_id' => array('label' => '旧编号', 'hint' => '旧 ini 物品 ID，仅对照用，没有就留空。', 'type' => 'intnull'),
        'name' => array('label' => '名称', 'hint' => '游戏里显示的名字，如 〖金豆〗、【小蟠桃】。', 'type' => 'text', 'required' => true, 'max' => 64),
        'color' => array('label' => '名称颜色', 'hint' => '可空。填 red、blue、green，或 #ff9933。', 'type' => 'text', 'max' => 16),
        'category_id' => array('label' => '分类', 'hint' => '对应 item_category 表的编号。', 'type' => 'category', 'required' => true),
        'slot_id' => array('label' => '装备部位', 'hint' => '只有装备才填；药品、材料、任务物品请留空。', 'type' => 'slot'),
        'set_id' => array('label' => '套装编号', 'hint' => '所属套装 ID，没有套装就留空。', 'type' => 'intnull'),
        'type_text' => array('label' => '类别文本', 'hint' => '道具上显示的类别，如 药品、任务、防具-头戴。留空则按分类自动生成。', 'type' => 'text', 'max' => 32),
        'sub_type' => array('label' => '子类', 'hint' => '兵器子类（剑、叉等），或镶物方向。没有就留空。', 'type' => 'text', 'max' => 16),
        'grade' => array('label' => '品级代码', 'hint' => '可填 a / b / c，没有就留空。', 'type' => 'text', 'max' => 4),
        'grade_text' => array('label' => '品阶文字', 'hint' => '徽章名称后面的品阶，如 传说、史诗。没有就留空。', 'type' => 'text', 'max' => 8),
        'bind_type' => array('label' => '绑定规则', 'hint' => '0 不绑定；1 拾取绑定；2 装备绑定；3 拾取和装备都绑定。', 'type' => 'select', 'options' => array('0' => '0 不绑定', '1' => '1 拾取绑定', '2' => '2 装备绑定', '3' => '3 拾取和装备都绑定')),
        'description' => array('label' => '描述', 'hint' => '物品说明文字。', 'type' => 'textarea', 'max' => 500, 'wide' => true),
        'extra_desc' => array('label' => '额外说明', 'hint' => '补充说明，一行一条，用换行分开。', 'type' => 'textarea', 'max' => 500, 'wide' => true),
        'extra_lines' => array('label' => '属性后附加行', 'hint' => '显示在属性后面的额外行，用换行分开，例如 抗暴击率:+21%', 'type' => 'textarea', 'max' => 1000, 'wide' => true),
        'level_req' => array('label' => '需求等级', 'hint' => '使用或穿戴所需等级。', 'type' => 'int', 'min' => 0),
        'req_class' => array('label' => '职业要求', 'hint' => '装备的职业限制文字，没有限制就留空。', 'type' => 'text', 'max' => 64),
        'weight' => array('label' => '重量', 'hint' => '物品重量，填整数。', 'type' => 'int', 'min' => 0),
        'price' => array('label' => '原价', 'hint' => '挂牌默认价 / 商店参考价，单位是银两。', 'type' => 'money'),
        'trade_type' => array('label' => '综合超市类别', 'hint' => '综合超市归类编号。', 'type' => 'select', 'options' => array(
            '1' => '1 消耗品', '2' => '2 兵器', '3' => '3 防具', '4' => '4 书籍',
            '5' => '5 兵器镶物', '6' => '6 防具镶物', '7' => '7 任务物品', '8' => '8 其它'
        )),
        'stackable' => array('label' => '可堆叠', 'hint' => '勾选后同一物品可以叠在同一格。', 'type' => 'check'),
        'max_stack' => array('label' => '最大堆叠', 'hint' => '一格最多叠多少个。', 'type' => 'int', 'min' => 1),
        'bind' => array('label' => '绑定', 'hint' => '勾选表示绑定（沿用旧字段含义）。更细的规则用上面的绑定规则。', 'type' => 'check'),
        'sell_price' => array('label' => '卖店价', 'hint' => '卖给商店得到的银两。', 'type' => 'money'),
        'buy_price' => array('label' => '商店买价', 'hint' => '在商店购买所需银两。', 'type' => 'money'),
        'bean_price' => array('label' => '金豆价格', 'hint' => '标价用的金豆数量。游戏里金豆是背包物品 9322。', 'type' => 'int', 'min' => 0),
        'usable' => array('label' => '可使用', 'hint' => '勾选后玩家可以点「使用」。没有效果的物品请不要勾。', 'type' => 'check'),
        'consume_on_use' => array('label' => '使用后消耗', 'hint' => '勾选后使用一次就少一个。', 'type' => 'check'),
        'base_holes' => array('label' => '基础孔数', 'hint' => '装备自带的镶孔数量。不是装备填 0。', 'type' => 'int', 'min' => 0),
        'punch_holes' => array('label' => '打孔增加数', 'hint' => '打孔器每次增加的孔数。不是打孔器填 0。', 'type' => 'int', 'min' => 0),
        'max_use' => array('label' => '限用次数', 'hint' => '限制使用次数。不限制请留空。', 'type' => 'intnull'),
        'batch_use' => array('label' => '可批量使用', 'hint' => '勾选后允许一次用多个。', 'type' => 'check'),
        'can_refine' => array('label' => '可炼化', 'hint' => '勾选后允许炼化。', 'type' => 'check'),
        'can_drop' => array('label' => '可丢弃', 'hint' => '勾选后玩家可以丢掉。', 'type' => 'check'),
        'can_sell' => array('label' => '可出售', 'hint' => '勾选后可以卖店或上架。', 'type' => 'check'),
        'image' => array('label' => '图片路径', 'hint' => '物品图片相对路径，没有就留空。', 'type' => 'text', 'max' => 128),
        'effect_type' => array('label' => '效果类型', 'hint' => '决定「使用」时干什么。没有效果请选「无效果」，并取消「可使用」。', 'type' => 'effect'),
        'effect_x' => array('label' => '效果参数 X', 'hint' => 'heal：回复生命；learn_skill：技能编号；item_hp：增加的生命上限；bag_capacity：永久增加的背包负重上限（填写正整数，如 1000）。不用就填 0。', 'type' => 'intnull'),
        'effect_y' => array('label' => '效果参数 Y', 'hint' => 'heal：回复内力。不用就填 0 或留空。', 'type' => 'intnull'),
        'effect_value' => array('label' => '效果数值', 'hint' => 'title（称号）时填称号编号。其它效果不用时留空；数据库按整数保存。', 'type' => 'intnull'),
        'use_effect' => array('label' => '使用效果 JSON', 'hint' => '按效果类型填写，必须用英文双引号。永久加属性（stat_bonus / add_hp）例如 {"hp":100}；礼包（gift）例如 {"silver":1000,"exp":100,"items":"9322:1"}，数量也可以写成 物品id:最少-最多。自选一件用 {"pick":[9578,9579,9580]}，随机一件用 {"random":[9578,9579,9580]}，也可以写成逗号分隔。没用就留空。', 'type' => 'textarea', 'max' => 1000, 'wide' => true),
        'gem_target' => array('label' => '镶物对象', 'hint' => '镶物适用：填 兵器 或 防具。不是镶物请留空。', 'type' => 'text', 'max' => 16),
        'use_message' => array('label' => '使用提示', 'hint' => '使用成功后显示的一句话，可空。', 'type' => 'text', 'max' => 255, 'wide' => true),
        'enabled' => array('label' => '启用', 'hint' => '取消勾选后，这件物品定义停用。', 'type' => 'check'),
        'updated_at' => array('type' => 'skip')
    );
}

function gm_item_effect_options()
{
    return array(
        '' => '无效果',
        'return_town' => 'return_town 回城（回到当前区域中心）',
        'teleport_menu' => 'teleport_menu 打开传送菜单（腾云符）',
        'heal' => 'heal 回复生命/内力（X=血，Y=蓝）',
        'learn_skill' => 'learn_skill 学习技能（X=技能编号，并填写使用提示）',
        'item_hp' => 'item_hp 永久增加生命上限（X=增加量）',
        'stat_bonus' => 'stat_bonus 永久加属性（在使用效果 JSON 里填，如 {"hp":100}）',
        'add_hp' => 'add_hp 同 stat_bonus，永久加属性（填 JSON）',
        'gift' => 'gift 开出银两/经验/物品；pick 自选一件，random 随机一件（在使用效果 JSON 里填）',
        'title' => 'title 获得称号（效果数值填称号编号）',
        'house_scepter' => 'house_scepter 帝王权杖（住宅家具）',
        'bag_capacity' => 'bag_capacity 永久增加背包负重上限（X=增加数，不用填写 JSON）'
    );
}

function gm_item_section_for($key)
{
    $map = array(
        'id' => '基本信息（item_def）',
        'description' => '说明文字',
        'level_req' => '等级、价格与交易',
        'stackable' => '堆叠与绑定',
        'usable' => '使用、孔数与开关',
        'effect_type' => '使用效果',
        'enabled' => '状态'
    );
    return isset($map[$key]) ? $map[$key] : '';
}

function gm_item_infer_type($col)
{
    $t = isset($col['Type']) ? strtolower((string)$col['Type']) : 'varchar';
    if (strpos($t, 'tinyint(1)') !== false) return 'check';
    if (strpos($t, 'text') !== false) return 'textarea';
    if (preg_match('/int|decimal|bigint|float|double/', $t)) return 'int';
    if (preg_match('/varchar\((\d+)\)/', $t, $m) && (int)$m[1] >= 200) return 'textarea';
    return 'text';
}

function gm_item_col_max($col, $fallback)
{
    $t = isset($col['Type']) ? (string)$col['Type'] : '';
    if (preg_match('/(?:varchar|char)\((\d+)\)/i', $t, $m)) return (int)$m[1];
    return $fallback;
}

function gm_item_fields_from_post()
{
    $cols = gm_columns('item_def');
    $meta = gm_item_field_meta();
    $fields = array();
    $types = array();
    $money = array('price', 'sell_price', 'buy_price', 'bean_price');
    foreach ($cols as $key => $col) {
        if ($key === 'id' || $key === 'updated_at') continue;
        $m = isset($meta[$key]) ? $meta[$key] : array();
        $kind = isset($m['type']) ? $m['type'] : gm_item_infer_type($col);
        if ($kind === 'skip') continue;
        $max = isset($m['max']) ? (int)$m['max'] : gm_item_col_max($col, 255);
        if ($kind === 'check') {
            $fields[$key] = !empty($_POST[$key]) ? 1 : 0;
            $types[$key] = 'i';
            continue;
        }
        if ($kind === 'effect') {
            $v = isset($_POST['effect_type']) ? trim((string)$_POST['effect_type']) : '';
            $custom = isset($_POST['effect_type_custom']) ? trim((string)$_POST['effect_type_custom']) : '';
            if ($custom !== '') $v = $custom;
            $fields[$key] = gm_clean_text($v, 32);
            $types[$key] = 's';
            continue;
        }
        if ($kind === 'category' || $kind === 'select') {
            $fields[$key] = isset($_POST[$key]) ? gm_clean_text($_POST[$key], 32) : '';
            if ($kind === 'category' || $key === 'trade_type' || $key === 'bind_type') {
                $fields[$key] = (int)$fields[$key];
                $types[$key] = 'i';
            } else {
                $types[$key] = 's';
            }
            continue;
        }
        if ($kind === 'slot' || $kind === 'intnull') {
            $raw = isset($_POST[$key]) ? trim((string)$_POST[$key]) : '';
            $fields[$key] = ($raw === '') ? null : (int)$raw;
            $types[$key] = 's';
            continue;
        }
        if ($kind === 'money') {
            $v = isset($_POST[$key]) ? $_POST[$key] : '0';
            $fields[$key] = is_numeric($v) ? (string)max(0, (float)$v) : '0';
            $types[$key] = 's';
            continue;
        }
        if ($kind === 'int') {
            $v = isset($_POST[$key]) ? $_POST[$key] : 0;
            $fields[$key] = (int)$v;
            $types[$key] = 'i';
            continue;
        }
        // text / textarea
        $raw = isset($_POST[$key]) ? $_POST[$key] : '';
        $fields[$key] = gm_clean_text($raw, $max > 0 ? $max : 1000);
        $types[$key] = 's';
        if (in_array($key, $money, true)) {
            $fields[$key] = is_numeric($raw) ? (string)max(0, (float)$raw) : '0';
        }
    }
    return array($fields, $types);
}

function gm_item_field_value($row, $key, $kind)
{
    if (!$row || !isset($row[$key]) || $row[$key] === null) {
        if ($kind === 'check') {
            return in_array($key, array('enabled', 'stackable', 'usable', 'can_drop', 'can_sell', 'consume_on_use'), true) ? 1 : 0;
        }
        if ($kind === 'int' && $key === 'max_stack') return 999999;
        if ($kind === 'int' && $key === 'level_req') return 1;
        if ($kind === 'int' && $key === 'weight') return 1;
        if ($kind === 'select' && $key === 'trade_type') return '8';
        return '';
    }
    return $row[$key];
}

function gm_render_item_form($editItem, $canWrite, $categories, $slots, $keep)
{
    if (!$canWrite) return;
    $cols = gm_columns('item_def');
    $meta = gm_item_field_meta();
    $effects = gm_item_effect_options();
    echo '<form method="post" class="schema-form">';
    echo gm_token_field();
    echo '<input type="hidden" name="return_page" value="items">';
    if (isset($_GET['q'])) echo '<input type="hidden" name="return_q" value="' . gm_h(gm_list_q()) . '">';
    if (isset($_GET['p']) && (int)$_GET['p'] > 1) echo '<input type="hidden" name="return_p" value="' . (int)$_GET['p'] . '">';
    echo '<input type="hidden" name="action" value="save_item">';
    $curId = $editItem ? (int)$editItem['id'] : 0;
    echo '<input type="hidden" name="id" value="' . $curId . '">';
    $shown = 0;
    foreach ($cols as $key => $col) {
        $m = isset($meta[$key]) ? $meta[$key] : array('label' => $key, 'hint' => '数据表字段，按类型填写。', 'type' => gm_item_infer_type($col));
        $kind = isset($m['type']) ? $m['type'] : 'text';
        if ($kind === 'skip') continue;
        $section = gm_item_section_for($key);
        if ($section !== '') {
            echo '<div class="schema-section">' . gm_h($section) . '</div>';
        }
        $val = gm_item_field_value($editItem, $key, $kind);
        $wide = !empty($m['wide']) || $kind === 'textarea';
        $req = !empty($m['required']) ? ' required' : '';
        echo '<div class="schema-row' . ($wide ? ' wide' : '') . '">';
        echo '<div class="schema-label"><b>' . gm_h(isset($m['label']) ? $m['label'] : $key) . '</b>';
        echo '<code>' . gm_h($key) . '</code>';
        if (!empty($m['hint'])) echo '<span class="field-hint">' . gm_h($m['hint']) . '</span>';
        echo '</div><div class="schema-input">';
        if ($kind === 'id') {
            if ($editItem) {
                echo '<input type="text" value="' . (int)$editItem['id'] . '" disabled>';
            } else {
                echo '<input type="number" name="new_id" min="1" value="" placeholder="指定新物品 ID">';
            }
        } elseif ($kind === 'category') {
            echo '<select name="category_id"' . $req . '>';
            echo '<option value="">请选择分类</option>';
            foreach ($categories as $c) {
                $sel = ($val !== '' && (int)$val === (int)$c['id']) ? ' selected' : '';
                echo '<option value="' . (int)$c['id'] . '"' . $sel . '>' . (int)$c['id'] . ' ' . gm_h($c['name']) . '</option>';
            }
            echo '</select>';
        } elseif ($kind === 'slot') {
            echo '<select name="slot_id">';
            echo '<option value="">非装备，留空</option>';
            foreach ($slots as $s) {
                $sel = ($val !== '' && $val !== null && (int)$val === (int)$s['id']) ? ' selected' : '';
                echo '<option value="' . (int)$s['id'] . '"' . $sel . '>' . (int)$s['id'] . ' ' . gm_h($s['name']) . '</option>';
            }
            echo '</select>';
        } elseif ($kind === 'effect') {
            $known = isset($effects[$val]) || $val === '' || $val === null;
            echo '<select name="effect_type">';
            foreach ($effects as $ev => $elab) {
                $sel = ((string)$val === (string)$ev) ? ' selected' : '';
                echo '<option value="' . gm_h($ev) . '"' . $sel . '>' . gm_h($elab) . '</option>';
            }
            if (!$known && $val !== '' && $val !== null) {
                echo '<option value="' . gm_h($val) . '" selected>其它：' . gm_h($val) . '</option>';
            }
            echo '</select>';
            echo '<input name="effect_type_custom" value="" placeholder="列表里没有的效果类型，可在此手填（会覆盖上面的选择）">';
        } elseif ($kind === 'select') {
            echo '<select name="' . gm_h($key) . '">';
            $opts = isset($m['options']) ? $m['options'] : array();
            foreach ($opts as $ov => $olab) {
                $sel = ((string)$val === (string)$ov) ? ' selected' : '';
                echo '<option value="' . gm_h($ov) . '"' . $sel . '>' . gm_h($olab) . '</option>';
            }
            echo '</select>';
        } elseif ($kind === 'check') {
            $on = ((int)$val === 1) ? ' checked' : '';
            echo '<label class="check"><input type="checkbox" name="' . gm_h($key) . '" value="1"' . $on . '> 是</label>';
        } elseif ($kind === 'textarea') {
            $rows = $key === 'use_effect' ? 3 : 3;
            echo '<textarea name="' . gm_h($key) . '" rows="' . $rows . '">' . gm_h($val) . '</textarea>';
        } else {
            $type = ($kind === 'int' || $kind === 'intnull' || $kind === 'money') ? 'number' : 'text';
            $min = ($kind === 'int' && isset($m['min'])) ? ' min="' . (int)$m['min'] . '"' : (($kind === 'money' || $kind === 'int') ? ' min="0"' : '');
            $step = ($kind === 'money') ? ' step="1"' : '';
            $ph = ($kind === 'intnull') ? ' placeholder="可空"' : '';
            echo '<input type="' . $type . '" name="' . gm_h($key) . '" value="' . gm_h($val) . '"' . $min . $step . $ph . $req . '>';
        }
        echo '</div></div>';
        $shown++;
    }
    if (!$shown) {
        echo '<div class="notice warn">读不到 item_def 字段。</div>';
    }
    echo '<div class="wide form-actions"><button class="btn primary">保存物品</button>';
    if ($editItem) echo ' <a class="btn" href="' . gm_h($keep) . '">取消编辑</a>';
    echo '</div></form>';
}

function gm_quest_goal_types($questCols)
{
    $types = array('talk' => '对话', 'kill' => '击杀', 'item' => '物品');
    if (isset($questCols['done_text'])) {
        $types['none'] = '无目标（对话即完成）';
        $types['skill'] = '技能';
    }
    return $types;
}

function gm_render_quest_form($editQuest, $canWrite, $questCols, $questQ, $questPg, $questKeep)
{
    if (!$canWrite) return;
    $v = function ($key, $default = '') use ($editQuest) {
        if (!$editQuest || !isset($editQuest[$key]) || $editQuest[$key] === null) return $default;
        return $editQuest[$key];
    };
    $goalTypes = gm_quest_goal_types($questCols);
    $curGoal = $v('goal_type', 'talk');
    echo '<form method="post" class="schema-form">';
    echo gm_token_field();
    echo '<input type="hidden" name="return_page" value="quests">';
    echo '<input type="hidden" name="return_q" value="' . gm_h($questQ) . '">';
    echo '<input type="hidden" name="return_p" value="' . (int)$questPg['page'] . '">';
    echo '<input type="hidden" name="action" value="save_quest">';
    echo '<input type="hidden" name="id" value="' . ($editQuest ? (int)$editQuest['id'] : 0) . '">';

    echo '<div class="schema-section">基本信息（quest_def）</div>';
    echo '<div class="form-grid">';
    if ($editQuest) {
        echo '<label>任务 ID<input type="text" value="' . (int)$editQuest['id'] . '" disabled></label>';
    } else {
        echo '<label>任务 ID<input type="number" name="quest_id" min="1" value="" placeholder="指定新任务 ID"><span class="field-hint">请自己指定编号，不要跟已有任务重复。留空则由系统自动编号。</span></label>';
    }
    echo '<label>任务类型 kind<input name="kind" value="' . gm_h($v('kind', '主线')) . '"><span class="field-hint">如 主线、关键、支线、日常。</span></label>';
    echo '<label>任务名称 name<input name="name" required value="' . gm_h($v('name')) . '"></label>';
    if (isset($questCols['tag'])) {
        echo '<label>列表后缀 tag<input name="tag" maxlength="8" value="' . gm_h($v('tag')) . '"><span class="field-hint">显示在任务列表名后面，如 新、支。可空。</span></label>';
    }
    if (isset($questCols['area'])) {
        echo '<label>所属区域 area<input name="area" maxlength="32" value="' . gm_h($v('area')) . '"><span class="field-hint">对话页第二行显示的地名，如 东海渔村。可空。</span></label>';
    }
    echo '<label>最低等级 min_level<input type="number" name="min_level" min="0" value="' . (int)$v('min_level', 0) . '"></label>';
    if (isset($questCols['done_level'])) {
        echo '<label>交任务所需等级 done_level<input type="number" name="done_level" min="0" value="' . (int)$v('done_level', 0) . '"><span class="field-hint">0 表示不额外限制。</span></label>';
    }
    echo '<label>发布 NPC ID giver_npc<input type="number" name="giver_npc" value="' . gm_h($v('giver_npc')) . '"><span class="field-hint">填 npc_def 的 ID，不是旧编号。</span></label>';
    if (isset($questCols['turnin_npc'])) {
        echo '<label>交任务 NPC ID turnin_npc<input type="number" name="turnin_npc" value="' . gm_h($v('turnin_npc')) . '"><span class="field-hint">留空则按目标类型自动判断。</span></label>';
    }
    echo '<label>目标类型 goal_type<select name="goal_type">';
    foreach ($goalTypes as $gv => $glab) {
        $sel = ((string)$curGoal === (string)$gv) ? ' selected' : '';
        echo '<option value="' . gm_h($gv) . '"' . $sel . '>' . gm_h($glab) . '</option>';
    }
    echo '</select></label>';
    echo '<label>目标编号 goal_ref<input name="goal_ref" value="' . gm_h($v('goal_ref')) . '"><span class="field-hint">对话填目标 NPC 的 npc_def ID；击杀填怪物编号；物品填 item_def ID。对话任务不填则跟发布 NPC 谈即可。</span></label>';
    echo '<label>目标数量 goal_qty<input type="number" min="0" name="goal_qty" value="' . (int)$v('goal_qty', 1) . '"><span class="field-hint">对话可填 0，表示谈一次即可完成。</span></label>';
    echo '<label>后续任务 ID next_id<input type="number" name="next_id" value="' . gm_h($v('next_id')) . '"><span class="field-hint">完成本环后自动接取的下一环，没有就留空。</span></label>';
    echo '</div>';

    echo '<div class="schema-section">连续对白（游戏里点「继续」翻到下一段，没有上一页下一页）</div>';
    echo gm_quest_pages_html('descr', '接任务对白 descr', '玩家来接这环时说的话。一段就是一页，点「继续」才进入下一段；到最后一段才真正接取任务。只写一段时，和以前一样当场接取。', $v('descr'));
    if (isset($questCols['talk_text'])) {
        echo gm_quest_pages_html('talk_text', '对话目标处对白 talk_text', '已接任务后，去目标 NPC 处触发的话。同样按段点「继续」。没有就留空。', $v('talk_text'));
    }
    if (isset($questCols['done_text'])) {
        echo gm_quest_pages_html('done_text', '交任务对白 done_text', '交还任务时说的话。多段时，到最后一段才真正交任务并发奖。', $v('done_text'));
    }

    echo '<div class="schema-section">奖励</div>';
    echo '<div class="form-grid">';
    if (isset($questCols['accept_exp'])) {
        echo '<label>接取经验 accept_exp<input type="number" min="0" name="accept_exp" value="' . gm_h($v('accept_exp', 0)) . '"></label>';
    }
    if (isset($questCols['accept_silver'])) {
        echo '<label>接取银两 accept_silver<input type="number" min="0" name="accept_silver" value="' . gm_h($v('accept_silver', 0)) . '"></label>';
    }
    if (isset($questCols['accept_items'])) {
        echo '<label class="wide">接取物品 accept_items<input name="accept_items" value="' . gm_h($v('accept_items')) . '"><span class="field-hint">格式 物品ID:数量，多件用逗号分开，如 1:15,9406:2。没有就留空。</span></label>';
    }
    echo '<label>完成经验 reward_exp<input type="number" min="0" name="reward_exp" value="' . gm_h($v('reward_exp', 0)) . '"></label>';
    echo '<label>完成银两 reward_silver<input type="number" min="0" name="reward_silver" value="' . gm_h($v('reward_silver', 0)) . '"></label>';
    echo '<label>完成物品 ID reward_item<input type="number" name="reward_item" value="' . gm_h($v('reward_item')) . '"><span class="field-hint">只奖一件时用这两个框。留空表示没有。</span></label>';
    echo '<label>完成物品数量 reward_item_qty<input type="number" min="0" name="reward_item_qty" value="' . (int)$v('reward_item_qty', 0) . '"></label>';
    if (isset($questCols['reward_items'])) {
        echo '<label class="wide">额外完成物品 reward_items<input name="reward_items" value="' . gm_h($v('reward_items')) . '"><span class="field-hint">格式同接取物品：物品ID:数量,物品ID:数量。</span></label>';
    }
    if (isset($questCols['talk_items'])) {
        echo '<label class="wide">对话目标处获得 talk_items<input name="talk_items" value="' . gm_h($v('talk_items')) . '"><span class="field-hint">在目标 NPC 处说到最后一段时发放。格式同上。</span></label>';
    }
    echo '</div>';

    if (isset($questCols['in_menu']) || isset($questCols['menu_loc']) || isset($questCols['menu_goto'])) {
        echo '<div class="schema-section">任务菜单</div>';
        echo '<div class="form-grid">';
        if (isset($questCols['in_menu'])) {
            $checked = ($editQuest ? (int)$v('in_menu', 1) : 1) ? ' checked' : '';
            echo '<label class="check">出现在未接菜单 in_menu<input type="checkbox" name="in_menu" value="1"' . $checked . '><span class="field-hint">主线衔接任务通常不勾选。</span></label>';
        }
        if (isset($questCols['menu_loc'])) {
            echo '<label>未接菜单地点 menu_loc<input name="menu_loc" value="' . gm_h($v('menu_loc')) . '"></label>';
        }
        if (isset($questCols['menu_goto'])) {
            echo '<label>未接继续传送 menu_goto<input name="menu_goto" value="' . gm_h($v('menu_goto')) . '"><span class="field-hint">格式 x,y 。可空。</span></label>';
        }
        echo '</div>';
    }

    $hasQuick = isset($questCols['quick_fee']) && isset($questCols['quick_dtx']) && isset($questCols['quick_dty']);
    echo '<div class="schema-section">快速前往</div>';
    if ($hasQuick) {
        echo '<div class="form-grid">';
        echo '<label>区域 dtx<input type="number" min="0" name="quick_dtx" value="' . (($editQuest && $editQuest['quick_dtx'] !== null) ? (int)$editQuest['quick_dtx'] : '') . '"></label>';
        echo '<label>地点 dty<input type="number" min="0" name="quick_dty" value="' . (($editQuest && $editQuest['quick_dty'] !== null) ? (int)$editQuest['quick_dty'] : '') . '"></label>';
        echo '<label>费用（银两）<input type="number" min="0" step="1" name="quick_fee" value="' . gm_h($v('quick_fee', 0)) . '"></label>';
        echo '<p class="muted wide">区域和地点都填写、费用大于 0，并且地图中确实有该地点时，任务页才显示「快速进行任务(费用两)」。只传送，不会自动完成任务。留空或费用填 0 即关闭。</p>';
        echo '</div>';
    } else {
        echo '<p class="muted">快速前往尚未安装。请先执行 sql_schema/029_quest_quick_travel.sql。</p>';
    }

    echo '<div class="wide form-actions"><button class="btn primary">保存任务</button>';
    if ($editQuest) echo ' <a class="btn" href="' . gm_h($questKeep) . '">取消编辑</a>';
    echo '</div></form>';
}

function gm_npc_digits($v)
{
    $v = trim((string)$v);
    $v = preg_replace('/[^0-9]/', '', $v);
    if ($v === '') return '0';
    $v = ltrim($v, '0');
    return $v === '' ? '0' : $v;
}

function gm_npc_save_shop($npcId)
{
    $npcId = (int)$npcId;
    if ($npcId <= 0) return true;
    if (!gm_table_exists('npc_func_shop')) return '缺少 npc_func_shop 表，请先导入 080_npc_func.sql。';
    if (gm_exec('DELETE FROM npc_func_shop WHERE npc_id=?', 'i', array($npcId)) === false) return '保存商店货物失败。';
    $ids = (isset($_POST['shop_item_id']) && is_array($_POST['shop_item_id'])) ? $_POST['shop_item_id'] : array();
    $prices = (isset($_POST['shop_price']) && is_array($_POST['shop_price'])) ? $_POST['shop_price'] : array();
    $sorts = (isset($_POST['shop_sort']) && is_array($_POST['shop_sort'])) ? $_POST['shop_sort'] : array();
    $seen = array();
    $auto = 0;
    $missing = array();
    for ($i = 0; $i < count($ids); $i++) {
        $iid = (int)$ids[$i];
        if ($iid <= 0) continue;
        if (isset($seen[$iid])) continue;
        $seen[$iid] = 1;
        $exists = gm_one('SELECT id, name FROM item_def WHERE id=?', 'i', array($iid));
        if (!$exists) { $missing[] = $iid; continue; }
        $price = gm_npc_digits(isset($prices[$i]) ? $prices[$i] : '0');
        $sort = (isset($sorts[$i]) && trim((string)$sorts[$i]) !== '') ? (int)$sorts[$i] : (++$auto);
        if (gm_exec('INSERT INTO npc_func_shop (npc_id,item_id,price,sort) VALUES (?,?,?,?)', 'issi', array($npcId, $iid, $price, $sort)) === false) {
            return '保存商店货物失败。';
        }
    }
    if ($missing) return '以下物品 ID 不存在，未加入商店：' . implode('、', $missing) . '。其它货物已保存。';
    return true;
}

function gm_npc_save_teleports($npcId)
{
    $npcId = (int)$npcId;
    if ($npcId <= 0) return true;
    if (!gm_table_exists('npc_teleport')) return '缺少 npc_teleport 表，请先导入 080_npc_func.sql。';
    if (gm_exec('DELETE FROM npc_teleport WHERE npc_id=?', 'i', array($npcId)) === false) return '保存传送点失败。';
    $cols = gm_columns('npc_teleport');
    $hasCond = isset($cols['min_lv']) && isset($cols['req_quest']) && isset($cols['req_camp']) && isset($cols['enabled']);
    $labels = (isset($_POST['tele_label']) && is_array($_POST['tele_label'])) ? $_POST['tele_label'] : array();
    $dtxs = (isset($_POST['tele_dtx']) && is_array($_POST['tele_dtx'])) ? $_POST['tele_dtx'] : array();
    $dtys = (isset($_POST['tele_dty']) && is_array($_POST['tele_dty'])) ? $_POST['tele_dty'] : array();
    $costs = (isset($_POST['tele_cost']) && is_array($_POST['tele_cost'])) ? $_POST['tele_cost'] : array();
    $sorts = (isset($_POST['tele_sort']) && is_array($_POST['tele_sort'])) ? $_POST['tele_sort'] : array();
    $minlvs = (isset($_POST['tele_min_lv']) && is_array($_POST['tele_min_lv'])) ? $_POST['tele_min_lv'] : array();
    $quests = (isset($_POST['tele_req_quest']) && is_array($_POST['tele_req_quest'])) ? $_POST['tele_req_quest'] : array();
    $camps = (isset($_POST['tele_req_camp']) && is_array($_POST['tele_req_camp'])) ? $_POST['tele_req_camp'] : array();
    $opens = (isset($_POST['tele_enabled']) && is_array($_POST['tele_enabled'])) ? $_POST['tele_enabled'] : array();
    $auto = 0;
    for ($i = 0; $i < count($labels); $i++) {
        $label = gm_clean_text(isset($labels[$i]) ? $labels[$i] : '', 64);
        if ($label === '') continue;
        $dtx = isset($dtxs[$i]) ? (int)$dtxs[$i] : 0;
        $dty = isset($dtys[$i]) ? (int)$dtys[$i] : 0;
        $cost = gm_npc_digits(isset($costs[$i]) ? $costs[$i] : '0');
        $sort = (isset($sorts[$i]) && trim((string)$sorts[$i]) !== '') ? (int)$sorts[$i] : (++$auto);
        if (!$hasCond) {
            if (gm_exec('INSERT INTO npc_teleport (npc_id,label,dtx,dty,cost_silver,sort) VALUES (?,?,?,?,?,?)', 'isiisi', array($npcId, $label, $dtx, $dty, $cost, $sort)) === false) {
                return '保存传送点失败。';
            }
            continue;
        }
        $minLv = (isset($minlvs[$i]) && trim((string)$minlvs[$i]) !== '') ? (int)$minlvs[$i] : 0;
        $quest = (isset($quests[$i]) && trim((string)$quests[$i]) !== '') ? (int)$quests[$i] : 0;
        $camp = isset($camps[$i]) ? trim((string)$camps[$i]) : '';
        if ($camp !== '' && !in_array($camp, array('阐教', '截教'), true)) $camp = '';
        $enabled = (isset($opens[$i]) && (int)$opens[$i] === 0) ? 0 : 1;
        if (gm_exec('INSERT INTO npc_teleport (npc_id,label,dtx,dty,cost_silver,sort,min_lv,req_quest,req_camp,enabled) VALUES (?,?,?,?,?,?,?,?,?,?)', 'isiisiiisi', array($npcId, $label, $dtx, $dty, $cost, $sort, $minLv, $quest, $camp, $enabled)) === false) {
            return '保存传送点失败。';
        }
    }
    return true;
}

function gm_npc_teleport_data_path()
{
    return dirname(__DIR__) . '/map/teleport_data.php';
}

function gm_npc_load_teleport_data()
{
    $path = gm_npc_teleport_data_path();
    if (!is_file($path)) return array();
    $data = include $path;
    return is_array($data) ? $data : array();
}

function gm_npc_write_teleport_data($data)
{
    ksort($data, SORT_NUMERIC);
    $lines = array("<?php", "/** 传送表 */", "return array(");
    foreach ($data as $id => $row) {
        $id = (int)$id;
        $name = isset($row['name']) ? $row['name'] : '';
        $dtx = isset($row['dtx']) ? (int)$row['dtx'] : 0;
        $dty = isset($row['dty']) ? (int)$row['dty'] : 0;
        $lines[] = "    " . $id . " => array('name' => " . var_export($name, true)
            . ", 'dtx' => " . $dtx
            . ", 'dty' => " . $dty . "),";
    }
    $lines[] = ");";
    $src = implode("
", $lines) . "
";
    $path = gm_npc_teleport_data_path();
    if (is_file($path)) @copy($path, $path . '.bak-' . date('Ymd-His'));
    if (class_exists('DbIniStore', false)) {
        return DbIniStore::filePutContents($path, $src) !== false;
    }
    return file_put_contents($path, $src) !== false;
}

function gm_npc_next_click_legacy()
{
    $next = 501;
    $row = gm_one('SELECT MAX(legacy_id) AS n FROM npc_def WHERE legacy_id>=501', '', array());
    if ($row && (int)$row['n'] >= $next) $next = (int)$row['n'] + 1;
    foreach (gm_npc_load_teleport_data() as $id => $unused) {
        if ((int)$id >= $next) $next = (int)$id + 1;
    }
    return $next;
}

function gm_npc_click_dest_from_post()
{
    $dtxRaw = isset($_POST['click_tp_dtx']) ? trim((string)$_POST['click_tp_dtx']) : '';
    $dtyRaw = isset($_POST['click_tp_dty']) ? trim((string)$_POST['click_tp_dty']) : '';
    if ($dtxRaw === '' || $dtyRaw === '') return null;
    if (!preg_match('/^-?\d+$/', $dtxRaw) || !preg_match('/^-?\d+$/', $dtyRaw)) return false;
    return array('dtx' => (int)$dtxRaw, 'dty' => (int)$dtyRaw);
}

function gm_npc_prepare_click_teleport(&$fields)
{
    $dest = gm_npc_click_dest_from_post();
    if ($dest === null) return true;
    if ($dest === false) return '一点就传送的地图编号或坐标格式不正确。';
    $fields['page'] = 20;
    if ((int)$fields['legacy_id'] < 501) {
        $fields['legacy_id'] = gm_npc_next_click_legacy();
    }
    return true;
}

function gm_npc_save_click_teleport($legacyId, $name)
{
    $legacyId = (int)$legacyId;
    $dest = gm_npc_click_dest_from_post();
    $data = gm_npc_load_teleport_data();
    if ($dest === null) {
        if ($legacyId >= 501 && isset($data[$legacyId])) {
            unset($data[$legacyId]);
            if (!gm_npc_write_teleport_data($data)) return '已保存 NPC，但未能从传送表里去掉旧的一点传送。请检查 map/teleport_data.php 是否可写。';
        }
        return true;
    }
    if ($dest === false) return '一点就传送的地图编号或坐标格式不正确。';
    if ($legacyId < 501) return '一点就传送需要旧编号 ≥ 501。';
    if ($legacyId === 500) return '旧编号 500 已用于船夫传送，请换一个编号。';
    $data[$legacyId] = array(
        'name' => (string)$name,
        'dtx' => $dest['dtx'],
        'dty' => $dest['dty'],
    );
    if (!gm_npc_write_teleport_data($data)) return 'NPC 已保存，但未能写入一点传送（map/teleport_data.php）。请检查文件是否可写。';
    return true;
}

function gm_npc_delete_click_teleport($legacyId)
{
    $legacyId = (int)$legacyId;
    if ($legacyId < 501) return true;
    $data = gm_npc_load_teleport_data();
    if (!isset($data[$legacyId])) return true;
    unset($data[$legacyId]);
    return gm_npc_write_teleport_data($data);
}

function gm_npc_fields_from_post()
{
    $talk = gm_quest_pages_from_post('talk');
    $fields = array(
        'legacy_id' => (int)(isset($_POST['legacy_id']) ? $_POST['legacy_id'] : 0),
        'name' => gm_clean_text(isset($_POST['name']) ? $_POST['name'] : '', 64),
        'page' => (int)(isset($_POST['page']) ? $_POST['page'] : 7),
        'color' => gm_clean_text(isset($_POST['color']) ? $_POST['color'] : 'blue', 16),
        'talk' => gm_clean_text($talk, 20000),
    );
    if (isset($_POST['promo_icon'])) $fields['promo_icon'] = gm_clean_text($_POST['promo_icon'], 32);
    $types = array('legacy_id' => 'i', 'page' => 'i');
    return array($fields, $types);
}

function gm_render_npc_form($editNpc, $canWrite, $keep)
{
    if (!$canWrite) return;
    $cols = gm_columns('npc_def');
    $id = $editNpc ? (int)$editNpc['id'] : 0;
    $v = function ($key, $default) use ($editNpc) {
        if ($editNpc && isset($editNpc[$key]) && $editNpc[$key] !== null) return $editNpc[$key];
        return $default;
    };
    echo '<div class="panel"><div class="panel-head"><h2>' . ($editNpc ? '编辑 NPC' : '添加 NPC') . '</h2>';
    if ($editNpc) echo '<span class="tag">ID ' . $id . '</span>';
    echo '</div>';
    if (!$cols) {
        echo '<div class="notice warn">NPC 表尚未安装，请执行 015_map_npc_quest.sql。</div></div>';
        return;
    }
    echo '<p class="muted">按 npc_def 字段填写。商店和「选一个目的地再传送」配在下边两栏。点一下就传到某处：在「一点就传送」里填目标地图编号 dtx 和坐标 dty，保存后页面会自动设为 20，旧编号若小于 501 会自动分配。对话、商店、先出传送菜单请把页面 ID 填 7。要把 NPC 放到地图上，还需要在地图编辑管理里挂上。</p>';
    echo '<form method="post" class="schema-form">';
    echo gm_token_field();
    echo '<input type="hidden" name="return_page" value="npcs">';
    $q = '';
    if (isset($_POST['return_q'])) $q = $_POST['return_q'];
    elseif (isset($_GET['q'])) $q = $_GET['q'];
    $pp = '';
    if (isset($_POST['return_p'])) $pp = $_POST['return_p'];
    elseif (isset($_GET['p'])) $pp = $_GET['p'];
    echo '<input type="hidden" name="return_q" value="' . gm_h($q) . '">';
    echo '<input type="hidden" name="return_p" value="' . gm_h($pp) . '">';
    echo '<input type="hidden" name="action" value="save_npc">';
    echo '<input type="hidden" name="id" value="' . $id . '">';

    echo '<div class="schema-section"><div class="schema-section-title">基本信息</div>';
    echo '<div class="schema-row"><label>NPC 编号 id<span class="field-hint">数据库主键。新 NPC 可自定，不要占用已有编号。商店货物按这个 ID 保存。</span>';
    if ($editNpc) echo '<input type="text" value="' . $id . '" disabled></label>';
    else echo '<input type="number" name="new_id" min="1" placeholder="可留空，保存后自动编号"></label>';
    echo '<label>旧编号 legacy_id<span class="field-hint">地图上点击用的编号，场景链接用这个号。同一地点不要和其他 NPC 重复。</span><input type="number" name="legacy_id" value="' . (int)$v('legacy_id', 0) . '"></label></div>';
    echo '<div class="schema-row"><label>名称 name<span class="field-hint">玩家看到的 NPC 名字。</span><input name="name" required value="' . gm_h($v('name', '')) . '"></label>';
    echo '<label>名称颜色 color<span class="field-hint">地图上名字的颜色，常用 blue 或 red。</span><input name="color" value="' . gm_h($v('color', 'blue')) . '"></label></div>';
    echo '<div class="schema-row"><label>点击跳转页面 ID page<span class="field-hint">对话、商店、先出传送菜单请填 7。点一下就传送请填 20（填写下方目的地后也会自动改成 20）。住宅、玄武门这类特殊功能才用其它页。</span><input type="number" name="page" value="' . (int)$v('page', 7) . '"></label>';
    if (isset($cols['promo_icon'])) {
        echo '<label>场景感叹号 promo_icon<span class="field-hint">场景名字前的宣传图标，例如 g1570_gth。一般留空。</span><input name="promo_icon" value="' . gm_h($v('promo_icon', '')) . '"></label>';
    }
    echo '</div></div>';

    echo gm_quest_pages_html('talk', '对白 talk', '可分多段。游戏里每段之后只出现「继续」，最后一段才出现买东西和传送。空段不会保存。', $v('talk', ''));

    $shopRows = array();
    $teleRows = array();
    if ($id > 0) {
        if (gm_table_exists('npc_func_shop')) $shopRows = gm_rows('SELECT s.*, d.name FROM npc_func_shop s LEFT JOIN item_def d ON d.id=s.item_id WHERE s.npc_id=? ORDER BY s.sort, s.item_id', 'i', array($id));
        if (gm_table_exists('npc_teleport')) $teleRows = gm_rows('SELECT * FROM npc_teleport WHERE npc_id=? ORDER BY sort, id', 'i', array($id));
    }
    while (count($shopRows) < 3) $shopRows[] = array('item_id' => '', 'price' => '', 'sort' => '', 'name' => '');
    while (count($teleRows) < 2) $teleRows[] = array('label' => '', 'dtx' => '', 'dty' => '', 'cost_silver' => '', 'sort' => '');

    $clickDtx = '';
    $clickDty = '';
    $legacyNow = (int)$v('legacy_id', 0);
    $clickMap = gm_npc_load_teleport_data();
    if ($legacyNow > 0 && isset($clickMap[$legacyNow])) {
        $clickDtx = (string)(int)$clickMap[$legacyNow]['dtx'];
        $clickDty = (string)(int)$clickMap[$legacyNow]['dty'];
    }
    echo '<div class="schema-section"><div class="schema-section-title">一点就传送</div>';
    echo '<p class="muted">玩家在场景里点这个 NPC，会立刻传到目标坐标，中间不会再出对白或传送菜单。例如返回枉死门：地图编号填 47，坐标填 0。两个都填了才会启用；保存时页面会改成 20。旧编号请用 501 及以上，留空或小于 501 时会自动分配。下方「传送」表格是另一种：点 NPC 后再点一条传送链接。</p>';
    echo '<div class="schema-row"><label>目标地图编号 dtx<input type="number" name="click_tp_dtx" value="' . gm_h($clickDtx) . '" placeholder="例如 47"></label>';
    echo '<label>目标坐标 dty<input type="number" name="click_tp_dty" value="' . gm_h($clickDty) . '" placeholder="例如 0"></label></div></div>';

    echo '<div class="schema-section"><div class="schema-section-title">商店（买东西）</div>';
    if (!gm_table_exists('npc_func_shop')) {
        echo '<div class="notice warn">还没有 npc_func_shop 表，请先导入 080_npc_func.sql，否则商店保不住。</div>';
    }
    echo '<p class="muted">每行一件货：物品 ID、银两单价、排序（越小越靠前）。留空的行不保存。这是这个 NPC 自己的货架，不会改到孔方兄、张二妈那些老商店。</p>';
    echo '<div class="table-wrap"><table class="func-table" id="npc-shop-table"><thead><tr><th>物品 ID</th><th>名称（保存后可见）</th><th>银两单价</th><th>排序</th></tr></thead><tbody>';
    foreach ($shopRows as $r) {
        $nm = isset($r['name']) ? $r['name'] : '';
        $iidv = (isset($r['item_id']) && $r['item_id'] !== '') ? (int)$r['item_id'] : '';
        $sortv = (isset($r['sort']) && $r['sort'] !== '') ? (int)$r['sort'] : '';
        echo '<tr><td><input type="number" name="shop_item_id[]" min="0" value="' . $iidv . '"></td>';
        echo '<td class="muted">' . gm_h($nm) . '</td>';
        echo '<td><input name="shop_price[]" value="' . gm_h(isset($r['price']) ? $r['price'] : '') . '" placeholder="0"></td>';
        echo '<td><input type="number" name="shop_sort[]" value="' . $sortv . '"></td></tr>';
    }
    echo '</tbody></table></div>';
    echo '<p class="muted"><button type="button" class="btn small js-add-shop-row">再加一行货物</button></p></div>';

    echo '<div class="schema-section"><div class="schema-section-title">传送</div>';
    if (!gm_table_exists('npc_teleport')) {
        echo '<div class="notice warn">还没有 npc_teleport 表，请先导入 080_npc_func.sql，否则传送保不住。</div>';
    }
    echo '<p class="muted">每行一个目的地：链接上显示的名称、地图编号 dtx、坐标 dty、银两费用（填 0 或不填就是免费）。条件栏可留空＝不限制：最低等级填 0 或不填＝不限等级；需任务填任务 ID＝该任务完成后才开放；需阵营填 阐教 / 截教＝只有该阵营能传送；开关选「关」＝这一条直接不开放。留空名称的行不保存。</p>';
    $tpCols = gm_columns('npc_teleport');
    $hasCond = isset($tpCols['min_lv']) && isset($tpCols['req_quest']) && isset($tpCols['req_camp']) && isset($tpCols['enabled']);
    echo '<div class="table-wrap"><table class="func-table" id="npc-tele-table"><thead><tr><th>显示名称</th><th>地图 dtx</th><th>坐标 dty</th><th>银两费用</th><th>排序</th><th>最低等级</th><th>需任务ID</th><th>需阵营</th><th>开关</th></tr></thead><tbody>';
    if (!$hasCond) {
        echo '<tr><td colspan="9" class="muted">npc_teleport 还没有条件字段（min_lv / req_quest / req_camp / enabled），请先导入 075_teleport_system.sql，导入后这里才会出现条件栏。</td></tr>';
    }
    foreach ($teleRows as $r) {
        $dtxv = (isset($r['dtx']) && $r['dtx'] !== '') ? (int)$r['dtx'] : '';
        $dtyv = (isset($r['dty']) && $r['dty'] !== '') ? (int)$r['dty'] : '';
        $sortv = (isset($r['sort']) && $r['sort'] !== '') ? (int)$r['sort'] : '';
        $lv = (isset($r['min_lv']) && (int)$r['min_lv'] > 0) ? (int)$r['min_lv'] : '';
        $qs = (isset($r['req_quest']) && (int)$r['req_quest'] > 0) ? (int)$r['req_quest'] : '';
        $cp = isset($r['req_camp']) ? (string)$r['req_camp'] : '';
        $en = (isset($r['enabled']) && (int)$r['enabled'] === 0) ? 0 : 1;
        echo '<tr><td><input name="tele_label[]" value="' . gm_h(isset($r['label']) ? $r['label'] : '') . '" maxlength="64"></td>';
        echo '<td><input type="number" name="tele_dtx[]" value="' . $dtxv . '"></td>';
        echo '<td><input type="number" name="tele_dty[]" value="' . $dtyv . '"></td>';
        echo '<td><input name="tele_cost[]" value="' . gm_h(isset($r['cost_silver']) ? $r['cost_silver'] : '') . '" placeholder="0"></td>';
        echo '<td><input type="number" name="tele_sort[]" value="' . $sortv . '"></td>';
        if ($hasCond) {
            echo '<td><input type="number" name="tele_min_lv[]" min="0" value="' . $lv . '" placeholder="0"></td>';
            echo '<td><input type="number" name="tele_req_quest[]" min="0" value="' . $qs . '" placeholder="0"></td>';
            echo '<td><select name="tele_req_camp[]"><option value=""' . ($cp === '' ? ' selected' : '') . '>不限</option>';
            echo '<option value="阐教"' . ($cp === '阐教' ? ' selected' : '') . '>阐教</option>';
            echo '<option value="截教"' . ($cp === '截教' ? ' selected' : '') . '>截教</option></select></td>';
            echo '<td><select name="tele_enabled[]"><option value="1"' . ($en === 1 ? ' selected' : '') . '>开</option>';
            echo '<option value="0"' . ($en === 0 ? ' selected' : '') . '>关</option></select></td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></div>';
    echo '<p class="muted"><button type="button" class="btn small js-add-tele-row">再加一个传送点</button></p></div>';

    echo '<div class="wide form-actions"><button class="btn primary">保存 NPC</button>';
    if ($editNpc) echo ' <a class="btn" href="' . gm_h($keep) . '">取消编辑</a>';
    echo '</div></form></div>';
}

/**
 * 校验物品使用效果字段。
 * 返回空字符串表示通过；返回中文错误信息表示配置不合法。
 * PHP 5.6 兼容。
 */
function gm_validate_item_effect_fields($fields)
{
    $type = isset($fields['effect_type']) ? trim((string)$fields['effect_type']) : '';
    $x = isset($fields['effect_x']) && $fields['effect_x'] !== null ? (int)$fields['effect_x'] : 0;
    $y = isset($fields['effect_y']) && $fields['effect_y'] !== null ? (int)$fields['effect_y'] : 0;
    $value = isset($fields['effect_value']) ? trim((string)$fields['effect_value']) : '';
    $json = isset($fields['use_effect']) ? trim((string)$fields['use_effect']) : '';

    if ($type === 'bag_capacity') {
        if ($x <= 0) return '背包扩容效果的参数 X 必须填写大于 0 的整数。';
    } elseif ($type === 'item_hp') {
        if ($x <= 0) return '永久增加生命上限的参数 X 必须填写大于 0 的整数。';
    } elseif ($type === 'learn_skill') {
        if ($x <= 0) return '学习技能效果的参数 X 必须填写有效技能编号。';
    } elseif ($type === 'title') {
        if ($value === '' || !is_numeric($value) || (int)$value <= 0) {
            return '称号效果必须在“效果数值”中填写有效的称号编号。';
        }
    } elseif ($type === 'heal') {
        if ($x < 0 || $y < 0 || ($x <= 0 && $y <= 0)) {
            return '回复效果至少填写一个大于 0 的数值：X 为生命，Y 为内力。';
        }
    }

    if (in_array($type, array('stat_bonus', 'add_hp', 'gift'), true)) {
        if ($json === '') return '该效果类型必须填写使用效果 JSON。';
        $decoded = json_decode($json, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
            return '使用效果 JSON 格式不正确，请使用英文双引号并填写 JSON 对象或数组。';
        }
    }

    return '';
}
