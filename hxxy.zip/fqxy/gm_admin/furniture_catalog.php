<?php
/** 住宅家具定义管理：家具数据和每级属性均写入 xy_furniture_* 数据库表。 */
require_once __DIR__ . '/bootstrap.php';
gm_require_login();
$required=array('xy_furniture_def','xy_furniture_room','xy_furniture_attr','xy_house_room_def','xy_house_slot_def');
$missing=array(); foreach($required as $t) if(!gm_table_exists($t)) $missing[]=$t;
$message=''; $messageType='success';
function gm_furn_safe_code($v){$v=trim((string)$v);return preg_match('/^[A-Za-z0-9_-]{2,50}$/',$v)?$v:'';}
function gm_furn_attr_text($rows){$out=array();foreach($rows as $r)$out[]=(int)$r['level'].'|'.$r['attr_key'].'|'.$r['attr_value'].'|'.$r['value_type'];return implode("\n",$out);}
if(!$missing && $_SERVER['REQUEST_METHOD']==='POST'){
    if(!gm_token_valid()){$message='页面验证已过期，请刷新后重试。';$messageType='error';}
    elseif(!gm_can_write()){$message='当前 GM 账号只有查看权限。';$messageType='error';}
    else{
        $id=isset($_POST['id'])?(int)$_POST['id']:0;$code=gm_furn_safe_code(isset($_POST['code'])?$_POST['code']:'');$name=trim(isset($_POST['name'])?$_POST['name']:'');$category=trim(isset($_POST['category'])?$_POST['category']:'');$description=trim(isset($_POST['description'])?$_POST['description']:'');$price=isset($_POST['base_price'])?trim((string)$_POST['base_price']):'';$currency=isset($_POST['currency'])?(string)$_POST['currency']:'silver';$maxLevel=isset($_POST['max_level'])?(int)$_POST['max_level']:1;$sort=isset($_POST['sort_order'])?(int)$_POST['sort_order']:0;$enabled=!empty($_POST['enabled'])?1:0;$rooms=isset($_POST['rooms'])&&is_array($_POST['rooms'])?$_POST['rooms']:array();$attrs=isset($_POST['attrs'])?(string)$_POST['attrs']:'';$error='';
        if($code==='')$error='家具编号只能使用英文字母、数字、下划线或短横线。';
        elseif($name==='')$error='家具名称不能为空。';
        elseif(!preg_match('/^[A-Za-z0-9_-]{2,40}$/',$category))$error='家具分类必须选择与摆放位置相同的类别。';
        elseif($price===''||!is_numeric($price)||(float)$price<0||(float)$price>999999999999999)$error='家具基础价格无效。';
        elseif(!in_array($currency,array('silver','goldbean'),true))$error='货币只能选择银两或金豆。';
        elseif($maxLevel<1||$maxLevel>20)$error='家具最高等级必须为 1 到 20 级。';
        $validRooms=array();foreach($rooms as $roomCode){$roomCode=preg_replace('/[^a-z0-9_]/i','',(string)$roomCode);$r=gm_one('SELECT room_code FROM xy_house_room_def WHERE room_code=? AND enabled=1 LIMIT 1','s',array($roomCode));if($r)$validRooms[$roomCode]=1;}
        if($error===''&&!$validRooms)$error='至少选择一个允许摆放的房间。';
        if($error==='' && $validRooms){
            $hasCompatibleSlot=false;
            foreach(array_keys($validRooms) as $roomCode){
                $slotMatch=gm_one("SELECT id FROM xy_house_slot_def WHERE room_code=? AND enabled=1 AND (furniture_category='' OR furniture_category=?) LIMIT 1",'ss',array($roomCode,$category));
                if($slotMatch){$hasCompatibleSlot=true;break;}
            }
            if(!$hasCompatibleSlot)$error='家具分类与所选房间的摆放位置不匹配，请重新选择分类或房间。';
        }
        $attrRows=array();$lines=preg_split('/\r?\n/',$attrs);$allowedKeys=array('hp','mp','atk','def','matk','speed','crit_rate','crit_dmg','dodge_rate','hit_rate','crit_resist','lifesteal','atk_ice','atk_fire','atk_thunder','def_ice','def_fire','def_thunder','ind_atk','ind_def');$seen=array();
        foreach($lines as $lineNo=>$line){$line=trim($line);if($line==='')continue;$parts=explode('|',$line);if(count($parts)!==4){$error='第 '.($lineNo+1).' 行属性格式错误，应为：等级|属性键|数值|flat/percent';break;}$lv=(int)trim($parts[0]);$key=trim($parts[1]);$value=trim($parts[2]);$valueType=trim($parts[3]);if($lv<1||$lv>$maxLevel||!in_array($key,$allowedKeys,true)||!is_numeric($value)||(float)$value<0||!in_array($valueType,array('flat','percent'),true)){$error='第 '.($lineNo+1).' 行属性值无效，请检查等级、属性键、数值和类型。';break;}$sig=$lv.'|'.$key;if(isset($seen[$sig])){$error='属性等级和属性键不能重复：'.$sig;break;}$seen[$sig]=1;$attrRows[]=array($lv,$key,(float)$value,$valueType);}
        if($error===''){
            $db=gm_db();$db->begin_transaction();
            if($id>0){$ok=gm_exec('UPDATE xy_furniture_def SET code=?,name=?,category=?,description=?,base_price=?,currency=?,max_level=?,enabled=?,sort_order=? WHERE id=?','ssssdsiiii',array($code,$name,$category,$description,(float)$price,$currency,$maxLevel,$enabled,$sort,$id));$furnitureId=$id;}
            else{$ok=gm_exec('INSERT INTO xy_furniture_def (code,name,category,description,base_price,currency,max_level,enabled,sort_order) VALUES (?,?,?,?,?,?,?,?,?)','ssssdsiii',array($code,$name,$category,$description,(float)$price,$currency,$maxLevel,$enabled,$sort));$furnitureId=(int)$db->insert_id;}
            if($ok===false||$furnitureId<=0){$db->rollback();$error='保存家具定义失败，可能是家具编号重复：'.$db->error;}
            else{
                gm_exec('DELETE FROM xy_furniture_room WHERE furniture_id=?','i',array($furnitureId));gm_exec('DELETE FROM xy_furniture_attr WHERE furniture_id=?','i',array($furnitureId));$writeOk=true;
                foreach(array_keys($validRooms) as $roomCode)if(gm_exec('INSERT INTO xy_furniture_room (furniture_id,room_code) VALUES (?,?)','is',array($furnitureId,$roomCode))===false)$writeOk=false;
                foreach($attrRows as $a)if(gm_exec('INSERT INTO xy_furniture_attr (furniture_id,level,attr_key,attr_value,value_type) VALUES (?,?,?,?,?)','iisds',array($furnitureId,$a[0],$a[1],$a[2],$a[3]))===false)$writeOk=false;
                if(!$writeOk){$db->rollback();$error='家具的房间或等级属性保存失败，已回滚。';}
                else{$db->commit();$message='家具定义已保存。';gm_log('furniture_def_save','家具 '.$furnitureId,$name.' / '.$code);}
            }
        }
        if($error!==''){$message=$error;$messageType='error';}
    }
}
$editId=isset($_GET['edit'])?(int)$_GET['edit']:0;$edit=$editId>0?gm_one('SELECT * FROM xy_furniture_def WHERE id=?','i',array($editId)):null;
$rooms=gm_rows('SELECT room_code,room_name FROM xy_house_room_def WHERE enabled=1 ORDER BY sort_order','',array());$categories=gm_rows("SELECT DISTINCT furniture_category FROM xy_house_slot_def WHERE enabled=1 AND furniture_category<>'' ORDER BY furniture_category",'',array());$selectedRooms=array();$attrText='';
if($edit){foreach(gm_rows('SELECT room_code FROM xy_furniture_room WHERE furniture_id=?','i',array($editId)) as $r)$selectedRooms[$r['room_code']]=1;$attrText=gm_furn_attr_text(gm_rows('SELECT level,attr_key,attr_value,value_type FROM xy_furniture_attr WHERE furniture_id=? ORDER BY level,attr_key','i',array($editId)));}
$defs=gm_rows('SELECT fd.*, (SELECT COUNT(*) FROM xy_player_furniture pf WHERE pf.furniture_id=fd.id) AS owned_count FROM xy_furniture_def fd ORDER BY fd.sort_order,fd.id','',array());
?><!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>家具定义管理</title><link rel="stylesheet" href="assets/gm.css"></head><body><div class="app-shell"><main class="main-area"><header class="topbar"><div><div class="eyebrow">HOUSE FURNITURE CATALOG</div><h1>住宅家具定义管理</h1></div><div class="top-user"><a class="text-link" href="house_instances.php">返回官宅管理</a></div></header>
<?php if($message!==''):?><div class="notice <?php echo $messageType==='success'?'success':'error';?>"><?php echo gm_h($message);?></div><?php endif;?>
<?php if($missing):?><div class="notice error">缺少住宅家具数据表：<?php echo gm_h(implode('、',$missing));?>。请先完成住宅系统第一至第四阶段安装。</div><?php else:?>
<div class="panel"><div class="panel-head"><h2><?php echo $edit?'编辑家具':'新增家具';?></h2><span class="muted">商品、适用房间和每级属性全部保存在数据库</span></div>
<form method="post" class="form-grid"><?php echo gm_token_field();?><input type="hidden" name="id" value="<?php echo $edit?(int)$edit['id']:0;?>">
<div class="field"><label>家具编号（唯一英文代码）</label><input name="code" required maxlength="50" value="<?php echo gm_h($edit?$edit['code']:'');?>" placeholder="例如 hall_table_01"></div>
<div class="field"><label>家具名称</label><input name="name" required maxlength="100" value="<?php echo gm_h($edit?$edit['name']:'');?>"></div>
<div class="field"><label>家具分类（必须对应摆放位置）</label><select name="category" required><option value="">请选择分类</option><?php $categoryNames=array('table'=>'桌类','wall'=>'墙面装饰','display'=>'展示陈列','weapon_rack'=>'兵器架','training'=>'训练设施','desk'=>'桌台','decoration'=>'装饰','fishing'=>'钓具','bed'=>'床具','shelf'=>'货架','furnace'=>'炼丹炉','bookshelf'=>'书架','bath'=>'浴具','screen'=>'屏风');$hasCurrent=false;foreach($categories as $cat){$code=$cat['furniture_category'];$sel=$edit&&$edit['category']===$code?'selected':'';if($sel)$hasCurrent=true;$label=isset($categoryNames[$code])?$categoryNames[$code]:$code;?><option value="<?php echo gm_h($code);?>" <?php echo $sel;?>><?php echo gm_h($label.'（'.$code.'）');?></option><?php }if($edit&&!$hasCurrent):?><option value="<?php echo gm_h($edit['category']);?>" selected><?php echo gm_h($edit['category']);?>（现有分类）</option><?php endif;?></select></div>
<div class="field"><label>基础价格</label><input name="base_price" type="number" min="0" step="1" required value="<?php echo $edit?gm_h($edit['base_price']):'0';?>"></div>
<div class="field"><label>货币</label><select name="currency"><option value="silver" <?php echo !$edit||$edit['currency']==='silver'?'selected':'';?>>银两</option><option value="goldbean" <?php echo $edit&&$edit['currency']==='goldbean'?'selected':'';?>>金豆</option></select></div>
<div class="field"><label>最高等级（1-20）</label><input name="max_level" type="number" min="1" max="20" required value="<?php echo $edit?(int)$edit['max_level']:1;?>"></div>
<div class="field"><label>排序</label><input name="sort_order" type="number" value="<?php echo $edit?(int)$edit['sort_order']:0;?>"></div>
<div class="field"><label><input type="checkbox" name="enabled" value="1" <?php echo !$edit||(int)$edit['enabled']===1?'checked':'';?>> 启用并允许管家出售</label></div>
<div class="field full"><label>说明</label><textarea name="description" rows="2"><?php echo gm_h($edit?$edit['description']:'');?></textarea></div>
<div class="field full"><label>允许摆放的房间</label><div class="checkbox-grid"><?php foreach($rooms as $r):?><label><input type="checkbox" name="rooms[]" value="<?php echo gm_h($r['room_code']);?>" <?php echo isset($selectedRooms[$r['room_code']])?'checked':'';?>> <?php echo gm_h($r['room_name']);?> <small><?php echo gm_h($r['room_code']);?></small></label><?php endforeach;?></div></div>
<div class="field full"><label>各等级属性（每行一条：等级|属性键|数值|flat/percent）</label><textarea name="attrs" rows="8" placeholder="1|hp|500|flat&#10;1|atk|80|flat&#10;2|hp|1000|flat&#10;2|atk|150|flat"><?php echo gm_h($attrText);?></textarea><small>属性键：hp、mp、atk、def、matk、speed、crit_rate、crit_dmg、dodge_rate、hit_rate、crit_resist、lifesteal、atk_ice、atk_fire、atk_thunder、def_ice、def_fire、def_thunder、ind_atk、ind_def。百分比类型会按玩家现有基础属性计算。</small></div>
<div class="field full"><button class="btn primary" type="submit">保存家具定义</button> <?php if($edit):?><a class="btn" href="furniture_catalog.php">新增另一件家具</a><?php endif;?></div></form></div>
<div class="panel"><div class="panel-head"><h2>家具目录</h2><span class="muted">停用家具不会从玩家已有家具中删除</span></div><div class="table-wrap"><table><thead><tr><th>ID</th><th>家具</th><th>分类</th><th>基础价格</th><th>等级</th><th>玩家拥有</th><th>状态</th><th>操作</th></tr></thead><tbody><?php foreach($defs as $d):?><tr><td><?php echo (int)$d['id'];?></td><td><?php echo gm_h($d['name']);?><br><small><?php echo gm_h($d['code']);?></small></td><td><?php echo gm_h($d['category']);?></td><td><?php echo gm_h($d['base_price'].' '.($d['currency']==='silver'?'银两':'金豆'));?></td><td><?php echo (int)$d['max_level'];?></td><td><?php echo (int)$d['owned_count'];?></td><td><?php echo (int)$d['enabled']?'启用':'停用';?></td><td><a class="text-link" href="furniture_catalog.php?edit=<?php echo (int)$d['id'];?>">编辑</a></td></tr><?php endforeach;?></tbody></table></div></div>
<?php endif;?><footer class="footer">家具定义仅保存在 xy_furniture_* 数据库表；家具属性只会在家具实际摆放后生效。</footer></main></div></body></html>
