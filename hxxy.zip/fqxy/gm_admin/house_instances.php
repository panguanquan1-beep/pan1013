<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/**
 * 官宅地点管理（Phase 4）
 * 仅管理官宅实例；民宅/豪宅由开封广场房屋管理员直接售卖，不在此创建。
 * 地图选项直接读取 fqxy/map/map_file_map.php 与 map/data/*.php，避免数据库导入不完整导致地点缺失。
 */
require_once __DIR__ . '/bootstrap.php';
gm_require_login();

function gm_ho_maps()
{
    static $maps = null;
    if ($maps !== null) return $maps;
    $maps = array();
    $root = dirname(__DIR__) . '/map';
    $mapFile = $root . '/map_file_map.php';
    if (!DbIniStore::isFile($mapFile)) return $maps;
    $mapKeys = include $mapFile;
    if (!is_array($mapKeys)) return $maps;
    foreach ($mapKeys as $dtx => $key) {
        $f = $root . '/data/' . basename($key) . '.php';
        if (!DbIniStore::isFile($f)) continue;
        $places = include $f;
        if (!is_array($places) || !$places) continue;
        $first = reset($places);
        $zoneName = is_array($first) && isset($first['name']) ? (string)$first['name'] : (string)$key;
        $mapPlaces = array();
        foreach ($places as $dty => $loc) {
            if (!is_array($loc) || !isset($loc['name'])) continue;
            $mapPlaces[(int)$dty] = array('name'=>(string)$loc['name'],'data'=>$loc);
        }
        if ($mapPlaces) $maps[(int)$dtx] = array('key'=>(string)$key,'name'=>$zoneName,'places'=>$mapPlaces);
    }
    return $maps;
}
function gm_ho_ensure_location($dtx, $dty, $zone, $place)
{
    if (!gm_table_exists('map_zone') || !gm_table_exists('map_loc')) return false;
    // 地图数据库中已有地点时绝不覆盖其描述、出口或编辑器内容。
    $existingLoc = gm_one('SELECT dty FROM map_loc WHERE dtx=? AND dty=? LIMIT 1', 'ii', array((int)$dtx,(int)$dty));
    $existingZone = gm_one('SELECT dtx FROM map_zone WHERE dtx=? LIMIT 1', 'i', array((int)$dtx));
    if (!$existingZone) {
        $key = (string)$zone['key']; $zoneName = (string)$zone['name'];
        if (gm_exec('INSERT INTO map_zone (dtx,map_key,name) VALUES (?,?,?)', 'iss', array((int)$dtx,$key,$zoneName)) === false) return false;
    }
    if ($existingLoc) return true;
    $data = isset($place['data']) && is_array($place['data']) ? $place['data'] : array();
    $name = (string)$place['name'];
    $desc = isset($data['desc']) ? (string)$data['desc'] : null;
    $monster = isset($data['gw']) && $data['gw'] !== '' ? (string)$data['gw'] : null;
    $before = isset($data['include_before']) && $data['include_before'] !== '' ? (string)$data['include_before'] : null;
    return gm_exec('INSERT INTO map_loc (dtx,dty,name,descr,monster_inc,include_before) VALUES (?,?,?,?,?,?)', 'iissss', array((int)$dtx,(int)$dty,$name,$desc,$monster,$before)) !== false;
}
function gm_ho_default_def()
{
    $r = gm_one("SELECT id FROM xy_house_def WHERE house_type='official' AND enabled=1 ORDER BY CASE WHEN code='system_official' THEN 0 ELSE 1 END,id LIMIT 1", '', array());
    if ($r) return (int)$r['id'];
    $ok = gm_exec("INSERT INTO xy_house_def (code,name,house_type,description,base_price,currency,max_furniture,enabled,sort_order) VALUES ('system_official','官宅','official','由 GM 官宅地点编辑器创建',0,'goldbean',30,1,30)", '', array());
    return $ok === false ? 0 : (int)gm_db()->insert_id;
}
function gm_ho_safe_code($code)
{
    $code = trim((string)$code);
    if ($code === '') $code = 'official_' . date('YmdHis') . '_' . mt_rand(100,999);
    return preg_match('/^[A-Za-z0-9_-]{2,50}$/', $code) ? $code : '';
}
function gm_ho_money($v)
{
    $v = trim((string)$v);
    if ($v === '' || !is_numeric($v)) return -1;
    $n = (float)$v;
    if ($n < 0 || $n > 999999999999999) return -1;
    return $n;
}

$required = array('xy_house_def','xy_house_instance','xy_player_house','map_zone','map_loc');
$missing = array();
foreach ($required as $t) if (!gm_table_exists($t)) $missing[] = $t;
$cols = gm_table_exists('xy_house_instance') ? gm_columns('xy_house_instance') : array();
if (!isset($cols['sale_price']) || !isset($cols['sale_currency'])) $missing[] = '第四阶段售价字段（请先运行 house_phase4_install.php）';
$message = '';
$messageType = 'success';
$canWrite = gm_can_write();
$maps = gm_ho_maps();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$missing) {
    if (!gm_token_valid()) {
        $message = '页面验证已过期，请刷新后重试。'; $messageType = 'error';
    } elseif (!$canWrite) {
        $message = '当前 GM 账号只有查看权限。'; $messageType = 'error';
    } else {
        $action = isset($_POST['action']) ? (string)$_POST['action'] : '';
        if ($action === 'save_official') {
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            $code = gm_ho_safe_code(isset($_POST['instance_code']) ? $_POST['instance_code'] : '');
            $name = gm_clean_text(isset($_POST['house_name']) ? $_POST['house_name'] : '', 100);
            $dtx = isset($_POST['world_map_code']) ? (int)$_POST['world_map_code'] : -1;
            $dty = isset($_POST['location_code']) ? (int)$_POST['location_code'] : -1;
            $price = gm_ho_money(isset($_POST['sale_price']) ? $_POST['sale_price'] : '');
            $currency = isset($_POST['sale_currency']) && in_array($_POST['sale_currency'], array('silver','goldbean'), true) ? $_POST['sale_currency'] : 'goldbean';
            $access = isset($_POST['access_mode']) && in_array($_POST['access_mode'], array('public','friends','private'), true) ? $_POST['access_mode'] : 'public';
            $entryEnabled = !empty($_POST['entry_enabled']) ? 1 : 0;
            $zone = isset($maps[$dtx]) ? $maps[$dtx] : null;
            $place = ($zone && isset($zone['places'][$dty])) ? $zone['places'][$dty] : null;
            $defaultDefId = gm_ho_default_def();
            $edit = $id > 0 ? gm_one("SELECT hi.id,hi.house_def_id,hd.house_type FROM xy_house_instance hi JOIN xy_house_def hd ON hd.id=hi.house_def_id WHERE hi.id=? LIMIT 1", 'i', array($id)) : null;
            if ($code === '') { $message = '官宅编号只能使用英文字母、数字、下划线或短横线。'; $messageType = 'error'; }
            elseif ($name === '') { $message = '请填写官宅名称。'; $messageType = 'error'; }
            elseif (!$zone || !$place) { $message = '所选地图区域或地点不存在，请重新选择。'; $messageType = 'error'; }
            elseif ($price < 0) { $message = '官宅价格必须是大于或等于 0 的数字。'; $messageType = 'error'; }
            elseif (!$defaultDefId) { $message = '找不到官宅类别定义，请先运行第四阶段安装。'; $messageType = 'error'; }
            elseif ($id > 0 && (!$edit || $edit['house_type'] !== 'official')) { $message = '只能编辑官宅实例；民宅和豪宅不由此编辑器管理。'; $messageType = 'error'; }
            elseif (!gm_ho_ensure_location($dtx,$dty,$zone,$place)) { $message = '地图地点写入失败，请检查 map_zone / map_loc 表结构。'; $messageType = 'error'; }
            else {
                $locationName = $place['name'];
                if ($id > 0) {
                    $st = gm_db()->prepare('UPDATE xy_house_instance SET instance_code=?,house_name=?,world_map_code=?,location_code=?,location_name=?,sale_price=?,sale_currency=?,access_mode=?,entry_enabled=? WHERE id=?');
                    if ($st) {
                        $mapCode=(string)$dtx; $locCode=(string)$dty; $sale=(float)$price; $st->bind_param('sssssdssii',$code,$name,$mapCode,$locCode,$locationName,$sale,$currency,$access,$entryEnabled,$id);
                        $ok = $st->execute(); if (!$ok) $message = '保存官宅失败：' . $st->error; $st->close();
                    } else $ok = false;
                } else {
                    $status = 'available'; $mapCode=(string)$dtx; $locCode=(string)$dty; $sale=(float)$price;
                    $st = gm_db()->prepare('INSERT INTO xy_house_instance (house_def_id,instance_code,house_name,world_map_code,location_code,location_name,sale_price,sale_currency,entry_enabled,access_mode,instance_status) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
                    if ($st) {
                        $st->bind_param('isssssdsiss',$defaultDefId,$code,$name,$mapCode,$locCode,$locationName,$sale,$currency,$entryEnabled,$access,$status);
                        $ok = $st->execute(); if (!$ok) $message = '新增官宅失败：' . $st->error; $st->close();
                        if ($ok) $id=(int)gm_db()->insert_id;
                    } else { $ok=false; $message='数据库预处理失败：'.gm_db()->error; }
                }
                if (!empty($ok)) {
                    $message = $id > 0 && isset($edit['id']) ? '官宅资料已更新。' : '官宅已创建，可在开封广场房屋管理员处购买。';
                    $messageType = 'success';
                    gm_log('official_house_save','官宅 '.$id,$name.' / 地图 '.$dtx.':'.$dty.' / 售价 '.$price.' '.$currency);
                } else { if ($message==='') $message='官宅保存失败，请检查编号是否重复及数据库日志。'; $messageType='error'; }
            }
        } elseif ($action === 'toggle_official') {
            $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
            $enabled = !empty($_POST['entry_enabled']) ? 1 : 0;
            $h = gm_one("SELECT hi.id,ph.player_id FROM xy_house_instance hi JOIN xy_house_def hd ON hd.id=hi.house_def_id AND hd.house_type='official' LEFT JOIN xy_player_house ph ON ph.house_instance_id=hi.id AND ph.ownership_status='active' WHERE hi.id=?", 'i', array($id));
            if (!$h) { $message='找不到这套官宅。'; $messageType='error'; }
            elseif ($enabled===0 && !empty($h['player_id'])) { $message='这套官宅已有房主，不能关闭入口；请先由房屋管理员完成转让或处理房屋所有权。'; $messageType='error'; }
            else {
                $ok=gm_exec('UPDATE xy_house_instance SET entry_enabled=? WHERE id=?','ii',array($enabled,$id))!==false;
                $message=$ok?'官宅入口状态已更新。':'修改失败。'; $messageType=$ok?'success':'error';
                if($ok) gm_log('official_house_toggle','官宅 '.$id,'entry_enabled='.$enabled);
            }
        }
    }
}

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editInstance = null;
if ($editId > 0 && !$missing) $editInstance = gm_one("SELECT hi.*,hd.house_type FROM xy_house_instance hi JOIN xy_house_def hd ON hd.id=hi.house_def_id WHERE hi.id=? AND hd.house_type='official' LIMIT 1", 'i', array($editId));
$area = isset($_GET['area']) ? (int)$_GET['area'] : ($editInstance ? (int)$editInstance['world_map_code'] : 70);
if (!isset($maps[$area])) { reset($maps); $area = key($maps); }
$locations = isset($maps[$area]) ? $maps[$area]['places'] : array();
$instances = !$missing ? gm_rows("SELECT hi.*,ph.player_id AS owner_player_id FROM xy_house_instance hi JOIN xy_house_def hd ON hd.id=hi.house_def_id AND hd.house_type='official' LEFT JOIN xy_player_house ph ON ph.house_instance_id=hi.id AND ph.ownership_status='active' ORDER BY hi.id DESC LIMIT 300", '', array()) : array();
$user = gm_current_user();
?><!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>官宅地点管理</title><link rel="stylesheet" href="assets/gm.css"></head>
<body><div class="app-shell"><aside class="sidebar"><div class="side-brand"><span class="brand-mark small">XY</span><div><b>西游踏凌霄</b><small>独立 GM 管理系统</small></div></div><nav><a class="nav-link" href="index.php"><span class="nav-dot"></span>返回 GM 首页</a><a class="nav-link active" href="house_instances.php"><span class="nav-dot"></span>官宅地点管理</a><a class="nav-link" href="furniture_catalog.php"><span class="nav-dot"></span>家具定义管理</a></nav><div class="side-foot"><div class="admin-chip"><b><?php echo gm_h($user['username']); ?></b><small><?php echo $user['role']==='super_admin'?'超级管理员':($user['role']==='viewer'?'只读管理员':'管理人员'); ?></small></div><a class="logout-link" href="logout.php">退出登录</a></div></aside>
<main class="main-area"><header class="topbar"><div><div class="eyebrow">OFFICIAL HOUSE EDITOR</div><h1>官宅地点管理</h1></div><div class="top-user"><a class="text-link" href="furniture_catalog.php">家具定义管理</a> &nbsp; <span class="status-dot"></span><?php echo gm_h($user['username']); ?></div></header>
<?php if ($message !== ''): ?><div class="notice <?php echo gm_h($messageType); ?>"><?php echo gm_h($message); ?></div><?php endif; ?>
<?php if ($missing): ?><div class="notice warn">缺少第四阶段结构：<?php echo gm_h(implode('、',$missing)); ?>。<a href="house_phase4_install.php">运行第四阶段升级</a></div><?php else: ?>
<div class="notice">这里仅创建和编辑官宅。民宅、豪宅由开封广场的房屋管理员直接出售，不需要 GM 创建实例。当前从游戏原始地图文件读取 <?php echo count($maps); ?> 个地图区域。</div>
<div class="panel"><div class="panel-head"><h2><?php echo $editInstance?'编辑官宅':'新增官宅'; ?></h2><span class="muted">设置官宅名字、地图位置和购买价格</span></div>
<?php if ($canWrite): ?>
<form method="get" class="search-row"><input type="hidden" name="edit" value="<?php echo $editId; ?>"><label>先选地图区域<select name="area" onchange="this.form.submit()"><option value="">请选择地图区域</option><?php foreach ($maps as $dtx=>$z): ?><option value="<?php echo (int)$dtx; ?>" <?php echo (int)$dtx===$area?'selected':''; ?>><?php echo (int)$dtx; ?> - <?php echo gm_h($z['name']); ?>（<?php echo gm_h($z['key']); ?>）</option><?php endforeach; ?></select></label><noscript><button class="btn">加载地点</button></noscript></form>
<form method="post" class="form-grid"><?php echo gm_token_field(); ?><input type="hidden" name="action" value="save_official"><input type="hidden" name="id" value="<?php echo $editInstance?(int)$editInstance['id']:0; ?>">
<label>官宅编号<input name="instance_code" value="<?php echo gm_h($editInstance?$editInstance['instance_code']:''); ?>" placeholder="留空自动生成"></label>
<label>官宅名称<input name="house_name" required value="<?php echo gm_h($editInstance?$editInstance['house_name']:''); ?>" placeholder="例如：紫云府"></label>
<label>当前地图区域<input type="text" value="<?php echo (int)$area; ?> - <?php echo gm_h($maps[$area]['name']); ?>（<?php echo gm_h($maps[$area]['key']); ?>）" readonly><input type="hidden" name="world_map_code" value="<?php echo (int)$area; ?>"></label>
<label>具体地点<select name="location_code" required><?php foreach ($locations as $dty=>$loc): ?><option value="<?php echo (int)$dty; ?>" <?php echo $editInstance && (int)$editInstance['location_code']===(int)$dty?'selected':''; ?>><?php echo (int)$dty; ?> - <?php echo gm_h($loc['name']); ?></option><?php endforeach; ?></select></label>
<label>官宅售价<input type="number" name="sale_price" min="0" step="1" required value="<?php echo $editInstance?gm_h($editInstance['sale_price']):888; ?>"></label>
<label>售价货币<select name="sale_currency"><option value="goldbean" <?php echo !$editInstance||$editInstance['sale_currency']==='goldbean'?'selected':''; ?>>金豆</option><option value="silver" <?php echo $editInstance&&$editInstance['sale_currency']==='silver'?'selected':''; ?>>银两</option></select></label>
<label>访问模式<select name="access_mode"><option value="public" <?php echo !$editInstance||$editInstance['access_mode']==='public'?'selected':''; ?>>公开参观</option><option value="friends" <?php echo $editInstance&&$editInstance['access_mode']==='friends'?'selected':''; ?>>指定访客</option><option value="private" <?php echo $editInstance&&$editInstance['access_mode']==='private'?'selected':''; ?>>仅房主</option></select></label>
<label class="check"><input type="checkbox" name="entry_enabled" value="1" <?php echo !$editInstance||(int)$editInstance['entry_enabled']===1?'checked':''; ?>>显示地图入口并开放购买</label>
<div class="wide form-actions"><button class="btn primary">保存官宅</button><a class="btn" href="house_instances.php">新建官宅</a></div></form>
<?php else: ?><p class="empty">当前账号只有查看权限。</p><?php endif; ?></div>
<div class="panel"><div class="panel-head"><h2>已登记官宅</h2><span class="muted">最近 300 套；民宅和豪宅不会显示在此</span></div>
<?php if ($instances): ?><div class="table-wrap"><table><thead><tr><th>ID</th><th>官宅名称</th><th>地图位置</th><th>售价</th><th>房主</th><th>状态</th><th>操作</th></tr></thead><tbody><?php foreach ($instances as $h): ?><tr><td><?php echo (int)$h['id']; ?></td><td><?php echo gm_h($h['house_name']); ?><br><small><?php echo gm_h($h['instance_code']); ?></small></td><td><?php echo gm_h($h['location_name']); ?><br><small>dtx=<?php echo gm_h($h['world_map_code']); ?> / dty=<?php echo gm_h($h['location_code']); ?></small></td><td><?php echo gm_h($h['sale_price'].' '.($h['sale_currency']==='silver'?'银两':'金豆')); ?></td><td><?php echo $h['owner_player_id']?(int)$h['owner_player_id']:'未出售'; ?></td><td><?php echo (int)$h['entry_enabled']?'开放':'隐藏'; ?></td><td><a class="text-link" href="house_instances.php?edit=<?php echo (int)$h['id']; ?>&area=<?php echo (int)$h['world_map_code']; ?>">编辑</a> <?php if (!$h['owner_player_id']): ?><form method="post" class="inline-form"><?php echo gm_token_field(); ?><input type="hidden" name="action" value="toggle_official"><input type="hidden" name="id" value="<?php echo (int)$h['id']; ?>"><input type="hidden" name="entry_enabled" value="<?php echo (int)$h['entry_enabled']?0:1; ?>"><button class="link-button"><?php echo (int)$h['entry_enabled']?'关闭出售/入口':'开放出售/入口'; ?></button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><p class="empty">暂无官宅。使用上方表单创建第一套官宅。</p><?php endif; ?></div>
<div class="notice">官宅保存后会自动出现在所选地图地点名称下方，并出现在开封广场房屋管理员的官宅购买列表。官宅已售出后，GM 可调整名称、位置和价格，但不会通过编辑器更换房主。</div>
<?php endif; ?>
<footer class="footer">西游踏凌霄 · 官宅地点管理 · PHP 5.6</footer></main></div></body></html>
