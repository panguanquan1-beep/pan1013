<?php
/**
 * 住宅系统第四阶段结构升级：官宅编辑器 + 房屋管理员商店。
 * PHP 5.6 / MySQL 5.6 兼容；可重复运行。
 */
require_once __DIR__ . '/bootstrap.php';
gm_require_login();
if (!gm_can_write()) die('当前 GM 账号只有查看权限。');

$errors = array();
$done = array();
$required = array('xy_house_def','xy_house_instance','xy_player_house','xy_furniture_def','map_zone','map_loc','npc_def','map_npc');
foreach ($required as $t) {
    if (!gm_table_exists($t)) $errors[] = '缺少数据表：' . $t;
}
if (!$errors) {
    // 修复此前结构复核报出的家具定义缺少 base_price。
    $furnitureCols = gm_columns('xy_furniture_def');
    if (!isset($furnitureCols['base_price'])) {
        if (!gm_db()->query("ALTER TABLE xy_furniture_def ADD COLUMN base_price DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER description")) {
            $errors[] = '添加 xy_furniture_def.base_price 失败：' . gm_db()->error;
        } else $done[] = '已补齐家具定义字段 base_price';
    }

    $cols = gm_columns('xy_house_instance');
    if (!isset($cols['sale_price'])) {
        if (!gm_db()->query("ALTER TABLE xy_house_instance ADD COLUMN sale_price DECIMAL(18,2) NOT NULL DEFAULT 0 AFTER location_name")) {
            $errors[] = '添加 xy_house_instance.sale_price 失败：' . gm_db()->error;
        } else $done[] = '已添加官宅售价字段 sale_price';
    }
    $cols = gm_columns('xy_house_instance');
    if (!isset($cols['sale_currency'])) {
        if (!gm_db()->query("ALTER TABLE xy_house_instance ADD COLUMN sale_currency VARCHAR(20) NOT NULL DEFAULT 'goldbean' AFTER sale_price")) {
            $errors[] = '添加 xy_house_instance.sale_currency 失败：' . gm_db()->error;
        } else $done[] = '已添加官宅价格货币字段 sale_currency';
    }

    // 民宅、豪宅只有系统商品定义，不在 GM 官宅编辑器里创建实例。
    $seeds = array(
        array('system_residence','民宅','residence','房屋管理员出售的标准民宅',10000000,'silver',30,1,10),
        array('system_mansion','豪宅','mansion','房屋管理员出售的标准豪宅',188,'goldbean',30,1,20),
        array('system_official','官宅','official','由 GM 官宅编辑器创建地点和名称',0,'goldbean',30,1,30)
    );
    foreach ($seeds as $s) {
        $exists = gm_one('SELECT id FROM xy_house_def WHERE code=? LIMIT 1', 's', array($s[0]));
        $code=$s[0]; $name=$s[1]; $type=$s[2]; $desc=$s[3]; $price=(float)$s[4]; $currency=$s[5]; $capacity=(int)$s[6]; $enabled=(int)$s[7]; $sort=(int)$s[8];
        if (!$exists) {
            $st = gm_db()->prepare('INSERT INTO xy_house_def (code,name,house_type,description,base_price,currency,max_furniture,enabled,sort_order) VALUES (?,?,?,?,?,?,?,?,?)');
            if (!$st) { $errors[] = '创建住宅类别失败：' . gm_db()->error; continue; }
            $st->bind_param('ssssdsiii', $code,$name,$type,$desc,$price,$currency,$capacity,$enabled,$sort);
            if ($st->execute()) $done[] = '已建立系统住宅类别：' . $name;
            else $errors[] = '创建住宅类别失败：' . $st->error;
            $st->close();
        } else {
            $ok = gm_exec('UPDATE xy_house_def SET name=?,house_type=?,description=?,base_price=?,currency=?,max_furniture=?,enabled=?,sort_order=? WHERE code=?', 'sssdsiiis', array($name,$type,$desc,$price,$currency,$capacity,$enabled,$sort,$code));
            if ($ok === false) $errors[] = '更新系统住宅类别失败：' . $name;
            else $done[] = '已确认系统住宅类别配置：' . $name;
        }
    }

    // 上面只检查并补充类别定义；再次按代码确认，确保默认官宅定义存在。
    $off = gm_one("SELECT id FROM xy_house_def WHERE code='system_official' AND house_type='official' LIMIT 1", '', array());
    if (!$off) {
        $st = gm_db()->prepare("INSERT INTO xy_house_def (code,name,house_type,description,base_price,currency,max_furniture,enabled,sort_order) VALUES ('system_official','官宅','official','由 GM 官宅编辑器创建地点和名称',0,'goldbean',30,1,30)");
        if ($st && $st->execute()) $done[] = '已建立官宅统一类别';
        elseif (!$st) $errors[] = '建立官宅统一类别失败：' . gm_db()->error;
        if ($st) $st->close();
    }

    // 开封广场（dtx=70,dty=0）确保存在，以便首次导入不完整时也能放置管理员 NPC。
    gm_exec("INSERT INTO map_zone (dtx,map_key,name) VALUES (70,'kfgc','开封广场') ON DUPLICATE KEY UPDATE map_key=VALUES(map_key),name=VALUES(name)", '', array());
    gm_exec("INSERT INTO map_loc (dtx,dty,name,descr) VALUES (70,0,'开封广场','开封广场往哪里走呢？') ON DUPLICATE KEY UPDATE name=VALUES(name)", '', array());

    $npc = gm_one("SELECT id FROM npc_def WHERE legacy_id=635 AND page=174 AND name='房屋管理员' ORDER BY id LIMIT 1", '', array());
    if (!$npc) {
        $st = gm_db()->prepare("INSERT INTO npc_def (legacy_id,name,page,color) VALUES (635,'房屋管理员',174,'blue')");
        if ($st && $st->execute()) { $npc = array('id'=>(int)gm_db()->insert_id); $done[] = '已创建房屋管理员 NPC'; }
        elseif (!$st) $errors[] = '创建房屋管理员 NPC 失败：' . gm_db()->error;
        if ($st) $st->close();
    }
    if ($npc) {
        $has = gm_one('SELECT seq FROM map_npc WHERE dtx=70 AND dty=0 AND npc_id=? LIMIT 1', 'i', array((int)$npc['id']));
        if (!$has) {
            $seqRow = gm_one('SELECT COALESCE(MAX(seq),0)+1 AS n FROM map_npc WHERE dtx=70 AND dty=0', '', array());
            $seq = $seqRow ? (int)$seqRow['n'] : 1;
            $ok = gm_exec('INSERT INTO map_npc (dtx,dty,seq,npc_id,pos) VALUES (70,0,?, ?,\'below_img\')', 'ii', array($seq,(int)$npc['id']));
            if ($ok !== false) $done[] = '已将房屋管理员放到开封广场';
            else $errors[] = '添加开封广场 NPC 入口失败。';
        } else $done[] = '开封广场已存在房屋管理员入口';
    }

    // 旧官宅如未设置售价，则继承旧住宅定义售价。
    gm_exec("UPDATE xy_house_instance hi JOIN xy_house_def hd ON hd.id=hi.house_def_id SET hi.sale_price=hd.base_price,hi.sale_currency=hd.currency WHERE hd.house_type='official' AND hi.sale_price=0 AND hd.base_price>0", '', array());
}

?><!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>住宅系统第四阶段安装</title><link rel="stylesheet" href="assets/gm.css"></head>
<body><div class="app-shell"><main class="main-area"><header class="topbar"><div><div class="eyebrow">HOUSE SYSTEM PHASE 4</div><h1>住宅系统第四阶段结构升级</h1></div></header>
<?php if ($errors): ?><div class="notice error"><b>升级未完全成功：</b><br><?php echo gm_h(implode('；',$errors)); ?></div><?php else: ?><div class="notice success">第四阶段结构升级完成。</div><?php endif; ?>
<div class="panel"><div class="panel-head"><h2>执行结果</h2></div><ul><?php foreach ($done as $v): ?><li><?php echo gm_h($v); ?></li><?php endforeach; ?><?php if (!$done): ?><li>所有结构已经存在，无需重复修改。</li><?php endif; ?></ul></div>
<div class="panel"><p>升级内容：民宅/豪宅改为房屋管理员直接售卖；GM 编辑器只保留官宅；官宅可设置每套售价；开封广场添加房屋管理员 NPC。</p><a class="btn primary" href="house_instances.php">进入官宅编辑器</a> <a class="btn" href="index.php">返回 GM 首页</a></div>
<footer class="footer">请保留本安装文件；重复运行不会重复创建房屋管理员或系统住宅类别。</footer></main></div></body></html>
