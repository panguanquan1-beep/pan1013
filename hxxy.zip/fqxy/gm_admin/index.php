<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/form_helpers.php';
gm_require_login();

function gm_attr_labels()
{
    return array(
        'hp' => '生命 HP', 'mp' => '法力 MP', 'atk' => '攻击', 'def' => '防御', 'matk' => '魔攻',
        'atk_ice' => '冰攻击', 'atk_fire' => '火攻击', 'atk_thunder' => '雷攻击',
        'def_ice' => '冰防御', 'def_fire' => '火防御', 'def_thunder' => '雷防御',
        'speed' => '速度', 'crit_rate' => '暴击率', 'crit_dmg' => '暴击伤害',
        'dodge_rate' => '闪避率', 'hit_rate' => '命中率', 'crit_resist' => '抗暴率',
        'lifesteal' => '吸血', 'ind_atk' => '独立攻击', 'ind_def' => '独立防御'
    );
}

function gm_dynamic_save($table, $id, $fields, $typeMap, $idColumn)
{
    $columns = gm_columns($table);
    if (!$columns) return false;
    $data = array();
    foreach ($fields as $key => $value) {
        if ($key !== $idColumn && isset($columns[$key])) $data[$key] = $value;
    }
    if (!$data) return false;
    $types = '';
    $params = array();
    foreach ($data as $key => $value) {
        $types .= isset($typeMap[$key]) ? $typeMap[$key] : 's';
        $params[] = $value;
    }
    if ($id > 0) {
        $sets = array();
        foreach ($data as $key => $value) $sets[] = '`' . $key . '`=?';
        $params[] = (int)$id;
        $types .= 'i';
        return gm_exec('UPDATE `' . $table . '` SET ' . implode(',', $sets) . ' WHERE `' . $idColumn . '`=?', $types, $params) !== false;
    }
    $names = array();
    foreach ($data as $key => $value) $names[] = '`' . $key . '`';
    $sql = 'INSERT INTO `' . $table . '` (' . implode(',', $names) . ') VALUES (' . implode(',', array_fill(0, count($data), '?')) . ')';
    return gm_exec($sql, $types, $params) !== false;
}


function gm_player_rows($query)
{
    if (gm_table_exists('player_char')) {
        if ($query !== '') {
            $like = '%' . $query . '%';
            $rows = gm_rows("SELECT player_id,name,level,vip,menpai,silver_bag,updated_at FROM player_char WHERE CAST(player_id AS CHAR) LIKE ? OR name LIKE ? ORDER BY player_id DESC LIMIT 100", 'ss', array($like, $like));
            if (count($rows)) return $rows;
        } else {
            $rows = gm_rows('SELECT player_id,name,level,vip,menpai,silver_bag,updated_at FROM player_char ORDER BY player_id DESC LIMIT 100', '', array());
            if (count($rows)) return $rows;
        }
    }
    if (gm_table_exists('all_zt')) {
        $cols = gm_columns('all_zt');
        $id = isset($cols['wjid']) ? 'wjid' : '';
        if ($id === '') return array();
        $name = isset($cols['username']) ? 'username' : "''";
        $level = isset($cols['dj']) ? 'dj' : '0';
        $vip = isset($cols['vip']) ? 'vip' : '0';
        $sql = "SELECT `$id` AS player_id,$name AS name,$level AS level,$vip AS vip,0 AS menpai,'' AS silver_bag,NULL AS updated_at FROM all_zt";
        if ($query !== '') {
            $like = '%' . $query . '%';
            $sql .= " WHERE CAST(`$id` AS CHAR) LIKE ? OR $name LIKE ?";
            return gm_rows($sql . ' ORDER BY player_id DESC LIMIT 100', 'ss', array($like, $like));
        }
        return gm_rows($sql . ' ORDER BY player_id DESC LIMIT 100', '', array());
    }
    return array();
}

function gm_player_detail($pid)
{
    if (gm_table_exists('player_char')) {
        $r = gm_one('SELECT * FROM player_char WHERE player_id=?', 'i', array($pid));
        if ($r) return $r;
    }
    if (gm_table_exists('all_zt')) return gm_one('SELECT * FROM all_zt WHERE wjid=?', 'i', array($pid));
    return null;
}

$pageNames = array(
    'dashboard' => '总览', 'players' => '玩家管理', 'items' => '物品管理',
    'houses' => '住宅与家具', 'npcs' => 'NPC 管理', 'quests' => '任务管理',
    'drops' => '怪物属性+掉落',
    'notice' => '世界公告', 'admins' => 'GM 账号', 'logs' => '操作日志'
);
$page = isset($_GET['page']) && isset($pageNames[$_GET['page']]) ? $_GET['page'] : 'dashboard';

$user = gm_current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $returnPage = isset($_POST['return_page'], $pageNames[$_POST['return_page']]) ? $_POST['return_page'] : $page;
    if (!gm_token_valid()) {
        gm_set_flash('error', '页面验证已过期，请刷新后重试。');
        gm_redirect($returnPage);
    }
    if (!gm_can_write()) {
        gm_set_flash('error', '当前 GM 账号只有查看权限。');
        gm_redirect($returnPage);
    }
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $ok = false; $message = '操作失败，请检查输入内容及数据库表是否已安装。'; $logDetail = '';

    // 玩家操作
    if ($action === 'player_add_silver' || $action === 'player_add_exp' || $action === 'player_give_item' || $action === 'player_add_beans' || $action === 'player_add_xiyou' || $action === 'player_set_vip') {
        $pid = isset($_POST['player_id']) ? (int)$_POST['player_id'] : 0;
        if ($pid < 10000000 || !gm_player_detail($pid)) $message = '玩家 ID 不正确。';
        elseif ($action === 'player_give_item') {
            $item = (int)(isset($_POST['item_id']) ? $_POST['item_id'] : 0);
            $qty = gm_safe_int(isset($_POST['qty']) ? $_POST['qty'] : 1, 1, 999999, 1);
            require_once XYGM_ROOT . '/lib/ItemDb.php';
            $result = ItemDb::give($pid, $item, $qty, 'GM后台发放', $user['username']);
            $ok = $result !== false;
            $message = $ok ? '物品已发放到玩家背包。' : '发放失败：请确认物品定义、玩家物品表和背包数据均已初始化。';
            $logDetail = 'player=' . $pid . ', item=' . $item . ', qty=' . $qty;
        } elseif ($action === 'player_add_beans') {
            $qty = gm_safe_int(isset($_POST['amount']) ? $_POST['amount'] : 0, 1, 2000000000, 0);
            $legacyTable = 'wp' . $pid;
            if ($qty <= 0) $message = '金豆数量不正确。';
            elseif (!gm_table_exists($legacyTable)) $message = '玩家旧物品表不存在：' . $legacyTable . '。未修改数据。';
            else {
                $beanRow = gm_one('SELECT id,wpsl FROM `' . $legacyTable . '` WHERE wpid=127 ORDER BY id LIMIT 1', '', array());
                if ($beanRow) {
                    $ok = gm_exec('UPDATE `' . $legacyTable . '` SET wpsl=wpsl+? WHERE id=?', 'ii', array($qty, (int)$beanRow['id'])) !== false;
                } else {
                    $maxRow = gm_one('SELECT COALESCE(MAX(id),0) AS max_id FROM `' . $legacyTable . '`', '', array());
                    $nextId = $maxRow ? (int)$maxRow['max_id'] + 1 : 1;
                    $ok = gm_exec('INSERT INTO `' . $legacyTable . '` (id,wpid,wpsl,wpfl) VALUES (?,127,?,4)', 'ii', array($nextId, $qty)) !== false;
                }
                $message = $ok ? '金豆已增加。' : '金豆发放失败，请检查玩家物品表字段。';
                $logDetail = 'player=' . $pid . ', gold_beans +' . $qty . ' (legacy item 127)';
            }
        } elseif ($action === 'player_set_vip') {
            $vip = gm_safe_int(isset($_POST['vip']) ? $_POST['vip'] : 0, 0, 999, 0);
            $ok = gm_exec("UPDATE all_zt SET vip=? WHERE wjid=?", 'ii', array($vip, $pid)) !== false;
            if ($ok) gm_exec("UPDATE player_char SET vip=? WHERE player_id=?", 'ii', array($vip, $pid));
            $message = $ok ? '玩家 VIP 等级已设置。' : '设置 VIP 失败，请检查玩家共享角色记录。';
            $logDetail = 'player=' . $pid . ', vip=' . $vip;
        } elseif ($action === 'player_add_xiyou') {
            $amount = gm_safe_int(isset($_POST['amount']) ? $_POST['amount'] : 0, 1, 2000000000, 0);
            if ($amount <= 0) {
                $message = '西游币数量不正确。';
            } else {
                $ruyiFile = XYGM_ROOT . '/lib/RuyiDb.php';
                if (!is_file($ruyiFile)) {
                    $message = '找不到游戏核心文件 lib/RuyiDb.php。';
                } else {
                    require_once $ruyiFile;
                    $newBalance = RuyiDb::addXiyouCoin($pid, $amount);
                    $ok = ((int)RuyiDb::getXiyouCoin($pid) === (int)$newBalance);
                    $message = $ok ? ('西游币已发放，当前余额：' . (int)$newBalance) : '西游币发放失败，请检查 player_kv。';
                    $logDetail = 'player=' . $pid . ', xiyou_coin +' . $amount . ', balance=' . (int)$newBalance;
                }
            }
        } elseif ($action === 'player_add_silver') {
            $amount = gm_safe_int(isset($_POST['amount']) ? $_POST['amount'] : 0, 1, 2000000000, 0);
            if ($amount > 0) {
                require_once XYGM_ROOT . '/lib/PlayerDb.php';
                $ok = PlayerDb::addSilver($pid, $amount) === true;
                $message = $ok ? '银两已增加。' : '银两发放失败，请检查玩家角色和银两数据库记录。';
                $logDetail = 'player=' . $pid . ', silver +' . $amount;
            }
        } else {
            $amount = gm_safe_int(isset($_POST['amount']) ? $_POST['amount'] : 0, 1, 2000000000, 0);
            if ($amount > 0) {
                require_once XYGM_ROOT . '/lib/PlayerDb.php';
                $result = PlayerDb::addExp($pid, $amount);
                $ok = ($result !== false);
                $message = $ok ? '经验已增加，系统按现有升级公式处理升级。' : '经验发放失败，请检查玩家共享角色记录。';
                $logDetail = 'player=' . $pid . ', exp +' . $amount;
            }
        }
        if ($ok) gm_log($action, '玩家 ' . $pid, $logDetail);
    }

    // 物品定义
    elseif ($action === 'save_monster') {
        $mid = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
        $cols = gm_columns('monster_def');
        $fields = array('name','lv','hp','maxhp','mp','maxmp','atk','atk_min','matk','matk_min','def','def_min','mdef','ice_atk','fire_atk','thunder_atk','ice_def','fire_def','thunder_def','exp','self_heal','ind_atk','ind_def','talk');
        $data = array();
        foreach ($fields as $f) {
            if (!isset($cols[$f]) || !isset($_POST[$f])) continue;
            $data[$f] = trim((string)$_POST[$f]);
        }
        if ($mid <= 0 || !gm_one('SELECT id FROM monster_def WHERE id=?', 'i', array($mid))) $message = '怪物不存在。';
        elseif (!$data) $message = '没有可保存的怪物字段。';
        else {
            $sets = array(); $types = ''; $params = array();
            foreach ($data as $k => $v) { $sets[] = '`'.$k.'`=?'; $types .= 's'; $params[] = $v; }
            $params[] = $mid; $types .= 'i';
            $ok = gm_exec('UPDATE monster_def SET '.implode(',', $sets).' WHERE id=?', $types, $params) !== false;
            $message = $ok ? '怪物属性已保存。' : '怪物属性保存失败。';
            if ($ok) gm_log('save_monster', '怪物 '.$mid, isset($data['name']) ? $data['name'] : '');
            $redirEdit = $mid;
        }
    } elseif ($action === 'add_drop') {
        $npc = (int)(isset($_POST['npc_id']) ? $_POST['npc_id'] : 0);
        $item = (int)(isset($_POST['item_id']) ? $_POST['item_id'] : 0);
        $qty = max(1, (int)(isset($_POST['qty']) ? $_POST['qty'] : 1));
        $cn = max(1, (int)(isset($_POST['chance_num']) ? $_POST['chance_num'] : 1));
        $cd = max(1, (int)(isset($_POST['chance_den']) ? $_POST['chance_den'] : 1));
        if ($npc > 0 && $item > 0 && gm_one('SELECT id FROM monster_def WHERE id=?', 'i', array($npc)) && gm_one('SELECT id FROM item_def WHERE id=?', 'i', array($item))) {
            $ok = gm_exec("INSERT INTO monster_drop (npc_id,item_id,qty,chance_num,chance_den) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE qty=VALUES(qty), chance_num=VALUES(chance_num), chance_den=VALUES(chance_den)", 'iiiii', array($npc, $item, $qty, $cn, $cd)) !== false;
            $message = $ok ? '掉落已保存' : ('保存失败：' . gm_last_db_error());
            if ($ok) gm_log('add_drop', '怪物'.$npc, '物品'.$item.' qty='.$qty.' '.$cn.'/'.$cd);
            $redirEdit = $npc;
        } else {
            $message = '怪物或物品不存在。';
        }
    } elseif ($action === 'del_monster_drop') {
        $npc = (int)(isset($_POST['npc_id']) ? $_POST['npc_id'] : 0);
        $item = (int)(isset($_POST['item_id']) ? $_POST['item_id'] : 0);
        if ($npc > 0 && $item > 0) {
            $ok = gm_exec('DELETE FROM monster_drop WHERE npc_id=? AND item_id=?', 'ii', array($npc, $item)) !== false;
            $message = $ok ? '掉落已删除' : '删除失败';
            if ($ok) gm_log('del_drop', '怪物'.$npc, '物品'.$item);
            $redirEdit = $npc;
        } else $message = '参数不正确。';
    } elseif ($action === 'save_item') {
        if (!gm_table_exists('item_def')) $message = '找不到 item_def。请先完成新物品系统数据库迁移。';
        else {
            $id = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
            if ($id <= 0 && isset($_POST['new_id']) && trim((string)$_POST['new_id']) !== '') $id = (int)$_POST['new_id'];
            list($fields, $types) = gm_item_fields_from_post();
            $effectValidationError = gm_validate_item_effect_fields($fields);
            if (empty($fields['name']) || empty($fields['category_id'])) $message = '物品名称和分类不能为空。';
            elseif ($effectValidationError !== '') $message = $effectValidationError;
            else {
                $postedId = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
                $exists = ($id > 0) ? gm_one('SELECT id FROM item_def WHERE id=?','i',array($id)) : null;
                if ($postedId > 0 && !$exists) {
                    $message = '要编辑的物品不存在。';
                } elseif ($postedId <= 0 && $id > 0 && $exists) {
                    $message = '物品 ID '.$id.' 已存在，请换一个编号。';
                } else {
                    $ok = gm_save_row('item_def', $id, $fields, $types, 'id');
                    if ($ok) {
                        if ($id <= 0) $id = (int)gm_db()->insert_id;
                        $redirEdit = $id;
                        $message = ($postedId > 0) ? '物品定义已更新。' : '物品定义已添加。';
                        gm_log('save_item', '物品 ' . $id, isset($fields['name']) ? $fields['name'] : '');
                    } else {
                        $dbError = function_exists('gm_last_db_error') ? gm_last_db_error() : '';
                        $message = '物品保存失败。' . ($dbError !== '' ? '数据库提示：' . $dbError : '请检查 item_def 字段、字段约束及迁移版本。');
                    }
                }
            }
        }
    } elseif ($action === 'toggle_item') {
        $id = (int)(isset($_POST['id']) ? $_POST['id'] : 0); $enabled = !empty($_POST['enabled']) ? 1 : 0;
        $ok = gm_exec('UPDATE item_def SET enabled=? WHERE id=?', 'ii', array($enabled, $id)) !== false;
        $message = $ok ? '物品状态已修改。' : $message;
        if ($ok) gm_log('toggle_item', '物品 ' . $id, 'enabled=' . $enabled);
    } elseif ($action === 'delete_item') {
        $id = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
        $used = gm_table_exists('player_item') ? gm_one('SELECT COUNT(*) AS n FROM player_item WHERE item_id=?', 'i', array($id)) : array('n'=>0);
        if ($used && (int)$used['n'] > 0) $message = '该物品仍有玩家持有，不能删除。请停用物品，避免破坏玩家数据。';
        elseif (gm_exec('DELETE FROM item_def WHERE id=?', 'i', array($id)) !== false) { $ok = true; $message = '物品定义已删除。'; gm_log('delete_item', '物品 ' . $id, '删除物品定义'); }
    } elseif ($action === 'save_item_attr') {
        $iid = (int)(isset($_POST['item_id']) ? $_POST['item_id'] : 0);
        $key = isset($_POST['attr_key']) ? $_POST['attr_key'] : '';
        $allowed = gm_attr_labels(); $min = isset($_POST['min_val']) ? (int)$_POST['min_val'] : 0; $max = isset($_POST['max_val']) ? (int)$_POST['max_val'] : 0;
        if (!isset($allowed[$key]) || !gm_table_exists('item_attr')) $message = '物品属性表不存在，或属性类型不合法。';
        elseif ($iid <= 0 || !gm_table_exists('item_def') || !gm_one('SELECT id FROM item_def WHERE id=?', 'i', array($iid))) $message = '物品不存在。';
        elseif ($min > $max) $message = '属性最小值不能大于最大值。';
        else {
            $exists = gm_one('SELECT item_id FROM item_attr WHERE item_id=? AND attr_key=?', 'is', array($iid, $key));
            $ok = $exists ? gm_exec('UPDATE item_attr SET min_val=?,max_val=? WHERE item_id=? AND attr_key=?', 'iiis', array($min,$max,$iid,$key)) !== false
                          : gm_exec('INSERT INTO item_attr (item_id,attr_key,min_val,max_val) VALUES (?,?,?,?)', 'isii', array($iid,$key,$min,$max)) !== false;
            $message = $ok ? '物品属性已保存。' : '属性保存失败。';
            if ($ok) { $redirEdit=$iid; gm_log('save_item_attr', '物品 ' . $iid, $key . ':' . $min . '-' . $max); }
        }
    }

    // 房屋与家具定义
    elseif ($action === 'save_house') {
        $id = (int)(isset($_POST['id']) ? $_POST['id'] : 0);
        $code = gm_clean_text(isset($_POST['code']) ? $_POST['code'] : '', 50);
        $name = gm_clean_text(isset($_POST['name']) ? $_POST['name'] : '', 100);
        $type = isset($_POST['house_type']) && in_array($_POST['house_type'], array('residence','mansion','official')) ? $_POST['house_type'] : 'residence';
        if (!preg_match('/^[A-Za-z0-9_-]{2,50}$/', $code) || $name === '') $message = '住宅编号仅允许英文、数字、下划线和横线，名称不能为空。';
        else {
            $fields = array('code'=>$code,'name'=>$name,'house_type'=>$type,'level_req'=>gm_safe_int(isset($_POST['level_req'])?$_POST['level_req']:1,1,9999,1),'max_rooms'=>gm_safe_int(isset($_POST['max_rooms'])?$_POST['max_rooms']:1,1,999,1),'max_furniture'=>gm_safe_int(isset($_POST['max_furniture'])?$_POST['max_furniture']:0,0,99999,0),'base_price'=>max(0,(float)(isset($_POST['base_price'])?$_POST['base_price']:0)),'currency'=>gm_clean_text(isset($_POST['currency'])?$_POST['currency']:'silver',20),'enabled'=>!empty($_POST['enabled'])?1:0,'sort'=>(int)(isset($_POST['sort'])?$_POST['sort']:0));
            $ok = gm_dynamic_save('xy_house_def',$id,$fields,array('level_req'=>'i','max_rooms'=>'i','max_furniture'=>'i','base_price'=>'d','enabled'=>'i','sort'=>'i'),'id');
            $message = $ok ? ($id ? '住宅定义已更新。' : '住宅已添加。') : '住宅保存失败，编号可能重复。';
            if ($ok) gm_log('save_house','住宅 ' . $id,$name . ' / ' . $type);
        }
    } elseif ($action === 'toggle_house') {
        $id=(int)$_POST['id']; $enabled=!empty($_POST['enabled'])?1:0;
        $ok=gm_exec('UPDATE xy_house_def SET enabled=? WHERE id=?','ii',array($enabled,$id))!==false;
        $message=$ok?'住宅状态已修改。':$message; if($ok) gm_log('toggle_house','住宅 '.$id,'enabled='.$enabled);
    } elseif ($action === 'delete_house') {
        $id=(int)$_POST['id']; $used=gm_one('SELECT COUNT(*) AS n FROM xy_player_house WHERE house_id=?','i',array($id));
        if($used && (int)$used['n']>0) $message='该住宅已有玩家持有，不能删除。请停用住宅。';
        elseif(gm_exec('DELETE FROM xy_house_def WHERE id=?','i',array($id))!==false){$ok=true;$message='住宅定义已删除。';gm_log('delete_house','住宅 '.$id,'删除住宅定义');}
    } elseif ($action === 'save_furniture') {
        $id=(int)(isset($_POST['id'])?$_POST['id']:0); $code=gm_clean_text(isset($_POST['code'])?$_POST['code']:'',50); $name=gm_clean_text(isset($_POST['name'])?$_POST['name']:'',100);
        if(!preg_match('/^[A-Za-z0-9_-]{2,50}$/',$code)||$name==='') $message='家具编号格式错误或名称为空。';
        else {
            $fields=array('code'=>$code,'name'=>$name,'category'=>gm_clean_text(isset($_POST['category'])?$_POST['category']:'decoration',40),'max_level'=>gm_safe_int(isset($_POST['max_level'])?$_POST['max_level']:1,1,999,1),'base_price'=>max(0,(float)(isset($_POST['base_price'])?$_POST['base_price']:0)),'currency'=>gm_clean_text(isset($_POST['currency'])?$_POST['currency']:'silver',20),'enabled'=>!empty($_POST['enabled'])?1:0,'sort'=>(int)(isset($_POST['sort'])?$_POST['sort']:0));
            $ok=gm_dynamic_save('xy_furniture_def',$id,$fields,array('max_level'=>'i','base_price'=>'d','enabled'=>'i','sort'=>'i'),'id');
            $message=$ok?($id?'家具定义已更新。':'家具已添加。'):'家具保存失败，编号可能重复。'; if($ok) gm_log('save_furniture','家具 '.$id,$name);
        }
    } elseif ($action === 'save_furniture_attrs') {
        $fid=(int)(isset($_POST['furniture_id'])?$_POST['furniture_id']:0); $level=gm_safe_int(isset($_POST['level'])?$_POST['level']:1,1,999,1);
        $def=gm_one('SELECT id,max_level FROM xy_furniture_def WHERE id=?','i',array($fid)); $labels=gm_attr_labels();
        if(!$def || $level>(int)$def['max_level']) $message='家具不存在，或属性等级超过最高等级。';
        else {
            gm_db()->begin_transaction();
            $ok=gm_exec('DELETE FROM xy_furniture_attr WHERE furniture_id=? AND level=?','ii',array($fid,$level))!==false;
            if($ok) foreach($labels as $key=>$label){$raw=isset($_POST['attrs'][$key])?trim((string)$_POST['attrs'][$key]):'0'; if($raw===''||!is_numeric($raw)){if($raw!==''){$ok=false;break;}continue;} $v=(float)$raw; if($v!=0 && gm_exec('INSERT INTO xy_furniture_attr (furniture_id,level,attr_key,attr_value) VALUES (?,?,?,?)','iisd',array($fid,$level,$key,$v))===false){$ok=false;break;}}
            if($ok){gm_db()->commit();$message='家具第 '.$level.' 级属性已保存。';gm_log('save_furniture_attrs','家具 '.$fid,'level='.$level);}else{gm_db()->rollback();$message='家具属性保存失败，已回滚。';}
        }
    } elseif ($action === 'toggle_furniture') {
        $id=(int)$_POST['id'];$enabled=!empty($_POST['enabled'])?1:0;$ok=gm_exec('UPDATE xy_furniture_def SET enabled=? WHERE id=?','ii',array($enabled,$id))!==false;$message=$ok?'家具状态已修改。':$message;if($ok)gm_log('toggle_furniture','家具 '.$id,'enabled='.$enabled);
    } elseif ($action === 'delete_furniture') {
        $id=(int)$_POST['id'];$a=gm_one('SELECT COUNT(*) AS n FROM xy_player_furniture WHERE furniture_id=?','i',array($id));$b=gm_one('SELECT COUNT(*) AS n FROM xy_house_furniture WHERE furniture_id=?','i',array($id));
        if(($a&&(int)$a['n']>0)||($b&&(int)$b['n']>0))$message='该家具已有玩家库存或摆放记录，不能删除。请停用。';
        else {gm_db()->begin_transaction();$ok=gm_exec('DELETE FROM xy_furniture_attr WHERE furniture_id=?','i',array($id))!==false;$ok=$ok&&gm_exec('DELETE FROM xy_furniture_def WHERE id=?','i',array($id))!==false;if($ok){gm_db()->commit();$message='家具定义已删除。';gm_log('delete_furniture','家具 '.$id,'删除家具及属性');}else{gm_db()->rollback();$message='删除失败，已回滚。';}}
    }

    // NPC / 任务
    elseif ($action === 'save_npc') {
        if (!gm_table_exists('npc_def')) $message='找不到 npc_def。请先安装 NPC/地图数据表。';
        else {
            $id=(int)(isset($_POST['id'])?$_POST['id']:0);
            if ($id<=0 && isset($_POST['new_id']) && trim((string)$_POST['new_id'])!=='') $id=(int)$_POST['new_id'];
            list($fields,$types)=gm_npc_fields_from_post();
            if ($fields['name']==='') $message='NPC 名称不能为空。';
            else {
                $postedId=(int)(isset($_POST['id'])?$_POST['id']:0);
                $exists=($id>0)?gm_one('SELECT id FROM npc_def WHERE id=?','i',array($id)):null;
                $clickPrep=gm_npc_prepare_click_teleport($fields);
                if ($postedId>0 && !$exists) $message='要编辑的 NPC 不存在。';
                elseif ($postedId<=0 && $id>0 && $exists) $message='NPC ID '.$id.' 已存在，请换一个编号。';
                elseif ($clickPrep!==true) $message=$clickPrep;
                else {
                    $ok=gm_save_row('npc_def',$id,$fields,$types,'id');
                    if ($ok) {
                        if ($id<=0) $id=(int)gm_db()->insert_id;
                        $shopRet=gm_npc_save_shop($id);
                        $teleRet=gm_npc_save_teleports($id);
                        $clickRet=gm_npc_save_click_teleport((int)$fields['legacy_id'], $fields['name']);
                        $redirEdit=$id;
                        $message=($postedId>0)?'NPC 已更新。':'NPC 已添加。';
                        if ($shopRet!==true) $message.=' '.$shopRet;
                        if ($teleRet!==true) $message.=' '.$teleRet;
                        if ($clickRet!==true) $message.=' '.$clickRet;
                        elseif (gm_npc_click_dest_from_post()) $message.=' 已设为点一下传到地图 '.(int)$_POST['click_tp_dtx'].' 坐标 '.(int)$_POST['click_tp_dty'].'（旧编号 '.(int)$fields['legacy_id'].'）。';
                        gm_log('save_npc','NPC '.$id,$fields['name']);
                    } else {
                        $message='NPC 保存失败；请先安装 NPC/地图数据表。';
                    }
                }
            }
        }
    } elseif ($action === 'delete_npc') {
        $id=(int)$_POST['id'];$used=gm_table_exists('map_npc')?gm_one('SELECT COUNT(*) AS n FROM map_npc WHERE npc_id=?','i',array($id)):array('n'=>0);
        $legacyRow=gm_one('SELECT legacy_id FROM npc_def WHERE id=?','i',array($id));
        if($used&&(int)$used['n']>0)$message='NPC 已被地图引用，不能删除。请先从地图配置中移除。';
        elseif(gm_exec('DELETE FROM npc_def WHERE id=?','i',array($id))!==false){
            if (gm_table_exists('npc_func_shop')) gm_exec('DELETE FROM npc_func_shop WHERE npc_id=?','i',array($id));
            if (gm_table_exists('npc_teleport')) gm_exec('DELETE FROM npc_teleport WHERE npc_id=?','i',array($id));
            if ($legacyRow) gm_npc_delete_click_teleport((int)$legacyRow['legacy_id']);
            $ok=true;$message='NPC 已删除。';gm_log('delete_npc','NPC '.$id,'删除NPC');
        }
    } elseif ($action === 'save_quest') {
        $id=(int)(isset($_POST['id'])?$_POST['id']:0);
        if ($id<=0 && isset($_POST['quest_id']) && trim((string)$_POST['quest_id'])!=='') $id=(int)$_POST['quest_id'];
        $nullIfEmpty=function($v){ $v=trim((string)$v); return $v===''?null:(int)$v; };
        $goalAllow=array('kill','item','talk','none','skill');
        $goal=isset($_POST['goal_type'])&&in_array($_POST['goal_type'],$goalAllow,true)?$_POST['goal_type']:'talk';
        $fields=array(
            'kind'=>gm_clean_text(isset($_POST['kind'])?$_POST['kind']:'主线',16),
            'name'=>gm_clean_text(isset($_POST['name'])?$_POST['name']:'',64),
            'min_level'=>(int)(isset($_POST['min_level'])?$_POST['min_level']:0),
            'giver_npc'=>$nullIfEmpty(isset($_POST['giver_npc'])?$_POST['giver_npc']:''),
            'descr'=>gm_clean_text(gm_quest_pages_from_post('descr'),20000),
            'goal_type'=>$goal,
            'goal_ref'=>gm_clean_text(isset($_POST['goal_ref'])?$_POST['goal_ref']:'',64),
            'goal_qty'=>gm_safe_int(isset($_POST['goal_qty'])?$_POST['goal_qty']:0,0,999999,0),
            'reward_exp'=>isset($_POST['reward_exp'])?(string)max(0,(float)$_POST['reward_exp']):'0',
            'reward_silver'=>isset($_POST['reward_silver'])?(string)max(0,(float)$_POST['reward_silver']):'0',
            'reward_item'=>$nullIfEmpty(isset($_POST['reward_item'])?$_POST['reward_item']:''),
            'reward_item_qty'=>gm_safe_int(isset($_POST['reward_item_qty'])?$_POST['reward_item_qty']:0,0,999999,0),
            'next_id'=>$nullIfEmpty(isset($_POST['next_id'])?$_POST['next_id']:''),
            'tag'=>gm_clean_text(isset($_POST['tag'])?$_POST['tag']:'',8),
            'area'=>gm_clean_text(isset($_POST['area'])?$_POST['area']:'',32),
            'turnin_npc'=>$nullIfEmpty(isset($_POST['turnin_npc'])?$_POST['turnin_npc']:''),
            'done_level'=>gm_safe_int(isset($_POST['done_level'])?$_POST['done_level']:0,0,999,0),
            'accept_exp'=>isset($_POST['accept_exp'])?(string)max(0,(float)$_POST['accept_exp']):'0',
            'accept_silver'=>isset($_POST['accept_silver'])?(string)max(0,(float)$_POST['accept_silver']):'0',
            'accept_items'=>gm_clean_text(isset($_POST['accept_items'])?$_POST['accept_items']:'',255),
            'done_text'=>gm_clean_text(gm_quest_pages_from_post('done_text'),20000),
            'reward_items'=>gm_clean_text(isset($_POST['reward_items'])?$_POST['reward_items']:'',255),
            'talk_text'=>gm_clean_text(gm_quest_pages_from_post('talk_text'),20000),
            'talk_items'=>gm_clean_text(isset($_POST['talk_items'])?$_POST['talk_items']:'',255),
            'in_menu'=>!empty($_POST['in_menu'])?1:0,
            'menu_loc'=>gm_clean_text(isset($_POST['menu_loc'])?$_POST['menu_loc']:'',64),
            'menu_goto'=>gm_clean_text(isset($_POST['menu_goto'])?$_POST['menu_goto']:'',16),
            'quick_dtx'=>(isset($_POST['quick_dtx'])&&trim((string)$_POST['quick_dtx'])!==''?gm_safe_int($_POST['quick_dtx'],0,999999,0):null),
            'quick_dty'=>(isset($_POST['quick_dty'])&&trim((string)$_POST['quick_dty'])!==''?gm_safe_int($_POST['quick_dty'],0,999999,0):null),
            'quick_fee'=>isset($_POST['quick_fee'])?(string)gm_safe_int($_POST['quick_fee'],0,999999999,0):'0'
        );
        $typeMap=array('min_level'=>'i','giver_npc'=>'i','goal_qty'=>'i','reward_exp'=>'s','reward_silver'=>'s','reward_item'=>'i','reward_item_qty'=>'i','next_id'=>'i','turnin_npc'=>'i','done_level'=>'i','accept_exp'=>'s','accept_silver'=>'s','in_menu'=>'i','quick_dtx'=>'i','quick_dty'=>'i','quick_fee'=>'s');
        if($fields['name']==='')$message='任务名称不能为空。';
        else{
            $postedId=(int)(isset($_POST['id'])?$_POST['id']:0);
            $exists=($id>0)?gm_one('SELECT id FROM quest_def WHERE id=?','i',array($id)):null;
            if($postedId>0 && !$exists){
                $message='要编辑的任务不存在。';
            }elseif($postedId<=0 && $id>0 && $exists){
                $message='任务 ID '.$id.' 已存在，请换一个编号。';
            }else{
                $ok=gm_save_row('quest_def',$id,$fields,$typeMap,'id');
                if($ok){
                    if($id<=0)$id=(int)gm_db()->insert_id;
                    $redirEdit=$id;
                    $message=($postedId>0)?'任务已更新。':'任务已添加。';
                    gm_log('save_quest','任务 '.$id,$fields['name']);
                }else{
                    $message='任务保存失败；请先安装任务数据表。';
                }
            }
        }
    } elseif ($action === 'delete_quest') {
        $id=(int)$_POST['id'];$used=gm_table_exists('player_quest')?gm_one('SELECT COUNT(*) AS n FROM player_quest WHERE quest_id=?','i',array($id)):array('n'=>0);
        if($used&&(int)$used['n']>0)$message='已有玩家接取或完成此任务，不能删除。';elseif(gm_exec('DELETE FROM quest_def WHERE id=?','i',array($id))!==false){$ok=true;$message='任务定义已删除。';gm_log('delete_quest','任务 '.$id,'删除任务');}
    }

    // 世界系统公告：使用游戏现有消息队列和历史文件。
    elseif ($action === 'post_notice') {
        $text=gm_clean_text(isset($_POST['notice_text'])?$_POST['notice_text']:'',300);$color=isset($_POST['color'])&&in_array($_POST['color'],array('black','red','blue','green'))?$_POST['color']:'black';
        if($text==='')$message='公告内容不能为空。';else{
            $safe=htmlspecialchars(str_replace(array("\r","\n","|"),array('','','｜'),$text),ENT_QUOTES,'UTF-8');
            $line="<font color='".$color."'>[系统]".$safe."</font>";
            $dir=XYGM_GAME_ROOT.'/msg';if(!is_dir($dir))@mkdir($dir,0777,true);
            $q=$dir.'/msg_queue.txt';$h=$dir.'/sys_history.txt';
            $w1=@DbIniStore::filePutContents($q,$line."\n",FILE_APPEND|LOCK_EX);$w2=@DbIniStore::filePutContents($h,date('H:i').'|'.$line."\n",FILE_APPEND|LOCK_EX);
            if($w1!==false&&$w2!==false){$lines=@file($h,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);if(is_array($lines)&&count($lines)>300)@DbIniStore::filePutContents($h,implode("\n",array_slice($lines,-300))."\n",LOCK_EX);$ok=true;$message='世界公告已进入游戏公告队列。';$logDetail=$text.' / '.$color;gm_log('post_notice','世界公告',$logDetail);}else$message='写入公告文件失败，请检查 fqxy/msg 目录权限。';
        }
    }

    // GM 账号
    elseif ($action === 'create_admin' || $action === 'reset_admin_password' || $action === 'toggle_admin' || $action === 'delete_admin') {
        if ($user['role'] !== 'super_admin') $message='只有超级管理员可以管理 GM 账号。';
        elseif ($action === 'create_admin') {
            $name=gm_clean_text(isset($_POST['username'])?$_POST['username']:'',50);$pw=isset($_POST['password'])?(string)$_POST['password']:'';$role=isset($_POST['role'])&&in_array($_POST['role'],array('admin','editor','viewer'))?$_POST['role']:'admin';
            if(!preg_match('/^[A-Za-z0-9_]{4,50}$/',$name)||strlen($pw)<8)$message='账号需 4～50 位字母数字下划线，密码至少 8 位。';
            else{$ok=gm_exec('INSERT INTO xy_gm_admin (username,password_hash,role,is_active) VALUES (?,?,?,1)','sss',array($name,password_hash($pw,PASSWORD_DEFAULT),$role))!==false;$message=$ok?'GM 账号已创建。':'创建失败，账号可能已存在。';if($ok)gm_log('create_admin',$name,'role='.$role);}
        } elseif ($action === 'reset_admin_password') {
            $id=(int)$_POST['id'];$pw=isset($_POST['password'])?(string)$_POST['password']:'';
            if(strlen($pw)<8)$message='新密码至少 8 位。';else{$ok=gm_exec('UPDATE xy_gm_admin SET password_hash=? WHERE id=?','si',array(password_hash($pw,PASSWORD_DEFAULT),$id))!==false;$message=$ok?'管理员密码已重置。':$message;if($ok)gm_log('reset_admin_password','GM '.$id,'重置密码');}
        } elseif ($action === 'toggle_admin') {
            $id=(int)$_POST['id'];$active=!empty($_POST['active'])?1:0;
            if($id===(int)$user['id'])$message='不能停用当前登录账号。';else{$ok=gm_exec('UPDATE xy_gm_admin SET is_active=? WHERE id=?','ii',array($active,$id))!==false;$message=$ok?'管理员状态已修改。':$message;if($ok)gm_log('toggle_admin','GM '.$id,'active='.$active);}
        } else {
            $id=(int)$_POST['id'];if($id===(int)$user['id'])$message='不能删除当前登录账号。';else{$ok=gm_exec('DELETE FROM xy_gm_admin WHERE id=?','i',array($id))!==false;$message=$ok?'GM 账号已删除。':$message;if($ok)gm_log('delete_admin','GM '.$id,'删除管理员');}
        }
    } else {
        $message = '未知操作。';
    }

    gm_set_flash($ok ? 'success' : 'error', $message);
    unset($_SESSION['xygm_token']);
    $redirExtra = array();
    if (isset($_POST['return_q']) && trim((string)$_POST['return_q']) !== '') $redirExtra['q'] = trim((string)$_POST['return_q']);
    if (isset($_POST['return_p']) && (int)$_POST['return_p'] > 1) $redirExtra['p'] = (int)$_POST['return_p'];
    if ($ok && isset($redirEdit) && (int)$redirEdit > 0) $redirExtra['edit'] = (int)$redirEdit;
    if (isset($_POST['player_id']) && (int)$_POST['player_id'] >= 10000000) $redirExtra['player_id'] = (int)$_POST['player_id'];
    gm_redirect($returnPage, $redirExtra);
}

$flash = gm_take_flash();
$canWrite = gm_can_write();

$stats = array();
foreach (array('player_char'=>'玩家','item_def'=>'物品','xy_house_def'=>'住宅定义','xy_furniture_def'=>'家具定义','npc_def'=>'NPC','quest_def'=>'任务') as $table=>$label) {
    $stats[$label] = gm_table_exists($table) ? gm_one('SELECT COUNT(*) AS n FROM `' . $table . '`', '', array()) : null;
}
?><!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>西游踏凌霄 - GM 管理后台</title><link rel="stylesheet" href="assets/gm.css"></head>
<body><div class="app-shell">
<aside class="sidebar"><div class="side-brand"><span class="brand-mark small">XY</span><div><b>西游踏凌霄</b><small>独立 GM 管理系统</small></div></div>
<nav><?php foreach($pageNames as $key=>$label): ?><a class="nav-link <?php echo $page===$key?'active':''; ?>" href="index.php?page=<?php echo gm_h($key); ?>"><span class="nav-dot"></span><?php echo gm_h($label); ?></a><?php if($key==='players'): ?><a class="nav-link" href="player_tools.php"><span class="nav-dot"></span>玩家资料中心</a><?php endif; ?><?php if($key==='npcs'): ?><a class="nav-link" href="map_editor.php"><span class="nav-dot"></span>地图编辑管理</a><?php endif; ?><?php endforeach; ?><a class="nav-link" href="house_instances.php"><span class="nav-dot"></span>房屋实例 / 官宅地点</a></nav>
<div class="side-foot"><div class="admin-chip"><b><?php echo gm_h($user['username']); ?></b><small><?php echo $user['role']==='super_admin'?'超级管理员':($user['role']==='viewer'?'只读管理员':'管理人员'); ?></small></div><a class="logout-link" href="logout.php">退出登录</a></div></aside>
<main class="main-area"><header class="topbar"><div><div class="eyebrow">GAME MASTER CONSOLE</div><h1><?php echo gm_h($pageNames[$page]); ?></h1></div><div class="top-user"><span class="status-dot"></span><?php echo gm_h($user['username']); ?></div></header>
<?php if($flash): ?><div class="notice <?php echo gm_h($flash['type']); ?>"><?php echo gm_h($flash['message']); ?></div><?php endif; ?>
<?php if(!$canWrite): ?><div class="notice warn">当前账号为只读权限，不能执行新增、修改或删除。</div><?php endif; ?>

<?php if($page==='dashboard'): ?>
<section class="welcome-card"><div><span class="eyebrow">CONTROL CENTER</span><h2>游戏管理总览</h2><p>后台独立运行，不依赖原版 admin 登录验证。</p></div><div class="welcome-symbol">XY</div></section>
<div class="stats-grid"><?php foreach($stats as $label=>$v): ?><div class="stat-card"><span><?php echo gm_h($label); ?></span><strong><?php echo $v===null?'未安装':number_format((int)$v['n']); ?></strong></div><?php endforeach; ?></div>
<div class="panel"><div class="panel-head"><h2>快捷管理</h2><span class="muted">常用功能</span></div><div class="quick-grid"><?php foreach(array('players'=>'玩家管理','items'=>'物品管理','houses'=>'住宅与家具','npcs'=>'NPC 管理','quests'=>'任务管理','notice'=>'发布世界公告') as $k=>$v): ?><a class="quick-card" href="index.php?page=<?php echo gm_h($k); ?>"><b><?php echo gm_h($v); ?></b><span>进入管理 →</span></a><?php endforeach; ?><a class="quick-card" href="player_tools.php"><b>玩家资料中心</b><span>发放 GM 徽章 →</span></a> ?></div></div>
<div class="notice warn">重要：玩家道具、银两、经验等操作会写入游戏现有数据表/数据层。执行发放前请确认玩家 ID 与物品 ID。</div>

<?php elseif($page==='players'): ?>
<div class="panel"><div class="panel-head"><h2>查找玩家</h2><span class="muted">支持玩家 ID 或角色名称</span></div><form method="get" class="search-row"><input type="hidden" name="page" value="players"><input name="q" value="<?php echo gm_h(isset($_GET['q'])?$_GET['q']:''); ?>" placeholder="输入玩家 ID 或昵称"><button class="btn primary">搜索</button></form>
<?php $playerRows=gm_player_rows(isset($_GET['q'])?trim($_GET['q']):''); if($playerRows): ?><div class="table-wrap"><table><thead><tr><th>玩家 ID</th><th>昵称</th><th>等级</th><th>VIP</th><th>银两</th><th>操作</th></tr></thead><tbody><?php foreach($playerRows as $pr): ?><tr><td><?php echo (int)$pr['player_id']; ?></td><td><?php echo gm_h($pr['name']); ?></td><td><?php echo (int)$pr['level']; ?></td><td><?php echo (int)$pr['vip']; ?></td><td><?php echo gm_h(isset($pr['silver_bag'])?$pr['silver_bag']:'-'); ?></td><td><a class="text-link" href="index.php?page=players&player_id=<?php echo (int)$pr['player_id']; ?>">查看 / 管理</a></td></tr><?php endforeach; ?></tbody></table></div><?php elseif(gm_table_exists('player_char')||gm_table_exists('all_zt')): ?><p class="empty">没有找到玩家记录。</p><?php else: ?><div class="notice warn">暂未发现 player_char 或 all_zt 玩家表。请先运行角色数据迁移，或检查当前 hxxy 数据库。</div><?php endif; ?></div>
<?php if(isset($_GET['player_id'])): $pid=(int)$_GET['player_id'];$detail=gm_player_detail($pid); $xybBalance=null; if($detail && is_file(XYGM_ROOT.'/lib/RuyiDb.php')){ require_once XYGM_ROOT.'/lib/RuyiDb.php'; if(class_exists('RuyiDb')) $xybBalance=(int)RuyiDb::getXiyouCoin($pid);} ?>
<div class="panel"><div class="panel-head"><h2>玩家资料</h2><span class="tag">ID <?php echo $pid; ?></span></div><?php if($detail): ?><div class="detail-grid"><?php foreach($detail as $k=>$v): if(in_array($k,array('updated_at')))continue; ?><div><small><?php echo gm_h($k); ?></small><b><?php echo gm_h($v); ?></b></div><?php endforeach; ?></div><?php else: ?><p class="empty">玩家资料不存在。</p><?php endif; ?></div>
<?php if($detail && $canWrite): ?><div class="forms-grid"><div class="panel"><h2>增加银两</h2><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="players"><input type="hidden" name="action" value="player_add_silver"><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><label>增加数量<input type="number" min="1" max="2000000000" name="amount" required></label><button class="btn primary">确认增加银两</button></form></div><div class="panel"><h2>增加金豆</h2><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="players"><input type="hidden" name="action" value="player_add_beans"><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><label>增加数量<input type="number" min="1" max="2000000000" name="amount" required></label><button class="btn primary">确认增加金豆</button></form></div><div class="panel"><h2>增加西游币</h2><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="players"><input type="hidden" name="action" value="player_add_xiyou"><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><label>增加数量<?php if($xybBalance!==null): ?><span class="muted">（当前余额：<?php echo (int)$xybBalance; ?>）</span><?php endif; ?><input type="number" min="1" max="2000000000" name="amount" required></label><button class="btn primary">确认增加西游币</button></form></div><div class="panel"><h2>增加经验</h2><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="players"><input type="hidden" name="action" value="player_add_exp"><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><label>增加经验<input type="number" min="1" max="2000000000" name="amount" required></label><button class="btn primary">确认增加经验</button></form></div><div class="panel"><h2>设置 VIP</h2><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="players"><input type="hidden" name="action" value="player_set_vip"><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><label>VIP 等级<input type="number" min="0" max="999" name="vip" value="<?php echo isset($detail['vip'])?(int)$detail['vip']:0; ?>" required></label><button class="btn primary">保存 VIP 等级</button></form></div><div class="panel"><h2>发放物品</h2><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="players"><input type="hidden" name="action" value="player_give_item"><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><label>物品 ID<input type="number" min="1" name="item_id" required></label><label>数量<input type="number" min="1" max="999999" name="qty" value="1" required></label><button class="btn primary">发放到背包</button></form></div></div><?php endif; ?>
<?php endif; ?>

<?php elseif($page==='items'): ?>
<?php
$editItem=isset($_GET['edit'])&&gm_table_exists('item_def')?gm_one('SELECT * FROM item_def WHERE id=?','i',array((int)$_GET['edit'])):null;
$categories=gm_table_exists('item_category')?gm_rows('SELECT id,name FROM item_category ORDER BY sort,id','',array()):array();
$slots=gm_table_exists('equip_slot')?gm_rows('SELECT id,name FROM equip_slot ORDER BY sort,id','',array()):array();
$itemQ=gm_list_q();
$itemWhere='';$itemTypes='';$itemParams=array();
if ($itemQ!=='') {
    if (preg_match('/^\d+$/', $itemQ)) {
        $itemWhere=' WHERE id=? OR name LIKE ?';
        $itemTypes='is';
        $itemParams=array((int)$itemQ, '%'.$itemQ.'%');
    } else {
        $itemWhere=' WHERE name LIKE ?';
        $itemTypes='s';
        $like='%'.$itemQ.'%';
        $itemParams=array($like);
        $__icols=gm_columns('item_def');
        if (isset($__icols['type_text'])) { $itemWhere.=' OR type_text LIKE ?'; $itemTypes.='s'; $itemParams[]=$like; }
        if (isset($__icols['effect_type'])) { $itemWhere.=' OR effect_type LIKE ?'; $itemTypes.='s'; $itemParams[]=$like; }
    }
}
$itemTotal=0;
if (gm_table_exists('item_def')) {
    $__ic=gm_one('SELECT COUNT(*) AS n FROM item_def'.$itemWhere,$itemTypes,$itemParams);
    $itemTotal=$__ic?(int)$__ic['n']:0;
}
$itemPg=gm_pager_data($itemTotal,20,gm_list_p());
$itemRows=array();
if ($itemTotal>0) {
    $itemRows=gm_rows('SELECT * FROM item_def'.$itemWhere.' ORDER BY id ASC LIMIT '.(int)$itemPg['offset'].','.(int)$itemPg['per'],$itemTypes,$itemParams);
}
$itemKeep=gm_page_url('items',$itemPg['page'],$itemQ);
?>
<div class="panel"><div class="panel-head"><h2><?php echo $editItem?'编辑物品定义':'添加物品定义'; ?></h2><span class="muted">按 item_def 表字段排列，左边是中文名和字段名，右边填写</span></div>
<?php if(!gm_table_exists('item_def')): ?><div class="notice warn">找不到 item_def 表。请先执行新物品系统的 sql_schema/001～006 等迁移。</div><?php elseif($canWrite): ?>
<?php gm_render_item_form($editItem, $canWrite, $categories, $slots, $itemKeep); ?>
<?php endif; ?></div>
<?php if($editItem && $canWrite): ?><div class="panel"><div class="panel-head"><h2>装备属性 item_attr</h2><span class="tag">物品 ID <?php echo (int)$editItem['id']; ?></span></div><?php if(gm_table_exists('item_attr')): ?><p class="muted">这里改的是装备属性表。属性类型对应 attr_key，最小值 min_val，最大值 max_val。最小和最大相同就是固定值。</p><form method="post" class="form-grid"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="items"><input type="hidden" name="return_q" value="<?php echo gm_h($itemQ); ?>"><input type="hidden" name="return_p" value="<?php echo (int)$itemPg['page']; ?>"><input type="hidden" name="action" value="save_item_attr"><input type="hidden" name="item_id" value="<?php echo (int)$editItem['id']; ?>"><label>属性类型 attr_key<select name="attr_key"><?php foreach(gm_attr_labels() as $k=>$v): ?><option value="<?php echo gm_h($k); ?>"><?php echo gm_h($v); ?>（<?php echo gm_h($k); ?>）</option><?php endforeach; ?></select></label><label>最小值 min_val<input type="number" name="min_val" value="0"></label><label>最大值 max_val<input type="number" name="max_val" value="0"></label><div class="wide"><button class="btn primary">保存 / 覆盖此属性</button></div></form><?php $attrs=gm_rows('SELECT attr_key,min_val,max_val FROM item_attr WHERE item_id=?','i',array((int)$editItem['id'])); $__labs=gm_attr_labels(); if($attrs): ?><div class="table-wrap"><table><thead><tr><th>属性</th><th>字段</th><th>最小</th><th>最大</th></tr></thead><tbody><?php foreach($attrs as $a): ?><tr><td><?php echo gm_h(isset($__labs[$a['attr_key']])?$__labs[$a['attr_key']]:$a['attr_key']); ?></td><td><code><?php echo gm_h($a['attr_key']); ?></code></td><td><?php echo gm_h($a['min_val']); ?></td><td><?php echo gm_h($a['max_val']); ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?><?php else: ?><div class="notice warn">缺少 item_attr 表，请执行装备属性迁移。</div><?php endif; ?></div><?php endif; ?>
<div class="panel"><div class="panel-head"><h2>物品定义列表</h2><span class="muted">按 ID 从小到大，每页 20 条</span></div>
<form method="get" class="search-row"><input type="hidden" name="page" value="items"><input name="q" value="<?php echo gm_h($itemQ); ?>" placeholder="物品 ID、名称、类别或效果"><button class="btn primary">搜索</button><?php if($itemQ!==''): ?><a class="btn" href="index.php?page=items">清除</a><?php endif; ?></form>
<?php if($itemRows): ?><div class="table-wrap"><table><thead><tr><th>ID</th><th>名称</th><th>分类</th><th>效果</th><th>价格</th><th>状态</th><th>操作</th></tr></thead><tbody><?php foreach($itemRows as $it): ?><tr><td><?php echo (int)$it['id']; ?></td><td><?php echo gm_h($it['name']); ?></td><td><?php echo (int)$it['category_id']; ?></td><td><?php echo gm_h(isset($it['effect_type'])?$it['effect_type']:''); ?></td><td><?php echo isset($it['price'])?gm_h($it['price']):'-'; ?></td><td><?php echo isset($it['enabled'])&&(int)$it['enabled']?'启用':'停用'; ?></td><td><a class="text-link" href="<?php echo gm_h(gm_page_url('items',$itemPg['page'],$itemQ,array('edit'=>(int)$it['id']))); ?>">编辑</a> <?php if($canWrite): ?><form method="post" class="inline-form"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="items"><input type="hidden" name="return_q" value="<?php echo gm_h($itemQ); ?>"><input type="hidden" name="return_p" value="<?php echo (int)$itemPg['page']; ?>"><input type="hidden" name="action" value="toggle_item"><input type="hidden" name="id" value="<?php echo (int)$it['id']; ?>"><input type="hidden" name="enabled" value="<?php echo isset($it['enabled'])&&(int)$it['enabled']?0:1; ?>"><button class="link-button"><?php echo isset($it['enabled'])&&(int)$it['enabled']?'停用':'启用'; ?></button></form><form method="post" class="inline-form" onsubmit="return confirm('确定删除此物品定义？有玩家持有时系统会阻止删除。');"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="items"><input type="hidden" name="return_q" value="<?php echo gm_h($itemQ); ?>"><input type="hidden" name="return_p" value="<?php echo (int)$itemPg['page']; ?>"><input type="hidden" name="action" value="delete_item"><input type="hidden" name="id" value="<?php echo (int)$it['id']; ?>"><button class="link-button danger-link">删除</button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php echo gm_pager_html('items',$itemPg,$itemQ); ?><?php else: ?><p class="empty"><?php echo $itemQ!==''?'没有匹配的物品。':'暂无物品定义。'; ?></p><?php endif; ?></div>

<?php elseif($page==='houses'): ?>
<div class="panel"><div class="panel-head"><h2>新住宅系统管理入口</h2><span class="muted">使用第一阶段的新数据表结构</span></div>
<div class="notice warn">原版 GM V1 的住宅/家具表单使用旧字段结构，已停止在此页面执行，避免向新住宅表写入不兼容数据。房屋定义、住宅实例、官宅地图地点和房主分配，请使用新版管理页面。</div>
<p><a class="btn primary" href="house_instances.php">进入房屋实例 / 官宅地点管理</a></p>
<p class="muted">家具定义、家具分级属性、家具库存和摆放管理将在后续住宅系统阶段接入新数据表。</p></div>
<?php elseif($page==='npcs'): ?>
<?php
$npcQ=gm_list_q();
$npcWhere='';
$npcTypes='';
$npcParams=array();
if ($npcQ!=='') {
    if (preg_match('/^\d+$/', $npcQ)) {
        $npcWhere=' WHERE id=? OR legacy_id=? OR name LIKE ?';
        $npcTypes='iis';
        $npcParams=array((int)$npcQ,(int)$npcQ,'%'.$npcQ.'%');
    } else {
        $npcWhere=' WHERE name LIKE ? OR color LIKE ?';
        $npcTypes='ss';
        $like='%'.$npcQ.'%';
        $npcParams=array($like,$like);
    }
}
$npcTotal=0;
if (gm_table_exists('npc_def')) {
    $npcCnt=gm_one('SELECT COUNT(*) AS n FROM npc_def'.$npcWhere,$npcTypes,$npcParams);
    $npcTotal=$npcCnt?(int)$npcCnt['n']:0;
}
$npcPg=gm_pager_data($npcTotal,20,gm_list_p());
$npcRows=array();
if (gm_table_exists('npc_def')) {
    $npcRows=gm_rows('SELECT * FROM npc_def'.$npcWhere.' ORDER BY id ASC LIMIT '.(int)$npcPg['offset'].','.(int)$npcPg['per'],$npcTypes,$npcParams);
}
$npcKeep=gm_page_url('npcs',$npcPg['page'],$npcQ);
$editNpc=isset($_GET['edit'])?gm_one('SELECT * FROM npc_def WHERE id=?','i',array((int)$_GET['edit'])):null;
if (!gm_table_exists('npc_def')): ?>
<div class="panel"><div class="panel-head"><h2>NPC 管理</h2></div><div class="notice warn">NPC 表尚未安装，请执行 015_map_npc_quest.sql。</div></div>
<?php else: ?>
<?php gm_render_npc_form($editNpc,$canWrite,$npcKeep); ?>
<div class="panel"><div class="panel-head"><h2>NPC 列表</h2><span class="muted">共 <?php echo (int)$npcTotal; ?> 个</span></div>
<form method="get" class="search-row"><input type="hidden" name="page" value="npcs"><input name="q" value="<?php echo gm_h($npcQ); ?>" placeholder="NPC ID、旧编号或名称"><button class="btn primary">搜索</button><?php if($npcQ!==''): ?><a class="btn" href="index.php?page=npcs">清除</a><?php endif; ?></form>
<?php if($npcRows): ?><div class="table-wrap"><table><thead><tr><th>ID</th><th>名称</th><th>旧编号</th><th>页面 ID</th><th>操作</th></tr></thead><tbody><?php foreach($npcRows as $n): ?><tr><td><?php echo (int)$n['id']; ?></td><td><?php echo gm_h($n['name']); ?></td><td><?php echo (int)$n['legacy_id']; ?></td><td><?php echo (int)$n['page']; ?></td><td><a class="text-link" href="<?php echo gm_h(gm_page_url('npcs',$npcPg['page'],$npcQ,array('edit'=>(int)$n['id']))); ?>">编辑</a> <?php if($canWrite): ?><form method="post" class="inline-form" onsubmit="return confirm('确定删除 NPC？已被地图引用时系统会阻止删除。');"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="npcs"><input type="hidden" name="return_q" value="<?php echo gm_h($npcQ); ?>"><input type="hidden" name="return_p" value="<?php echo (int)$npcPg['page']; ?>"><input type="hidden" name="action" value="delete_npc"><input type="hidden" name="id" value="<?php echo (int)$n['id']; ?>"><button class="link-button danger-link">删除</button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php echo gm_pager_html('npcs',$npcPg,$npcQ); ?><?php else: ?><p class="empty"><?php echo $npcQ!==''?'没有匹配的 NPC。':'暂无 NPC 定义。'; ?></p><?php endif; ?></div>
<?php endif; ?>

<?php elseif($page==='quests'): ?>
<?php
$editQuest=isset($_GET['edit'])?gm_one('SELECT * FROM quest_def WHERE id=?','i',array((int)$_GET['edit'])):null;
$questCols=gm_table_exists('quest_def')?gm_columns('quest_def'):array();
$hasQuickTravelCols=isset($questCols['quick_fee'])&&isset($questCols['quick_dtx'])&&isset($questCols['quick_dty']);
$questQ=gm_list_q();
$questWhere='';$questTypes='';$questParams=array();
if ($questQ!=='') {
    if (preg_match('/^\d+$/', $questQ)) {
        $questWhere=' WHERE id=? OR name LIKE ?';
        $questTypes='is';
        $questParams=array((int)$questQ, '%'.$questQ.'%');
    } else {
        $questWhere=' WHERE name LIKE ? OR kind LIKE ? OR goal_ref LIKE ?';
        $questTypes='sss';
        $like='%'.$questQ.'%';
        $questParams=array($like,$like,$like);
    }
}
$questTotal=0;
if (gm_table_exists('quest_def')) {
    $__qc=gm_one('SELECT COUNT(*) AS n FROM quest_def'.$questWhere,$questTypes,$questParams);
    $questTotal=$__qc?(int)$__qc['n']:0;
}
$questPg=gm_pager_data($questTotal,20,gm_list_p());
$questRows=array();
if ($questTotal>0) {
    $questRows=gm_rows('SELECT * FROM quest_def'.$questWhere.' ORDER BY id ASC LIMIT '.(int)$questPg['offset'].','.(int)$questPg['per'],$questTypes,$questParams);
}
$questKeep=gm_page_url('quests',$questPg['page'],$questQ);
?>
<div class="panel"><div class="panel-head"><h2><?php echo $editQuest?'编辑任务':'添加任务'; ?></h2><span class="muted">对白可分成多段，游戏里点「继续」进入下一段</span></div><?php if(!gm_table_exists('quest_def')): ?><div class="notice warn">任务表尚未安装，请执行 015_map_npc_quest.sql。</div><?php elseif($canWrite): ?>
<?php gm_render_quest_form($editQuest, $canWrite, $questCols, $questQ, $questPg, $questKeep); ?>
<?php endif; ?></div>
<div class="panel"><div class="panel-head"><h2>任务列表</h2><span class="muted">按 ID 从小到大，每页 20 条</span></div>
<form method="get" class="search-row"><input type="hidden" name="page" value="quests"><input name="q" value="<?php echo gm_h($questQ); ?>" placeholder="任务 ID、名称、类型或目标"><button class="btn primary">搜索</button><?php if($questQ!==''): ?><a class="btn" href="index.php?page=quests">清除</a><?php endif; ?></form>
<?php if($questRows): ?><div class="table-wrap"><table><thead><tr><th>ID</th><th>类型</th><th>名称</th><th>等级</th><th>目标</th><th>操作</th></tr></thead><tbody><?php foreach($questRows as $q): ?><tr><td><?php echo (int)$q['id']; ?></td><td><?php echo gm_h($q['kind']); ?></td><td><?php echo gm_h($q['name']); ?></td><td><?php echo (int)$q['min_level']; ?></td><td><?php echo gm_h($q['goal_type'].' / '.$q['goal_ref']); ?></td><td><a class="text-link" href="<?php echo gm_h(gm_page_url('quests',$questPg['page'],$questQ,array('edit'=>(int)$q['id']))); ?>">编辑</a> <?php if($canWrite): ?><form method="post" class="inline-form" onsubmit="return confirm('确定删除任务？有玩家任务记录时系统会阻止删除。');"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="quests"><input type="hidden" name="return_q" value="<?php echo gm_h($questQ); ?>"><input type="hidden" name="return_p" value="<?php echo (int)$questPg['page']; ?>"><input type="hidden" name="action" value="delete_quest"><input type="hidden" name="id" value="<?php echo (int)$q['id']; ?>"><button class="link-button danger-link">删除</button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php echo gm_pager_html('quests',$questPg,$questQ); ?><?php else: ?><p class="empty"><?php echo $questQ!==''?'没有匹配的任务。':'暂无任务定义。'; ?></p><?php endif; ?></div>

<?php elseif($page==='notice'): ?>
<div class="panel"><div class="panel-head"><h2>发布世界公告</h2><span class="muted">写入游戏现有公告队列与历史</span></div><?php if($canWrite): ?><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="notice"><input type="hidden" name="action" value="post_notice"><label>公告内容<textarea name="notice_text" rows="4" maxlength="300" required placeholder="输入要向全服玩家展示的公告"></textarea></label><label>文字颜色<select name="color"><option value="black">黑色</option><option value="red">红色</option><option value="blue">蓝色</option><option value="green">绿色</option></select></label><button class="btn primary">发布全服公告</button></form><?php else: ?><p class="empty">只读账号不能发布公告。</p><?php endif; ?></div>
<?php $historyFile=XYGM_GAME_ROOT.'/msg/sys_history.txt';$history=(class_exists('DbIniStore', false) ? DbIniStore::isFile($historyFile) : is_file($historyFile))?@file($historyFile,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES):array();if(is_array($history))$history=array_slice(array_reverse($history),0,30); ?><div class="panel"><div class="panel-head"><h2>最近公告记录</h2></div><?php if($history): ?><div class="history-list"><?php foreach($history as $line): $parts=explode('|',$line,2); ?><div><time><?php echo gm_h(isset($parts[0])?$parts[0]:''); ?></time><span><?php echo gm_h(isset($parts[1])?strip_tags($parts[1]):$line); ?></span></div><?php endforeach; ?></div><?php else: ?><p class="empty">暂无公告历史。</p><?php endif; ?></div>

<?php elseif($page==='admins'): ?>
<?php if($user['role']!=='super_admin'): ?><div class="notice warn">只有超级管理员可以管理 GM 账号。</div><?php else: ?>
<div class="panel"><div class="panel-head"><h2>创建 GM 账号</h2><span class="muted">密码至少 8 位</span></div><form method="post" class="form-grid"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="admins"><input type="hidden" name="action" value="create_admin"><label>账号<input name="username" required pattern="[A-Za-z0-9_]{4,50}"></label><label>初始密码<input type="password" name="password" required minlength="8"></label><label>权限<select name="role"><option value="admin">管理员（可读写）</option><option value="editor">编辑员（可读写）</option><option value="viewer">只读</option></select></label><div class="wide"><button class="btn primary">创建管理员</button></div></form></div>
<div class="panel"><div class="panel-head"><h2>管理员列表</h2></div><?php $adminRows=gm_rows('SELECT id,username,role,is_active,last_login,created_at FROM xy_gm_admin ORDER BY id','',array()); ?><div class="table-wrap"><table><thead><tr><th>ID</th><th>账号</th><th>权限</th><th>状态</th><th>上次登录</th><th>操作</th></tr></thead><tbody><?php foreach($adminRows as $a): ?><tr><td><?php echo (int)$a['id']; ?></td><td><?php echo gm_h($a['username']); ?></td><td><?php echo gm_h($a['role']); ?></td><td><?php echo (int)$a['is_active']?'启用':'停用'; ?></td><td><?php echo gm_h($a['last_login']); ?></td><td><form method="post" class="inline-form"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="admins"><input type="hidden" name="action" value="toggle_admin"><input type="hidden" name="id" value="<?php echo (int)$a['id']; ?>"><input type="hidden" name="active" value="<?php echo (int)$a['is_active']?0:1; ?>"><button class="link-button"><?php echo (int)$a['is_active']?'停用':'启用'; ?></button></form><details class="inline-details"><summary>重置密码</summary><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="admins"><input type="hidden" name="action" value="reset_admin_password"><input type="hidden" name="id" value="<?php echo (int)$a['id']; ?>"><input type="password" name="password" minlength="8" placeholder="新密码" required><button class="btn small">确认</button></form></details></td></tr><?php endforeach; ?></tbody></table></div></div><?php endif; ?>

<?php elseif($page==='logs'): ?>
<div class="panel">
    <div class="panel-head"><h2>GM 操作日志</h2><span class="muted">最近 200 条</span></div>
    <?php $logs = gm_rows('SELECT * FROM xy_gm_log ORDER BY id DESC LIMIT 200', '', array()); ?>
    <?php if ($logs): ?>
    <div class="table-wrap">
        <table>
            <thead><tr><th>时间</th><th>管理员</th><th>操作</th><th>目标</th><th>详情</th><th>IP</th></tr></thead>
            <tbody>
            <?php foreach ($logs as $l): ?>
                <tr>
                    <td><?php echo gm_h($l['created_at']); ?></td>
                    <td><?php echo gm_h($l['username']); ?></td>
                    <td><?php echo gm_h($l['action']); ?></td>
                    <td><?php echo gm_h($l['target']); ?></td>
                    <td><?php echo gm_h($l['detail']); ?></td>
                    <td><?php echo gm_h($l['ip']); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
        <p class="empty">暂无操作日志。</p>
    <?php endif; ?>
</div>

<?php elseif($page==='drops'): ?>
<?php
$monFields = array(
    'name'=>'名称','lv'=>'等级','hp'=>'当前HP','maxhp'=>'最大HP','mp'=>'当前MP','maxmp'=>'最大MP',
    'atk'=>'物攻','atk_min'=>'物攻下限','matk'=>'魔攻','matk_min'=>'魔攻下限',
    'def'=>'物防','def_min'=>'物防下限','mdef'=>'魔防',
    'ice_atk'=>'冰攻','fire_atk'=>'火攻','thunder_atk'=>'雷攻',
    'ice_def'=>'冰防','fire_def'=>'火防','thunder_def'=>'雷防',
    'exp'=>'经验','self_heal'=>'自愈','ind_atk'=>'独立攻击','ind_def'=>'独立防御','talk'=>'战斗对白'
);
$monQ = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$monWhere = ''; $monTypes = ''; $monParams = array();
if ($monQ !== '') {
    if (preg_match('/^\d+$/', $monQ)) {
        $monWhere = ' WHERE id=? OR name LIKE ?';
        $monTypes = 'is';
        $monParams = array((int)$monQ, '%'.$monQ.'%');
    } else {
        $monWhere = ' WHERE name LIKE ?';
        $monTypes = 's';
        $monParams = array('%'.$monQ.'%');
    }
}
$monTotal = 0;
if (gm_table_exists('monster_def')) {
    $__mc = gm_one('SELECT COUNT(*) AS n FROM monster_def'.$monWhere, $monTypes, $monParams);
    $monTotal = $__mc ? (int)$__mc['n'] : 0;
}
$monPg = gm_pager_data($monTotal, 20, gm_list_p());
$monRows = ($monTotal > 0) ? gm_rows('SELECT id,name,lv,hp,atk,def FROM monster_def'.$monWhere.' ORDER BY id ASC LIMIT '.(int)$monPg['offset'].','.(int)$monPg['per'], $monTypes, $monParams) : array();
$editMon = (isset($_GET['edit']) && gm_table_exists('monster_def')) ? gm_one('SELECT * FROM monster_def WHERE id=?', 'i', array((int)$_GET['edit'])) : null;
$monDrops = array();
if ($editMon && gm_table_exists('monster_drop')) {
    $monDrops = gm_rows('SELECT d.npc_id,d.item_id,d.qty,d.chance_num,d.chance_den,i.name AS item_name FROM monster_drop d LEFT JOIN item_def i ON i.id=d.item_id WHERE d.npc_id=? ORDER BY d.item_id', 'i', array((int)$editMon['id']));
}
$monKeep = gm_page_url('drops', $monPg['page'], $monQ);
?>
<div class="panel"><div class="panel-head"><h2>查找怪物</h2><span class="muted">按 ID 或名称，点进去同时改属性和掉落</span></div>
<form method="get" class="search-row"><input type="hidden" name="page" value="drops"><input name="q" value="<?php echo gm_h($monQ); ?>" placeholder="怪物 ID 或名称"><button class="btn primary">搜索</button><?php if($monQ!==''): ?><a class="btn" href="index.php?page=drops">清除</a><?php endif; ?></form>
<?php if(!gm_table_exists('monster_def')): ?><div class="notice warn">缺少 monster_def 表。</div>
<?php elseif($monRows): ?><div class="table-wrap"><table><thead><tr><th>ID</th><th>名称</th><th>等级</th><th>HP</th><th>攻击</th><th>防御</th><th>操作</th></tr></thead><tbody>
<?php foreach($monRows as $mr): ?><tr><td><?php echo (int)$mr['id']; ?></td><td><?php echo gm_h($mr['name']); ?></td><td><?php echo gm_h($mr['lv']); ?></td><td><?php echo gm_h($mr['hp']); ?></td><td><?php echo gm_h($mr['atk']); ?></td><td><?php echo gm_h($mr['def']); ?></td><td><a class="text-link" href="<?php echo gm_h(gm_page_url('drops',$monPg['page'],$monQ,array('edit'=>(int)$mr['id']))); ?>">属性+掉落</a></td></tr><?php endforeach; ?>
</tbody></table></div><?php echo gm_pager_html('drops',$monPg,$monQ); ?><?php else: ?><p class="empty">没有匹配的怪物。</p><?php endif; ?></div>
<?php if($editMon): $monCols = gm_columns('monster_def'); ?>
<div class="panel"><div class="panel-head"><h2>怪物属性 #<?php echo (int)$editMon['id']; ?> <?php echo gm_h($editMon['name']); ?></h2></div>
<?php if($canWrite): ?><form method="post" style="padding:16px"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="drops"><input type="hidden" name="return_q" value="<?php echo gm_h($monQ); ?>"><input type="hidden" name="return_p" value="<?php echo (int)$monPg['page']; ?>"><input type="hidden" name="action" value="save_monster"><input type="hidden" name="id" value="<?php echo (int)$editMon['id']; ?>"><div class="form-grid">
<?php foreach($monFields as $fk=>$fl): if(!isset($monCols[$fk])) continue; ?>
<label><?php echo gm_h($fl); ?><?php if($fk==='talk'): ?><textarea name="talk" rows="2"><?php echo gm_h(isset($editMon[$fk])?$editMon[$fk]:''); ?></textarea><?php else: ?><input name="<?php echo gm_h($fk); ?>" value="<?php echo gm_h(isset($editMon[$fk])?$editMon[$fk]:''); ?>"><?php endif; ?></label>
<?php endforeach; ?>
<div class="wide"><button class="btn primary">保存属性</button></div></div></form><?php else: ?><div class="notice warn">当前账号只读。</div><?php endif; ?></div>
<div class="panel"><div class="panel-head"><h2>该怪物掉落</h2><span class="muted">主键是怪物ID+物品ID，没有单独 id 列</span></div>
<?php if($canWrite && gm_table_exists('monster_drop')): ?><form method="post" class="form-grid" style="padding:16px"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="drops"><input type="hidden" name="return_q" value="<?php echo gm_h($monQ); ?>"><input type="hidden" name="return_p" value="<?php echo (int)$monPg['page']; ?>"><input type="hidden" name="action" value="add_drop"><input type="hidden" name="npc_id" value="<?php echo (int)$editMon['id']; ?>"><label>物品 ID<input type="number" name="item_id" min="1" required></label><label>数量<input type="number" name="qty" min="1" value="1" required></label><label>概率分子<input type="number" name="chance_num" min="1" value="1" required></label><label>概率分母<input type="number" name="chance_den" min="1" value="100" required></label><div class="wide"><button class="btn primary">添加 / 覆盖掉落</button></div></form><?php endif; ?>
<?php if($monDrops): ?><div class="table-wrap"><table><thead><tr><th>物品</th><th>数量</th><th>概率</th><th>操作</th></tr></thead><tbody>
<?php foreach($monDrops as $dr): ?><tr><td><?php echo (int)$dr['item_id']; ?> <?php echo gm_h(isset($dr['item_name'])?$dr['item_name']:''); ?></td><td><?php echo (int)$dr['qty']; ?></td><td><?php echo (int)$dr['chance_num']; ?>/<?php echo (int)$dr['chance_den']; ?></td><td><?php if($canWrite): ?><form method="post" class="inline-form" onsubmit="return confirm('确定删除这条掉落？');"><?php echo gm_token_field(); ?><input type="hidden" name="return_page" value="drops"><input type="hidden" name="return_q" value="<?php echo gm_h($monQ); ?>"><input type="hidden" name="return_p" value="<?php echo (int)$monPg['page']; ?>"><input type="hidden" name="action" value="del_monster_drop"><input type="hidden" name="npc_id" value="<?php echo (int)$editMon['id']; ?>"><input type="hidden" name="item_id" value="<?php echo (int)$dr['item_id']; ?>"><button class="link-button danger-link">删除</button></form><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php else: ?><p class="empty">这个怪物还没有掉落。</p><?php endif; ?></div>
<?php endif; ?>
<?php endif; ?>

<footer class="footer">西游踏凌霄 · 独立 GM 系统 · PHP 5.6 兼容</footer>
<script>
(function(){
  function closestPages(el){
    while (el && el !== document) {
      if (el.className && (' ' + el.className + ' ').indexOf(' quest-pages ') !== -1) return el;
      el = el.parentNode;
    }
    return null;
  }
  document.addEventListener('click', function(e){
    var btn = e.target;
    if (!btn || !btn.className) return;
    var cls = ' ' + btn.className + ' ';
    if (cls.indexOf(' js-add-quest-page ') !== -1) {
      e.preventDefault();
      var box = closestPages(btn);
      if (!box) return;
      var items = box.querySelectorAll('.quest-page-item');
      var n = items.length + 1;
      var name = box.getAttribute('data-name') + '_page[]';
      var lab = document.createElement('label');
      lab.className = 'quest-page-item';
      lab.appendChild(document.createTextNode('第' + n + '段'));
      var ta = document.createElement('textarea');
      ta.name = name;
      ta.rows = 4;
      lab.appendChild(ta);
      box.insertBefore(lab, btn.parentNode);
      return;
    }
    if (cls.indexOf(' js-add-shop-row ') !== -1) {
      e.preventDefault();
      var tb = document.querySelector('#npc-shop-table tbody');
      if (!tb) return;
      var tr = document.createElement('tr');
      tr.innerHTML = '<td><input type="number" name="shop_item_id[]" min="0" value=""></td><td class="muted"></td><td><input name="shop_price[]" value="" placeholder="0"></td><td><input type="number" name="shop_sort[]" value=""></td>';
      tb.appendChild(tr);
      return;
    }
    if (cls.indexOf(' js-add-tele-row ') !== -1) {
      e.preventDefault();
      var tb2 = document.querySelector('#npc-tele-table tbody');
      if (!tb2) return;
      var tr2 = document.createElement('tr');
      tr2.innerHTML = '<td><input name="tele_label[]" value="" maxlength="64"></td><td><input type="number" name="tele_dtx[]" value=""></td><td><input type="number" name="tele_dty[]" value=""></td><td><input name="tele_cost[]" value="" placeholder="0"></td><td><input type="number" name="tele_sort[]" value=""></td><td><input type="number" name="tele_min_lv[]" min="0" value="" placeholder="0"></td><td><input type="number" name="tele_req_quest[]" min="0" value="" placeholder="0"></td><td><select name="tele_req_camp[]"><option value="">不限</option><option value="阐教">阐教</option><option value="截教">截教</option></select></td><td><select name="tele_enabled[]"><option value="1">开</option><option value="0">关</option></select></td>';
      tb2.appendChild(tr2);
    }
  });
})();
</script>
</main></div></body></html>
