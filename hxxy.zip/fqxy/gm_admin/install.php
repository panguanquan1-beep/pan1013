<?php
require_once __DIR__ . '/bootstrap.php';
if (gm_current_user()) { header('Location: index.php'); exit; }
$count = gm_one('SELECT COUNT(*) AS n FROM xy_gm_admin', '', array());
if ($count && (int)$count['n'] > 0) {
    header('Location: login.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!gm_token_valid()) $error = '页面已过期，请刷新后重试。';
    else {
        $username = gm_clean_text(isset($_POST['username']) ? $_POST['username'] : '', 50);
        $password = isset($_POST['password']) ? (string)$_POST['password'] : '';
        $confirm = isset($_POST['confirm']) ? (string)$_POST['confirm'] : '';
        if (!preg_match('/^[A-Za-z0-9_]{4,50}$/', $username)) $error = '账号需为 4～50 位英文字母、数字或下划线。';
        elseif (strlen($password) < 8) $error = '密码至少 8 位。';
        elseif ($password !== $confirm) $error = '两次输入的密码不一致。';
        else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $ok = gm_exec('INSERT INTO xy_gm_admin (username,password_hash,role,is_active) VALUES (?,?,\'super_admin\',1)', 'ss', array($username, $hash));
            if ($ok !== false) {
                gm_log('install', $username, '建立独立 GM 超级管理员');
                gm_set_flash('success', '超级管理员已创建，请登录。');
                header('Location: login.php'); exit;
            }
            $error = '创建失败，请检查数据库写入权限。';
        }
    }
}
?><!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>初始化独立 GM</title><link rel="stylesheet" href="assets/gm.css"></head>
<body class="auth-body"><div class="auth-card"><div class="brand-mark">XY</div><h1>初始化 GM 后台</h1><p class="muted">首次安装时创建你自己的超级管理员账号，不使用原版 GM 账号。</p>
<?php if ($error !== '') echo '<div class="notice error">' . gm_h($error) . '</div>'; ?>
<form method="post" autocomplete="off"><?php echo gm_token_field(); ?>
<label>管理员账号<input name="username" required minlength="4" maxlength="50" pattern="[A-Za-z0-9_]+" autocomplete="username"></label>
<label>管理员密码<input type="password" name="password" required minlength="8" autocomplete="new-password"></label>
<label>再次输入密码<input type="password" name="confirm" required minlength="8" autocomplete="new-password"></label>
<button class="btn primary full" type="submit">创建超级管理员</button></form><p class="tiny muted">初始化成功后，此页面会自动关闭注册入口。</p></div></body></html>
