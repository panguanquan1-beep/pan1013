<?php
require_once __DIR__ . '/bootstrap.php';
if (gm_current_user()) { header('Location: index.php'); exit; }
$count = gm_one('SELECT COUNT(*) AS n FROM xy_gm_admin', '', array());
if (!$count || (int)$count['n'] === 0) { header('Location: install.php'); exit; }
$error = '';
$flash = gm_take_flash();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!gm_token_valid()) $error = '页面已过期，请刷新后重试。';
    else {
        $username = gm_clean_text(isset($_POST['username']) ? $_POST['username'] : '', 50);
        $password = isset($_POST['password']) ? (string)$_POST['password'] : '';
        $admin = gm_one('SELECT id,username,password_hash,role,is_active FROM xy_gm_admin WHERE username=? LIMIT 1', 's', array($username));
        if ($admin && (int)$admin['is_active'] === 1 && password_verify($password, $admin['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['xygm_user'] = array('id' => (int)$admin['id'], 'username' => $admin['username'], 'role' => $admin['role']);
            gm_exec('UPDATE xy_gm_admin SET last_login=NOW() WHERE id=?', 'i', array((int)$admin['id']));
            gm_log('login', $admin['username'], '独立 GM 登录成功');
            header('Location: index.php'); exit;
        }
        $error = '账号或密码错误，或该管理员已停用。';
    }
}
?><!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>西游踏凌霄 GM 登录</title><link rel="stylesheet" href="assets/gm.css"></head>
<body class="auth-body"><div class="auth-card"><div class="brand-mark">XY</div><h1>西游踏凌霄</h1><p class="muted">独立 GM 管理系统</p>
<?php if ($flash) echo '<div class="notice ' . gm_h($flash['type']) . '">' . gm_h($flash['message']) . '</div>'; ?>
<?php if ($error !== '') echo '<div class="notice error">' . gm_h($error) . '</div>'; ?>
<form method="post" autocomplete="off"><?php echo gm_token_field(); ?>
<label>管理员账号<input name="username" required maxlength="50" autocomplete="username"></label>
<label>管理员密码<input type="password" name="password" required autocomplete="current-password"></label>
<button class="btn primary full" type="submit">登录管理后台</button></form><p class="tiny muted">此后台独立于原版 admin 登录系统。</p></div></body></html>
