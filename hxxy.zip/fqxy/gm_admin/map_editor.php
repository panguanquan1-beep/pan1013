<?php
require_once __DIR__ . '/extra_layout.php';
require_once __DIR__ . '/map_editor_lib.php';

$ensure = map_editor_ensure_tables();
$tablesOk = map_editor_tables_ok();
$notice = '';
$noticeType = 'success';
if (!$ensure['ok']) {
    $notice = '自动创建地图表失败：' . $ensure['error'];
    $noticeType = 'error';
} elseif (!empty($ensure['created'])) {
    $notice = '已自动创建缺失的地图表：' . implode('、', $ensure['created']) . '。当前可能是空表，请从 map/data 导入一张地图，或确认后导入全部地图。无需手工执行 SQL。';
    $noticeType = 'warn';
}

function map_editor_redirect($dtx, $dty, $q)
{
    $rd = 'map_editor.php';
    $parts = array();
    if ($dtx !== '' && $dtx !== null && (int)$dtx >= 0) $parts[] = 'dtx=' . (int)$dtx;
    if ($dty !== '' && $dty !== null) $parts[] = 'dty=' . (int)$dty;
    if ($q !== '') $parts[] = 'q=' . rawurlencode($q);
    if (isset($_POST['npc_q']) && trim((string)$_POST['npc_q']) !== '') {
        $parts[] = 'npc_q=' . rawurlencode(trim((string)$_POST['npc_q']));
    }
    if ($parts) $rd .= '?' . implode('&', $parts);
    gm_extra_redirect($rd);
}

$q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
if (isset($_POST['q'])) $q = trim((string)$_POST['q']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    gm_extra_post_guard();
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $dtxPost = isset($_POST['dtx']) ? (int)$_POST['dtx'] : -1;
    $dtyPost = isset($_POST['dty']) ? (int)$_POST['dty'] : 0;

    if (!$tablesOk) {
        $notice = '地图数据表不完整，未进行修改。';
        $noticeType = 'error';
    } elseif ($action === 'save_zone') {
        $dtx = (int)$_POST['dtx'];
        $key = map_editor_safe_key(isset($_POST['map_key']) ? $_POST['map_key'] : '');
        $name = trim((string)$_POST['name']);
        if ($dtx < 0 || $key === '' || $name === '') {
            $notice = '地图编号、英文键名或地图名称不正确。';
            $noticeType = 'error';
        } else {
            $sameKey = gm_one('SELECT dtx FROM map_zone WHERE map_key=? AND dtx<>? LIMIT 1', 'si', array($key, $dtx));
            if ($sameKey) {
                $notice = '地图键名已被地图编号 ' . $sameKey['dtx'] . ' 使用。每个 map_key 应对应唯一地图资源文件。';
                $noticeType = 'error';
            } else {
                $exists = gm_one('SELECT dtx,map_key FROM map_zone WHERE dtx=?', 'i', array($dtx));
                $oldKey = $exists ? $exists['map_key'] : '';
                if ($exists) {
                    $ok = gm_exec('UPDATE map_zone SET map_key=?,name=? WHERE dtx=?', 'ssi', array($key, $name, $dtx)) !== false;
                    if ($ok && $oldKey !== $key) map_editor_copy_key_file($oldKey, $key);
                } else {
                    $ok = gm_exec('INSERT INTO map_zone (dtx,map_key,name) VALUES (?,?,?)', 'iss', array($dtx, $key, $name)) !== false;
                }
                $sync = $ok ? map_editor_sync_dtx_to_file($dtx, array('changed' => 'zone')) : array('ok' => false, 'error' => '');
                list($notice, $noticeType) = map_editor_flash_sync($ok, $sync, $exists ? '地图区域已保存。' : '地图区域已新建。');
                if ($ok) gm_log('map_save_zone', '地图区域 ' . $dtx, $key . ' / ' . $name);
                $dtxPost = $dtx;
            }
        }
    } elseif ($action === 'save_loc') {
        $dtx = (int)$_POST['dtx'];
        $dty = (int)$_POST['dty'];
        $name = trim((string)$_POST['name']);
        $descr = trim((string)$_POST['descr']);
        $monster = trim((string)$_POST['monster_inc']);
        $before = trim((string)$_POST['include_before']);
        $body = trim((string)$_POST['body']);
        if ($dtx < 0 || $dty < 0 || $name === '' || !gm_one('SELECT dtx FROM map_zone WHERE dtx=?', 'i', array($dtx))) {
            $notice = '请先建立地图区域，并填写有效的地图编号、坐标和地点名称。';
            $noticeType = 'error';
        } else {
            $exists = gm_one('SELECT dty FROM map_loc WHERE dtx=? AND dty=?', 'ii', array($dtx, $dty));
            if ($exists) {
                $ok = gm_exec(
                    'UPDATE map_loc SET name=?,descr=?,monster_inc=?,include_before=?,body=? WHERE dtx=? AND dty=?',
                    'sssssii',
                    array($name, $descr, $monster, $before, $body, $dtx, $dty)
                ) !== false;
            } else {
                $ok = gm_exec(
                    'INSERT INTO map_loc (dtx,dty,name,descr,monster_inc,include_before,body) VALUES (?,?,?,?,?,?,?)',
                    'iisssss',
                    array($dtx, $dty, $name, $descr, $monster, $before, $body)
                ) !== false;
            }
            $sync = $ok ? map_editor_sync_dtx_to_file($dtx, array('changed' => 'loc', 'dty' => $dty)) : array('ok' => false, 'error' => '');
            list($notice, $noticeType) = map_editor_flash_sync($ok, $sync, '地图地点已保存。');
            if ($ok) gm_log('map_save_location', '地点 ' . $dtx . '_' . $dty, $name);
            $dtxPost = $dtx;
            $dtyPost = $dty;
        }
    } elseif ($action === 'batch_add_loc') {
        $dtx = (int)$_POST['dtx'];
        $raw = isset($_POST['batch_locs']) ? (string)$_POST['batch_locs'] : '';
        $startRaw = isset($_POST['start_dty']) ? trim((string)$_POST['start_dty']) : '';
        $start = ($startRaw !== '') ? (int)$startRaw : -1;
        if ($dtx < 0 || !gm_one('SELECT dtx FROM map_zone WHERE dtx=?', 'i', array($dtx))) {
            $notice = '请先选择或建立地图区域。';
            $noticeType = 'error';
        } else {
            $maxRow = gm_one('SELECT MAX(dty) AS m FROM map_loc WHERE dtx=?', 'i', array($dtx));
            $next = 0;
            if ($start >= 0) {
                $next = $start;
            } elseif ($maxRow && $maxRow['m'] !== null && $maxRow['m'] !== '') {
                $next = (int)$maxRow['m'] + 1;
            }
            $parsed = map_editor_parse_batch_locs($raw, $next);
            $added = array();
            $skipped = array();
            $okAll = true;
            foreach ($parsed['rows'] as $row) {
                $dty = (int)$row['dty'];
                $exists = gm_one('SELECT dty,name FROM map_loc WHERE dtx=? AND dty=?', 'ii', array($dtx, $dty));
                if ($exists) {
                    $skipped[] = $dty . '（已有「' . $exists['name'] . '」）';
                    continue;
                }
                $ins = gm_exec(
                    'INSERT INTO map_loc (dtx,dty,name,descr,monster_inc,include_before,body) VALUES (?,?,?,?,?,?,?)',
                    'iisssss',
                    array($dtx, $dty, $row['name'], $row['descr'], '', '', '')
                );
                if ($ins === false) {
                    $parsed['errors'][] = '坐标 ' . $dty . '（' . $row['name'] . '）写入失败。';
                    $okAll = false;
                } else {
                    $added[] = $dty . ' ' . $row['name'];
                }
            }
            $sync = array('ok' => true, 'error' => '');
            if ($added) {
                $dtys = array();
                foreach ($added as $item) {
                    $dtys[] = (int)$item;
                }
                $sync = map_editor_sync_locs_to_file($dtx, $dtys);
            }
            $msg = array();
            if ($added) $msg[] = '已新增 ' . count($added) . ' 个地点：' . implode('、', $added) . '。';
            if ($skipped) $msg[] = '已跳过占用坐标：' . implode('、', $skipped) . '。';
            if ($parsed['errors']) $msg[] = implode(' ', $parsed['errors']);
            if (!$added && !$skipped && $parsed['errors']) {
                $notice = implode(' ', $parsed['errors']);
                $noticeType = 'error';
            } elseif ($added) {
                list($notice, $noticeType) = map_editor_flash_sync($okAll, $sync, implode(' ', $msg));
                gm_log('map_batch_add_location', '地图 ' . $dtx, '新增 ' . count($added) . '：' . implode('、', $added));
            } else {
                $notice = implode(' ', $msg);
                $noticeType = $skipped ? 'warn' : 'error';
            }
            $dtxPost = $dtx;
            if ($added) $dtyPost = (int)$added[count($added) - 1];
        }
    } elseif ($action === 'save_exit') {
        $dtx = (int)$_POST['dtx'];
        $dty = (int)$_POST['dty'];
        $dir = trim((string)$_POST['dir']);
        $name = trim((string)$_POST['name']);
        $label = trim((string)$_POST['label']);
        $toDtx = isset($_POST['to_dtx']) && $_POST['to_dtx'] !== '' ? (int)$_POST['to_dtx'] : $dtx;
        $toDty = isset($_POST['to_dty']) && $_POST['to_dty'] !== '' ? (int)$_POST['to_dty'] : -1;
        $seqPosted = isset($_POST['seq']) ? trim((string)$_POST['seq']) : '';
        $seq = $seqPosted !== '' ? (int)$seqPosted : null;
        $dirs = array('up', 'down', 'left', 'right', 'out', 'in', 'x1', 'x2', 'x3', 'x4', 'x5');
        $source = gm_one('SELECT dtx FROM map_loc WHERE dtx=? AND dty=?', 'ii', array($dtx, $dty));
        $dest = gm_one('SELECT dtx FROM map_loc WHERE dtx=? AND dty=?', 'ii', array($toDtx, $toDty));
        if (!$source || !$dest || !in_array($dir, $dirs, true) || $name === '') {
            $notice = '出口方向、名称或目标地点无效。目标必须是已经存在的地图坐标。';
            $noticeType = 'error';
        } else {
            if ($seq === null) {
                $seqRow = gm_one('SELECT COALESCE(MAX(seq),-1)+1 AS n FROM map_exit WHERE dtx=? AND dty=?', 'ii', array($dtx, $dty));
                $seq = $seqRow ? (int)$seqRow['n'] : 0;
            }
            $ok = gm_exec(
                'INSERT INTO map_exit (dtx,dty,dir,name,label,to_dtx,to_dty,seq) VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),label=VALUES(label),to_dtx=VALUES(to_dtx),to_dty=VALUES(to_dty),seq=VALUES(seq)',
                'iisssiii',
                array($dtx, $dty, $dir, $name, $label, $toDtx, $toDty, $seq)
            ) !== false;
            $sync = $ok ? map_editor_sync_dtx_to_file($dtx, array('changed' => 'exits', 'dty' => $dty)) : array('ok' => false, 'error' => '');
            list($notice, $noticeType) = map_editor_flash_sync($ok, $sync, '地图出口已保存（同一地点同一方向会覆盖旧出口）。');
            if ($ok) gm_log('map_save_exit', '出口 ' . $dtx . '_' . $dty . '_' . $dir, '目标 ' . $toDtx . '_' . $toDty . ' ' . $name);
            $dtxPost = $dtx;
            $dtyPost = $dty;
        }
    } elseif ($action === 'delete_exit') {
        $dtx = (int)$_POST['dtx'];
        $dty = (int)$_POST['dty'];
        $dir = trim((string)$_POST['dir']);
        $ok = gm_exec('DELETE FROM map_exit WHERE dtx=? AND dty=? AND dir=?', 'iis', array($dtx, $dty, $dir)) !== false;
        $sync = $ok ? map_editor_sync_dtx_to_file($dtx, array('changed' => 'exits', 'dty' => $dty)) : array('ok' => false, 'error' => '');
        list($notice, $noticeType) = map_editor_flash_sync($ok, $sync, '出口记录已删除。');
        if ($ok) gm_log('map_delete_exit', '出口 ' . $dtx . '_' . $dty . '_' . $dir, '');
        $dtxPost = $dtx;
        $dtyPost = $dty;
    } elseif ($action === 'place_npc') {
        $dtx = (int)$_POST['dtx'];
        $dty = (int)$_POST['dty'];
        $npc = (int)$_POST['npc_id'];
        $pos = trim((string)$_POST['pos']);
        $loc = gm_one('SELECT dtx FROM map_loc WHERE dtx=? AND dty=?', 'ii', array($dtx, $dty));
        $np = gm_table_exists('npc_def') ? gm_one('SELECT id FROM npc_def WHERE id=?', 'i', array($npc)) : null;
        $validPos = array('below_img', 'after_name', 'above_img');
        if (!$loc || !$np || !in_array($pos, $validPos, true)) {
            $notice = '地图地点、NPC 编号或显示位置无效。';
            $noticeType = 'error';
        } else {
            $seqRow = gm_one('SELECT COALESCE(MAX(seq),-1)+1 AS n FROM map_npc WHERE dtx=? AND dty=?', 'ii', array($dtx, $dty));
            $seq = $seqRow ? (int)$seqRow['n'] : 0;
            $ok = gm_exec('INSERT INTO map_npc (dtx,dty,seq,npc_id,pos) VALUES (?,?,?,?,?)', 'iiiis', array($dtx, $dty, $seq, $npc, $pos)) !== false;
            $sync = $ok ? map_editor_sync_dtx_to_file($dtx, array('changed' => 'npcs', 'dty' => $dty)) : array('ok' => false, 'error' => '');
            list($notice, $noticeType) = map_editor_flash_sync($ok, $sync, 'NPC 已放置到地图坐标。');
            if ($ok) gm_log('map_place_npc', '地图 ' . $dtx . '_' . $dty, 'NPC ' . $npc . ' seq=' . $seq);
            $dtxPost = $dtx;
            $dtyPost = $dty;
        }
    } elseif ($action === 'edit_npc_placement') {
        $dtx = (int)$_POST['dtx'];
        $dty = (int)$_POST['dty'];
        $oldSeq = (int)$_POST['old_seq'];
        $newSeq = (int)$_POST['new_seq'];
        $pos = trim((string)$_POST['pos']);
        $validPos = array('below_img', 'after_name', 'above_img');
        $collision = gm_one('SELECT seq FROM map_npc WHERE dtx=? AND dty=? AND seq=? LIMIT 1', 'iii', array($dtx, $dty, $newSeq));
        if (!in_array($pos, $validPos, true) || $newSeq < -99999 || $newSeq > 99999 || ($newSeq !== $oldSeq && $collision)) {
            $notice = '显示顺序已被占用，或显示位置不正确。请使用一个未被占用的顺序编号。';
            $noticeType = 'error';
        } else {
            $ok = gm_exec('UPDATE map_npc SET seq=?,pos=? WHERE dtx=? AND dty=? AND seq=?', 'isiii', array($newSeq, $pos, $dtx, $dty, $oldSeq)) !== false;
            $sync = $ok ? map_editor_sync_dtx_to_file($dtx, array('changed' => 'npcs', 'dty' => $dty)) : array('ok' => false, 'error' => '');
            list($notice, $noticeType) = map_editor_flash_sync($ok, $sync, '地图 NPC 顺序和显示位置已更新。');
            if ($ok) gm_log('map_edit_npc_placement', '地图 ' . $dtx . '_' . $dty, 'seq ' . $oldSeq . ' -> ' . $newSeq . ', pos=' . $pos);
            $dtxPost = $dtx;
            $dtyPost = $dty;
        }
    } elseif ($action === 'remove_npc') {
        $dtx = (int)$_POST['dtx'];
        $dty = (int)$_POST['dty'];
        $seq = (int)$_POST['seq'];
        $ok = gm_exec('DELETE FROM map_npc WHERE dtx=? AND dty=? AND seq=?', 'iii', array($dtx, $dty, $seq)) !== false;
        $sync = $ok ? map_editor_sync_dtx_to_file($dtx, array('changed' => 'npcs', 'dty' => $dty)) : array('ok' => false, 'error' => '');
        list($notice, $noticeType) = map_editor_flash_sync($ok, $sync, '地图 NPC 放置记录已删除（不会删除 NPC 定义）。');
        if ($ok) gm_log('map_remove_npc', '地图 ' . $dtx . '_' . $dty, 'seq=' . $seq);
        $dtxPost = $dtx;
        $dtyPost = $dty;
    } elseif ($action === 'import_one') {
        $dtx = (int)$_POST['dtx'];
        $key = map_editor_safe_key(isset($_POST['map_key']) ? $_POST['map_key'] : '');
        if ($key === '') {
            $zone = gm_one('SELECT map_key FROM map_zone WHERE dtx=?', 'i', array($dtx));
            if ($zone) $key = map_editor_safe_key($zone['map_key']);
        }
        if ($key === '') {
            $mf = map_editor_load_file_map();
            if (isset($mf[$dtx])) $key = map_editor_safe_key($mf[$dtx]);
        }
        $r = map_editor_import_dtx($dtx, $key);
        if ($r['ok']) {
            $c = $r['cnt'];
            $notice = '已从 map/data/' . $key . '.php 导入本张地图到数据库：地点 ' . (int)$c['loc'] . '，出口 ' . (int)$c['exit'] . '，NPC 放置 ' . (int)$c['npc'] . '。未清空 npc_def，也未改写其它地图。';
            $noticeType = 'success';
            gm_log('map_import_one', '地图 ' . $dtx, $key);
        } else {
            $notice = '导入失败：' . $r['error'];
            $noticeType = 'error';
        }
        $dtxPost = $dtx;
    } elseif ($action === 'import_all') {
        $confirm = isset($_POST['confirm_import_all']) ? $_POST['confirm_import_all'] : '';
        if ($confirm !== 'yes') {
            $notice = '请勾选确认后再导入全部地图。';
            $noticeType = 'error';
        } else {
            $r = map_editor_import_all_maps();
            if ($r['ok']) {
                $c = $r['cnt'];
                $notice = '已从地图文件导入全部地图：' . (int)$c['maps'] . ' 张，地点 ' . (int)$c['loc'] . '，出口 ' . (int)$c['exit'] . '，NPC 放置 ' . (int)$c['npc'] . '。未清空 npc_def。';
                if (!empty($r['error'])) {
                    $notice .= ' 部分失败：' . $r['error'];
                    $noticeType = 'warn';
                } else {
                    $noticeType = 'success';
                }
                gm_log('map_import_all', '全部地图', 'maps=' . (int)$c['maps']);
            } else {
                $notice = '全部导入失败：' . $r['error'];
                $noticeType = 'error';
            }
        }
    } elseif ($action === 'restore_map_backup') {
        $confirm = isset($_POST['confirm_restore_map']) ? $_POST['confirm_restore_map'] : '';
        if ($confirm !== 'yes') {
            $notice = '请勾选确认后再恢复地图备份。';
            $noticeType = 'error';
        } else {
            $r = map_editor_restore_map_backup_keep_edits();
            if ($r['ok']) {
                $notice = '已把其它地图的地点、出口和 NPC 放置恢复为 11月18日 22:17（上海时间）的备份。角色、背包、任务和 NPC 定义没有改动。';
                $kept = isset($r['kept']) && is_array($r['kept']) ? $r['kept'] : array();
                if ($kept) $notice .= ' 已按地图编号保留你当前改过的：' . implode('、', $kept) . '。';
                else $notice .= ' 当前库里的枉死城（地图编号 47，键名 wsc）如有改动也会按编号保留。';
                $ex = isset($r['export']) ? $r['export'] : array();
                if (!empty($ex['ok'])) {
                    $notice .= ' 并已把合并后的数据写回地图文件（' . (int)$ex['maps'] . ' 张）。';
                    if (!empty($ex['error'])) {
                        $notice .= ' 部分文件未写回：' . $ex['error'];
                        $noticeType = 'warn';
                    } else {
                        $noticeType = 'success';
                    }
                } else {
                    $notice .= ' 数据库已处理，但写回地图文件失败：' . (isset($ex['error']) ? $ex['error'] : '未知原因') . '。请检查 fqxy/map/data 目录权限。';
                    $noticeType = 'warn';
                }
                gm_log('map_restore_backup', '地图四表保留dtx47', '20261118_2217');
            } else {
                $notice = '恢复失败：' . $r['error'];
                $noticeType = 'error';
            }
        }
    }

    if ($notice !== '') gm_set_flash($noticeType, $notice);
    map_editor_redirect($dtxPost, isset($_POST['dty']) ? $dtyPost : '', $q);
}

$dtx = isset($_GET['dtx']) ? (int)$_GET['dtx'] : -1;
$dty = isset($_GET['dty']) ? (int)$_GET['dty'] : -1;
$npcQ = isset($_GET['npc_q']) ? trim((string)$_GET['npc_q']) : '';
$locQ = isset($_GET['loc_q']) ? trim((string)$_GET['loc_q']) : '';

$zones = array();
$pendingFiles = array();
if ($tablesOk) {
    $sql = 'SELECT z.*, (SELECT COUNT(*) FROM map_loc l WHERE l.dtx=z.dtx) AS loc_count FROM map_zone z';
    $params = array();
    $types = '';
    if ($q !== '') {
        $sql .= ' WHERE z.name LIKE ? OR z.map_key LIKE ? OR CAST(z.dtx AS CHAR) LIKE ?';
        $like = '%' . $q . '%';
        $params = array($like, $like, $like);
        $types = 'sss';
    }
    $sql .= ' ORDER BY z.dtx';
    $zones = gm_rows($sql, $types, $params);
    $mf = map_editor_load_file_map();
    $have = array();
    foreach (gm_rows('SELECT dtx,map_key FROM map_zone', '', array()) as $z) {
        $have[(int)$z['dtx']] = $z['map_key'];
    }
    foreach ($mf as $mdtx => $mkey) {
        $mdtx = (int)$mdtx;
        if (!isset($have[$mdtx])) {
            if ($q !== '' && stripos((string)$mkey, $q) === false && strpos((string)$mdtx, $q) === false) continue;
            $pendingFiles[] = array('dtx' => $mdtx, 'map_key' => $mkey, 'file_ok' => map_editor_file_exists($mkey));
        }
    }
}

$locs = ($tablesOk && $dtx >= 0) ? gm_rows('SELECT * FROM map_loc WHERE dtx=? ORDER BY dty', 'i', array($dtx)) : array();
if ($locQ !== '' && $locs) {
    $filtered = array();
    foreach ($locs as $l) {
        $nameHit = function_exists('mb_stripos') ? (mb_stripos($l['name'], $locQ, 0, 'UTF-8') !== false) : (stripos($l['name'], $locQ) !== false);
        if (strpos((string)$l['dty'], $locQ) !== false || $nameHit) $filtered[] = $l;
    }
    $locs = $filtered;
}
$exitCounts = array();
$npcCounts = array();
if ($tablesOk && $dtx >= 0) {
    foreach (gm_rows('SELECT dty,COUNT(*) AS n FROM map_exit WHERE dtx=? GROUP BY dty', 'i', array($dtx)) as $r) {
        $exitCounts[(int)$r['dty']] = (int)$r['n'];
    }
    foreach (gm_rows('SELECT dty,COUNT(*) AS n FROM map_npc WHERE dtx=? GROUP BY dty', 'i', array($dtx)) as $r) {
        $npcCounts[(int)$r['dty']] = (int)$r['n'];
    }
}
$zone = ($tablesOk && $dtx >= 0) ? gm_one('SELECT * FROM map_zone WHERE dtx=?', 'i', array($dtx)) : null;
$loc = ($tablesOk && $dtx >= 0 && $dty >= 0) ? gm_one('SELECT * FROM map_loc WHERE dtx=? AND dty=?', 'ii', array($dtx, $dty)) : null;
$exits = ($loc && gm_table_exists('map_exit')) ? gm_rows('SELECT * FROM map_exit WHERE dtx=? AND dty=? ORDER BY seq,dir', 'ii', array($dtx, $dty)) : array();
$nextExitSeq = 0;
if ($exits) {
    $maxSeq = -1;
    foreach ($exits as $__e) {
        if ((int)$__e['seq'] > $maxSeq) $maxSeq = (int)$__e['seq'];
    }
    $nextExitSeq = $maxSeq + 1;
}
$placed = array();
if ($loc && gm_table_exists('map_npc')) {
    $placedSql = 'SELECT m.*,n.name AS npc_name FROM map_npc m LEFT JOIN npc_def n ON n.id=m.npc_id WHERE m.dtx=? AND m.dty=? ORDER BY m.seq';
    $placed = gm_rows($placedSql, 'ii', array($dtx, $dty));
}
$npcs = array();
if (gm_table_exists('npc_def')) {
    if ($npcQ !== '') {
        $like = '%' . $npcQ . '%';
        $npcs = gm_rows('SELECT id,name,legacy_id FROM npc_def WHERE name LIKE ? OR CAST(id AS CHAR) LIKE ? OR CAST(legacy_id AS CHAR) LIKE ? ORDER BY name LIMIT 500', 'sss', array($like, $like, $like));
    } else {
        $npcs = gm_rows('SELECT id,name,legacy_id FROM npc_def ORDER BY name LIMIT 500', '', array());
    }
}
$dirs = array(
    'up' => '上', 'down' => '下', 'left' => '左', 'right' => '右',
    'out' => '离开', 'in' => '进入',
    'x1' => '扩展出口 X1', 'x2' => '扩展出口 X2', 'x3' => '扩展出口 X3', 'x4' => '扩展出口 X4', 'x5' => '扩展出口 X5'
);
$posLabels = array('below_img' => '图片下方', 'after_name' => '名称后', 'above_img' => '图片上方');

gm_extra_header('地图编辑管理', 'map_editor.php');
if ($notice !== '') echo '<div class="notice ' . gm_h($noticeType) . '">' . gm_h($notice) . '</div>';
?>
<div class="notice">保存会同时写入游戏地图文件（fqxy/map/data/键名.php，必要时更新 map_file_map.php）和数据库。不会调用全量删表导入。写文件前会在同目录留下 .bak-日期 备份。</div>
<?php if (!$tablesOk): ?>
<div class="panel"><div class="notice error">地图编辑需要 map_zone、map_loc、map_exit、map_npc 四张表。自动建表未成功，请检查数据库账号是否有 CREATE 权限。<?php echo $ensure['error'] !== '' ? ' 错误：' . gm_h($ensure['error']) : ''; ?></div></div>
<?php else: ?>

<div class="panel extra-panel">
    <div class="panel-head"><h2>地图区域</h2><span class="muted">地图编号 dtx 对应一个区域，可搜索后选择</span></div>
    <form method="get" class="search-row">
        <label>搜索地图<input type="text" name="q" value="<?php echo gm_h($q); ?>" placeholder="编号 / 名称 / map_key"></label>
        <?php if ($dtx >= 0): ?><input type="hidden" name="dtx" value="<?php echo (int)$dtx; ?>"><?php endif; ?>
        <button class="btn">搜索</button>
        <?php if ($q !== ''): ?><a class="btn" href="map_editor.php">清除</a><?php endif; ?>
    </form>
    <div class="table-wrap"><table>
        <thead><tr><th>地图编号</th><th>地图名称</th><th>地图键名</th><th>地点数量</th><th>地图文件</th><th>操作</th></tr></thead>
        <tbody>
        <?php if (!$zones): ?>
            <tr><td colspan="6"><?php echo $q !== '' ? '没有匹配的地图区域。' : '数据库中还没有地图区域。可从下方待导入列表导入。'; ?></td></tr>
        <?php else: foreach ($zones as $z): $fileOk = map_editor_file_exists($z['map_key']); ?>
            <tr<?php echo $dtx === (int)$z['dtx'] ? ' style="background:#eef5ff"' : ''; ?>>
                <td><?php echo (int)$z['dtx']; ?></td>
                <td><?php echo gm_h($z['name']); ?></td>
                <td><code><?php echo gm_h($z['map_key']); ?></code></td>
                <td><?php echo (int)$z['loc_count']; ?></td>
                <td><?php echo $fileOk ? '已有文件' : '文件不存在'; ?></td>
                <td>
                    <a class="text-link" href="map_editor.php?dtx=<?php echo (int)$z['dtx']; ?><?php echo $q !== '' ? '&q=' . rawurlencode($q) : ''; ?>">选择地图</a>
                    <?php if (gm_can_write() && $fileOk): ?>
                    <form method="post" class="inline-form" onsubmit="return confirm('将用地图文件覆盖这张地图在数据库中的地点、出口和 NPC 放置。不会删除 NPC 定义，也不影响其它地图。确定？');">
                        <?php echo gm_token_field(); ?>
                        <input type="hidden" name="action" value="import_one">
                        <input type="hidden" name="dtx" value="<?php echo (int)$z['dtx']; ?>">
                        <input type="hidden" name="map_key" value="<?php echo gm_h($z['map_key']); ?>">
                        <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
                        <button class="link-button">从文件导入</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table></div>

<?php if ($pendingFiles): ?>
    <h3 style="margin:16px 0 8px">尚未导入数据库的地图文件</h3>
    <p class="extra-note">这些条目来自 map_file_map.php，数据库中还没有对应区域。一次导入一张即可。</p>
    <div class="table-wrap"><table>
        <thead><tr><th>地图编号</th><th>map_key</th><th>文件</th><th>操作</th></tr></thead>
        <tbody>
        <?php foreach ($pendingFiles as $p): ?>
            <tr>
                <td><?php echo (int)$p['dtx']; ?></td>
                <td><code><?php echo gm_h($p['map_key']); ?></code></td>
                <td><?php echo $p['file_ok'] ? '已有文件' : '文件不存在'; ?></td>
                <td>
                    <?php if (gm_can_write() && $p['file_ok']): ?>
                    <form method="post" class="inline-form" onsubmit="return confirm('从文件导入这张地图到数据库？不会删除 NPC 定义。');">
                        <?php echo gm_token_field(); ?>
                        <input type="hidden" name="action" value="import_one">
                        <input type="hidden" name="dtx" value="<?php echo (int)$p['dtx']; ?>">
                        <input type="hidden" name="map_key" value="<?php echo gm_h($p['map_key']); ?>">
                        <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
                        <button class="link-button">从文件导入</button>
                    </form>
                    <?php else: ?>—
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
<?php endif; ?>

<?php if (gm_can_write()): ?>
    <form method="post" class="panel" style="margin:14px 0 0;padding:14px;background:#f8fafc">
        <?php echo gm_token_field(); ?>
        <input type="hidden" name="action" value="save_zone">
        <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
        <h3><?php echo $zone ? '修改当前地图区域' : '新增地图区域'; ?></h3>
        <div class="extra-form-grid">
            <label>地图编号 dtx<input type="number" name="dtx" min="0" required value="<?php echo $zone ? (int)$zone['dtx'] : ''; ?>"></label>
            <label>地图键名 map_key<input name="map_key" maxlength="32" required value="<?php echo $zone ? gm_h($zone['map_key']) : ''; ?>" placeholder="例如 cac"></label>
            <label>地图名称<input name="name" maxlength="64" required value="<?php echo $zone ? gm_h($zone['name']) : ''; ?>"></label>
        </div>
        <p class="extra-note">新增地图会同时建立数据库记录、写入 map/data/键名.php，并更新 map_file_map.php。若修改已有区域的键名，会复制原文件到新键名，不会删除旧文件。</p>
        <button class="btn primary">保存地图区域</button>
    </form>
    <form method="post" style="margin-top:12px;padding:14px;background:#ecfdf3;border-radius:8px" onsubmit="return confirm('将恢复 11月18日晚上的地图备份，并按地图编号保留你当前的枉死城（47，wsc）等已改副本。不会改角色、背包、任务和 NPC 定义。确定？');">
        <?php echo gm_token_field(); ?>
        <input type="hidden" name="action" value="restore_map_backup">
        <h3>恢复误导入前的地图</h3>
        <p class="extra-note">会先把当前数据库里的地图做一份快照，再写入 11月18日 22:17（上海时间）的备份，找回十字街头等处被冲掉的 NPC。随后按地图编号（不是地名）把你现在的枉死城写回去：编号 47，键名 wsc，入口格子叫枉死门，不会和其它同名地点搞混。若还有地点更多或布局已改的地图，也会按编号一并保留。不必手工执行 SQL。</p>
        <label class="check"><input type="checkbox" name="confirm_restore_map" value="yes"> 我确认要恢复备份并保留当前枉死城</label>
        <div style="margin-top:10px"><button class="btn primary">恢复地图备份</button></div>
    </form>
    <form method="post" style="margin-top:12px;padding:14px;background:#fff8e7;border-radius:8px" onsubmit="return confirm('将用地图文件覆盖数据库中的全部地图区域、地点、出口和地图 NPC 放置。如果文件还不完整，场景 NPC 会再次丢失。确定？');">
        <?php echo gm_token_field(); ?>
        <input type="hidden" name="action" value="import_all">
        <p class="extra-note">请先完成上方的备份恢复，等地图文件写回完整后再用这项。此操作可能较慢。不会清空 npc_def 整表。</p>
        <label class="check"><input type="checkbox" name="confirm_import_all" value="yes"> 我确认要从文件导入全部地图</label>
        <div style="margin-top:10px"><button class="btn">从文件导入全部地图</button></div>
    </form>
<?php endif; ?>
</div>

<div class="panel extra-panel">
    <div class="panel-head"><h2>地点列表</h2><span class="muted">当前地图：<?php echo $zone ? gm_h($zone['name']) : '请选择区域'; ?>（<?php echo $dtx >= 0 ? (int)$dtx : '未选'; ?>）</span></div>
    <?php if (!$zone): ?>
        <p class="empty">请先在上方选择或新建一张地图。</p>
    <?php else: ?>
        <form method="get" class="search-row">
            <input type="hidden" name="dtx" value="<?php echo (int)$dtx; ?>">
            <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?php echo gm_h($q); ?>"><?php endif; ?>
            <label>筛选地点<input type="text" name="loc_q" value="<?php echo gm_h($locQ); ?>" placeholder="坐标或名称"></label>
            <label>查看地点
                <select name="dty">
                    <option value="">选择地点坐标</option>
                    <?php foreach ($locs as $l): ?>
                    <option value="<?php echo (int)$l['dty']; ?>"<?php echo $dty === (int)$l['dty'] ? ' selected' : ''; ?>><?php echo (int)$l['dty']; ?> - <?php echo gm_h($l['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <button class="btn">查看</button>
        </form>
        <div class="table-wrap"><table>
            <thead><tr><th>dty</th><th>地点名称</th><th>描述</th><th>出口数</th><th>NPC 数</th><th>操作</th></tr></thead>
            <tbody>
            <?php if (!$locs): ?>
                <tr><td colspan="6">这张地图还没有地点，请在下方新增。</td></tr>
            <?php else: foreach ($locs as $l):
                $descText = (string)$l['descr'];
                $descShort = function_exists('mb_substr') ? mb_substr($descText, 0, 70, 'UTF-8') : substr($descText, 0, 70);
            ?>
                <tr<?php echo $dty === (int)$l['dty'] ? ' style="background:#eef5ff"' : ''; ?>>
                    <td><?php echo (int)$l['dty']; ?></td>
                    <td><?php echo gm_h($l['name']); ?></td>
                    <td><?php echo gm_h($descShort); ?></td>
                    <td><?php echo isset($exitCounts[(int)$l['dty']]) ? $exitCounts[(int)$l['dty']] : 0; ?></td>
                    <td><?php echo isset($npcCounts[(int)$l['dty']]) ? $npcCounts[(int)$l['dty']] : 0; ?></td>
                    <td><a class="text-link" href="map_editor.php?dtx=<?php echo (int)$dtx; ?>&dty=<?php echo (int)$l['dty']; ?><?php echo $q !== '' ? '&q=' . rawurlencode($q) : ''; ?>">编辑</a></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table></div>
    <?php endif; ?>
</div>

<div class="panel extra-panel">
    <div class="panel-head"><h2>批量添加地点</h2><span class="muted">一次录入多个坐标，已有坐标不会被覆盖</span></div>
    <?php if (!$zone): ?>
        <p class="extra-note">请先选择地图区域。</p>
    <?php elseif (gm_can_write()): ?>
        <form method="post" style="padding:0 0 4px">
            <?php echo gm_token_field(); ?>
            <input type="hidden" name="action" value="batch_add_loc">
            <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
            <input type="hidden" name="dtx" value="<?php echo (int)$dtx; ?>">
            <div class="extra-form-grid">
                <label>起始坐标 dty（只对没写坐标的行生效）<input type="number" name="start_dty" min="0" value="<?php
                    $__maxDty = -1;
                    foreach ($locs as $__l) { if ((int)$__l['dty'] > $__maxDty) $__maxDty = (int)$__l['dty']; }
                    echo $__maxDty >= 0 ? ($__maxDty + 1) : 0;
                ?>"></label>
            </div>
            <div class="extra-field">
                <label>地点清单（一行一个）<textarea name="batch_locs" rows="10" placeholder="0 山门
1 前殿
2,后殿,一座古庙的后院
偏殿" required></textarea></label>
            </div>
            <p class="extra-note">每行一种写法：<code>坐标 名称</code>、<code>坐标,名称</code>、<code>坐标,名称,描述</code>，或只写名称（从上面的起始坐标起自动往后排）。也可以直接粘贴 <code>城南荒野(6, 0)(危)  城南荒野，往哪走呢？…</code> 这种行，会自动把括号前的当名称、后面的当描述。空行和以 # 开头的行会跳过。</p>
            <button class="btn primary">批量添加</button>
        </form>
    <?php else: ?>
        <p class="extra-note">只读账号无法编辑。</p>
    <?php endif; ?>
</div>

<div class="panel extra-panel">
    <div class="panel-head"><h2><?php echo $loc ? '编辑地图地点' : '新增地图地点'; ?></h2><span class="muted">修改名称和描述会同步到地图文件，不会删除未改到的字段和其它坐标</span></div>
    <?php if (!$zone): ?>
        <p class="extra-note">请先选择地图区域。</p>
    <?php elseif (gm_can_write()): ?>
        <form method="post" style="padding:0 0 4px">
            <?php echo gm_token_field(); ?>
            <input type="hidden" name="action" value="save_loc">
            <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
            <div class="extra-form-grid">
                <label>地图编号 dtx<input type="number" name="dtx" value="<?php echo (int)$dtx; ?>" min="0" required></label>
                <label>坐标 dty<input type="number" name="dty" value="<?php echo $loc ? (int)$loc['dty'] : ($dty >= 0 ? (int)$dty : ''); ?>" min="0" required></label>
                <label>地点名称<input name="name" maxlength="64" required value="<?php echo $loc ? gm_h($loc['name']) : ''; ?>"></label>
                <label>怪物刷新文件 monster_inc / gw<input name="monster_inc" maxlength="128" value="<?php echo $loc ? gm_h($loc['monster_inc']) : ''; ?>" placeholder="例如 ./gw/bjt.php"></label>
                <label>旧 NPC 渲染文件 include_before<input name="include_before" maxlength="128" value="<?php echo $loc ? gm_h($loc['include_before']) : ''; ?>"></label>
            </div>
            <div class="extra-field"><label>地点描述 descr / desc<textarea name="descr" rows="3"><?php echo $loc ? gm_h($loc['descr']) : ''; ?></textarea></label></div>
            <div class="extra-field">
                <label>正文顺序 body（高级设置）<textarea class="extra-textarea" name="body" rows="4"><?php echo $loc ? gm_h($loc['body']) : ''; ?></textarea></label>
                <small>此字段目前保存原文，不自动改写。不了解 JSON 结构时请保持原样。</small>
            </div>
            <button class="btn primary">保存地点</button>
        </form>
    <?php else: ?>
        <p class="extra-note">只读账号无法编辑。</p>
    <?php endif; ?>
</div>

<?php if ($loc): ?>
<div class="panel extra-panel">
    <div class="panel-head"><h2>出口管理</h2><span class="muted">同一地点同一方向只能配置一个出口</span></div>
    <?php if (gm_can_write()): ?>
        <form method="post" style="padding:14px;background:#f8fafc;margin:0 0 12px;border-radius:8px">
            <?php echo gm_token_field(); ?>
            <input type="hidden" name="action" value="save_exit">
            <input type="hidden" name="dtx" value="<?php echo (int)$dtx; ?>">
            <input type="hidden" name="dty" value="<?php echo (int)$dty; ?>">
            <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
            <div class="extra-form-grid">
                <label>方向<select name="dir"><?php foreach ($dirs as $k => $v): ?><option value="<?php echo gm_h($k); ?>"><?php echo gm_h($v . '（' . $k . '）'); ?></option><?php endforeach; ?></select></label>
                <label>出口名称<input name="name" required maxlength="64"></label>
                <label>显示文字 label<input name="label" maxlength="64" placeholder="例如：上：长安广场"></label>
                <label>目标地图 to_dtx<input type="number" name="to_dtx" min="0" required value="<?php echo (int)$dtx; ?>"></label>
                <label>目标坐标 to_dty<input type="number" name="to_dty" min="0" required></label>
                <label>本图地点快捷选择
                    <select onchange="if(this.value!==''){var p=this.value.split('_');var f=this.form;f.to_dtx.value=p[0];f.to_dty.value=p[1];if(!f.name.value)f.name.value=this.options[this.selectedIndex].getAttribute('data-name');}">
                        <option value="">选择后填入目标坐标</option>
                        <?php
                        $allHere = gm_rows('SELECT dty,name FROM map_loc WHERE dtx=? ORDER BY dty', 'i', array($dtx));
                        foreach ($allHere as $t):
                        ?>
                        <option value="<?php echo (int)$dtx . '_' . (int)$t['dty']; ?>" data-name="<?php echo gm_h($t['name']); ?>"><?php echo (int)$dtx . '_' . (int)$t['dty'] . ' - ' . gm_h($t['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>排序 seq<input type="number" name="seq" value="<?php echo (int)$nextExitSeq; ?>"></label>
            </div>
            <p class="extra-note">目标地图和目标坐标必须对应一个已存在的地点。跨图出口请直接填写对方的 dtx / dty。</p>
            <p class="extra-note">像参考服「发现新区域 / 进入长安城」这种入口：方向选「离开（out）」或「进入（in）」，出口名称和显示文字都填「进入长安城」，目标地图填对方的 dtx，目标坐标填对方的 dty。例如从城南荒野(4，5)进长安，目标是长安城（dtx=1）的泾水桥南（dty=151）。页面会自动在「请选择出口」上方显示「发现新区域」和这条链接。同一格已经用了离开时，可以用进入或扩展出口 X1。</p>
            <button class="btn primary">保存出口</button>
        </form>
    <?php endif; ?>
    <div class="table-wrap"><table>
        <thead><tr><th>方向</th><th>出口名称</th><th>显示文字</th><th>目的地</th><th>排序</th><th>操作</th></tr></thead>
        <tbody>
        <?php if (!$exits): ?>
            <tr><td colspan="6">还没有出口。</td></tr>
        <?php else: foreach ($exits as $e):
            $tdtx = $e['to_dtx'] === null || $e['to_dtx'] === '' ? $dtx : (int)$e['to_dtx'];
        ?>
            <tr>
                <td><?php echo gm_h(isset($dirs[$e['dir']]) ? $dirs[$e['dir']] : $e['dir']); ?><br><code><?php echo gm_h($e['dir']); ?></code></td>
                <td><?php echo gm_h($e['name']); ?></td>
                <td><?php echo gm_h($e['label']); ?></td>
                <td><?php echo (int)$tdtx . '_' . (int)$e['to_dty']; ?></td>
                <td><?php echo (int)$e['seq']; ?></td>
                <td>
                    <?php if (gm_can_write()): ?>
                    <form method="post" class="inline-form" onsubmit="return confirm('确定删除这个出口？');">
                        <?php echo gm_token_field(); ?>
                        <input type="hidden" name="action" value="delete_exit">
                        <input type="hidden" name="dtx" value="<?php echo (int)$dtx; ?>">
                        <input type="hidden" name="dty" value="<?php echo (int)$dty; ?>">
                        <input type="hidden" name="dir" value="<?php echo gm_h($e['dir']); ?>">
                        <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
                        <button class="link-button danger-link">删除出口</button>
                    </form>
                    <?php else: ?>只读<?php endif; ?>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table></div>
</div>

<div class="panel">
    <div class="panel-head"><h2>地图 NPC 放置</h2><span class="muted">只移动地图引用，不删除 NPC 定义</span></div>
    <?php if (gm_can_write()): ?>
        <form method="get" class="search-row">
            <input type="hidden" name="dtx" value="<?php echo (int)$dtx; ?>">
            <input type="hidden" name="dty" value="<?php echo (int)$dty; ?>">
            <?php if ($q !== ''): ?><input type="hidden" name="q" value="<?php echo gm_h($q); ?>"><?php endif; ?>
            <label>搜索 NPC<input type="text" name="npc_q" value="<?php echo gm_h($npcQ); ?>" placeholder="名称 / ID / 旧编号"></label>
            <button class="btn">筛选 NPC</button>
        </form>
        <form method="post" style="padding:0 0 14px">
            <input type="hidden" name="action" value="place_npc">
            <?php echo gm_token_field(); ?>
            <input type="hidden" name="dtx" value="<?php echo (int)$dtx; ?>">
            <input type="hidden" name="dty" value="<?php echo (int)$dty; ?>">
            <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
            <input type="hidden" name="npc_q" value="<?php echo gm_h($npcQ); ?>">
            <div class="extra-form-grid">
                <label>选择 NPC
                    <select name="npc_id">
                        <?php if (!$npcs): ?>
                        <option value="">没有可放置的 NPC<?php echo $npcQ !== '' ? '（请调整搜索）' : ''; ?></option>
                        <?php else: foreach ($npcs as $n): ?>
                        <option value="<?php echo (int)$n['id']; ?>"><?php echo (int)$n['id'] . ' / 旧编号 ' . (int)$n['legacy_id'] . ' - ' . gm_h($n['name']); ?></option>
                        <?php endforeach; endif; ?>
                    </select>
                </label>
                <label>显示位置
                    <select name="pos">
                        <?php foreach ($posLabels as $pk => $pv): ?>
                        <option value="<?php echo gm_h($pk); ?>"><?php echo gm_h($pv . '（' . $pk . '）'); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
            <button class="btn primary">放置 NPC</button>
        </form>
    <?php endif; ?>
    <div class="table-wrap"><table>
        <thead><tr><th>顺序</th><th>NPC</th><th>位置</th><th>操作</th></tr></thead>
        <tbody>
        <?php if (!$placed): ?>
            <tr><td colspan="4">此地点还没有放置 NPC。</td></tr>
        <?php else: foreach ($placed as $p): ?>
            <tr>
                <td><?php echo (int)$p['seq']; ?></td>
                <td><?php echo (int)$p['npc_id'] . ' - ' . gm_h($p['npc_name']); ?></td>
                <td><?php echo gm_h(isset($posLabels[$p['pos']]) ? $posLabels[$p['pos']] : $p['pos']); ?></td>
                <td>
                    <?php if (gm_can_write()): ?>
                    <form method="post" class="inline-form" style="display:flex;gap:5px;flex-wrap:wrap;align-items:center">
                        <?php echo gm_token_field(); ?>
                        <input type="hidden" name="action" value="edit_npc_placement">
                        <input type="hidden" name="dtx" value="<?php echo (int)$dtx; ?>">
                        <input type="hidden" name="dty" value="<?php echo (int)$dty; ?>">
                        <input type="hidden" name="old_seq" value="<?php echo (int)$p['seq']; ?>">
                        <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
                        <input type="number" name="new_seq" value="<?php echo (int)$p['seq']; ?>" style="width:76px" title="显示顺序">
                        <select name="pos">
                            <?php foreach ($posLabels as $pk => $pv): ?>
                            <option value="<?php echo gm_h($pk); ?>"<?php echo $p['pos'] === $pk ? ' selected' : ''; ?>><?php echo gm_h($pv); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button class="link-button">保存</button>
                    </form>
                    <form method="post" class="inline-form" onsubmit="return confirm('只移除地图上的 NPC，不会删除 NPC 本身。确定？');">
                        <?php echo gm_token_field(); ?>
                        <input type="hidden" name="action" value="remove_npc">
                        <input type="hidden" name="dtx" value="<?php echo (int)$dtx; ?>">
                        <input type="hidden" name="dty" value="<?php echo (int)$dty; ?>">
                        <input type="hidden" name="seq" value="<?php echo (int)$p['seq']; ?>">
                        <input type="hidden" name="q" value="<?php echo gm_h($q); ?>">
                        <button class="link-button danger-link">移除放置</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table></div>
</div>
<?php endif; ?>

<div class="notice warn">安全提示：本页不会一键删除整张地图，也不会批量删除地点或删除 map/data/*.php 地图脚本。可以删除单条出口，或移除地图上的 NPC 放置。新增地图区域后，请确认对应地图资源文件和游戏调用都正确。编辑 body、monster_inc、include_before 属于高级操作。</div>
<?php endif; ?>
<?php gm_extra_footer(); ?>
