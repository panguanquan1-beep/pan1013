<?php
/**
 * GM 地图编辑管理辅助函数
 * 同步写入数据库与 fqxy/map/data/{map_key}.php，不调用 map_import_all()。
 */

function map_editor_map_root()
{
    return dirname(__DIR__) . '/map';
}

function map_editor_data_dir()
{
    return map_editor_map_root() . '/data';
}

function map_editor_file_map_path()
{
    return map_editor_map_root() . '/map_file_map.php';
}

function map_editor_safe_key($mapKey)
{
    $mapKey = trim((string)$mapKey);
    if (!preg_match('/^[A-Za-z0-9_-]{1,32}$/', $mapKey)) return '';
    return $mapKey;
}

function map_editor_data_file($mapKey)
{
    $mapKey = map_editor_safe_key($mapKey);
    if ($mapKey === '') return '';
    return map_editor_data_dir() . '/' . $mapKey . '.php';
}

function map_editor_tables_ok()
{
    return gm_table_exists('map_zone') && gm_table_exists('map_loc') && gm_table_exists('map_exit') && gm_table_exists('map_npc');
}

function map_editor_ensure_tables()
{
    $sql = array(
        'map_exit' => "CREATE TABLE IF NOT EXISTS `map_exit` (
  `dtx` int(11) NOT NULL,
  `dty` int(11) NOT NULL,
  `dir` varchar(16) NOT NULL,
  `name` varchar(64) NOT NULL,
  `label` varchar(64) DEFAULT NULL,
  `to_dtx` int(11) DEFAULT NULL,
  `to_dty` int(11) DEFAULT NULL,
  `seq` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`dtx`,`dty`,`dir`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'map_loc' => "CREATE TABLE IF NOT EXISTS `map_loc` (
  `dtx` int(11) NOT NULL,
  `dty` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `descr` varchar(500) DEFAULT NULL,
  `monster_inc` varchar(128) DEFAULT NULL COMMENT '旧怪物刷新文件（gw）',
  `include_before` varchar(128) DEFAULT NULL COMMENT '旧 NPC 渲染文件（过渡）',
  `body` text COMMENT '出口前正文顺序 [{n:seq}|{x:dir}|{t:文字}]',
  PRIMARY KEY (`dtx`,`dty`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'map_npc' => "CREATE TABLE IF NOT EXISTS `map_npc` (
  `dtx` int(11) NOT NULL,
  `dty` int(11) NOT NULL,
  `seq` int(11) NOT NULL,
  `npc_id` int(11) NOT NULL,
  `pos` varchar(16) NOT NULL DEFAULT 'below_img',
  PRIMARY KEY (`dtx`,`dty`,`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
        'map_zone' => "CREATE TABLE IF NOT EXISTS `map_zone` (
  `dtx` int(11) NOT NULL,
  `map_key` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`dtx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
    $created = array();
    $db = gm_db();
    foreach ($sql as $name => $query) {
        $existed = gm_table_exists($name);
        if (!$db->query($query)) {
            return array('ok' => false, 'error' => $db->error, 'created' => $created);
        }
        if (!$existed && gm_table_exists($name)) $created[] = $name;
    }
    $repair = dirname(dirname(__DIR__)) . '/lib/MapExitRepair.php';
    if (is_file($repair)) {
        require_once $repair;
        if (class_exists('MapExitRepair')) {
            MapExitRepair::ensure();
        }
    }
    return array('ok' => true, 'error' => '', 'created' => $created);
}

function map_editor_backup_file($path)
{
    if (!is_file($path)) return true;
    $bak = $path . '.bak-' . date('Ymd-His');
    return @copy($path, $bak) ? true : false;
}

function map_editor_export_value($value, $indent)
{
    $pad = str_repeat('    ', $indent);
    $pad1 = str_repeat('    ', $indent + 1);
    if (is_array($value)) {
        if ($value === array()) return 'array()';
        $isList = true;
        $i = 0;
        foreach ($value as $k => $v) {
            if ($k !== $i) {
                $isList = false;
                break;
            }
            $i++;
        }
        $lines = array('array(');
        foreach ($value as $k => $v) {
            if ($isList) {
                $lines[] = $pad1 . map_editor_export_value($v, $indent + 1) . ',';
            } else {
                if (is_int($k) || (is_string($k) && preg_match('/^-?\d+$/', $k) && (string)(int)$k === (string)$k)) {
                    $key = (string)(int)$k;
                } else {
                    $key = var_export((string)$k, true);
                }
                $lines[] = $pad1 . $key . ' => ' . map_editor_export_value($v, $indent + 1) . ',';
            }
        }
        $lines[] = $pad . ')';
        return implode("\n", $lines);
    }
    if ($value === null) return 'null';
    if (is_bool($value)) return $value ? 'true' : 'false';
    if (is_int($value) || is_float($value)) return (string)$value;
    return var_export((string)$value, true);
}

function map_editor_write_php_return($path, $data, $header)
{
    map_editor_backup_file($path);
    $src = "<?php\n" . $header . "return " . map_editor_export_value($data, 0) . ";\n";
    if (!class_exists('DbIniStore', false)) {
        return file_put_contents($path, $src) !== false;
    }
    return DbIniStore::filePutContents($path, $src) !== false;
}

function map_editor_write_map_data($mapKey, $data)
{
    $path = map_editor_data_file($mapKey);
    if ($path === '') return false;
    if (!is_array($data)) $data = array();
    ksort($data, SORT_NUMERIC);
    $header = "/** 由 GM 地图编辑管理保存 */\n";
    return map_editor_write_php_return($path, $data, $header);
}

function map_editor_load_file_map()
{
    $path = map_editor_file_map_path();
    if (!is_file($path)) return array();
    $data = include $path;
    return is_array($data) ? $data : array();
}

function map_editor_update_file_map($dtx, $mapKey)
{
    $dtx = (int)$dtx;
    $mapKey = map_editor_safe_key($mapKey);
    if ($mapKey === '') return false;
    $data = map_editor_load_file_map();
    if (isset($data[$dtx]) && $data[$dtx] === $mapKey) return true;
    $data[$dtx] = $mapKey;
    ksort($data, SORT_NUMERIC);
    $header = "/**\n * dtx => 数据文件名 完整映射\n * MapMover 与 map_loader 共用\n */\n";
    return map_editor_write_php_return(map_editor_file_map_path(), $data, $header);
}

function map_editor_load_map_data($mapKey)
{
    $file = map_editor_data_file($mapKey);
    if ($file === '' || !is_file($file)) return array();
    $data = include $file;
    return is_array($data) ? $data : array();
}

function map_editor_file_exists($mapKey)
{
    $file = map_editor_data_file($mapKey);
    return $file !== '' && is_file($file);
}

function map_editor_db_exits_for_file($dtx, $dty, $oldExits)
{
    if (!is_array($oldExits)) $oldExits = array();
    $rows = gm_rows('SELECT * FROM map_exit WHERE dtx=? AND dty=? ORDER BY seq,dir', 'ii', array((int)$dtx, (int)$dty));
    $out = array();
    foreach ($rows as $r) {
        $dir = (string)$r['dir'];
        $e = array('name' => (string)$r['name']);
        if ($r['label'] !== null && $r['label'] !== '') $e['label'] = (string)$r['label'];
        if ($r['to_dty'] !== null && $r['to_dty'] !== '') $e['dty'] = (int)$r['to_dty'];
        if ($r['to_dtx'] !== null && $r['to_dtx'] !== '' && (int)$r['to_dtx'] !== (int)$dtx) {
            $e['dtx'] = (int)$r['to_dtx'];
        }
        if ((int)$r['seq'] !== 0) $e['seq'] = (int)$r['seq'];
        if (isset($oldExits[$dir]) && is_array($oldExits[$dir])) {
            foreach ($oldExits[$dir] as $k => $v) {
                if (!in_array($k, array('name', 'label', 'dtx', 'dty', 'seq'), true)) $e[$k] = $v;
            }
        }
        $out[$dir] = $e;
    }
    return $out;
}

function map_editor_db_npcs_for_file($dtx, $dty, $oldNpcs)
{
    $oldById = array();
    if (is_array($oldNpcs)) {
        foreach ($oldNpcs as $n) {
            if (is_array($n) && isset($n['id'])) $oldById[(int)$n['id']] = $n;
        }
    }
    $sql = 'SELECT m.seq,m.pos,n.legacy_id,n.name,n.page,n.color FROM map_npc m LEFT JOIN npc_def n ON n.id=m.npc_id WHERE m.dtx=? AND m.dty=? ORDER BY m.seq';
    $rows = gm_table_exists('npc_def') ? gm_rows($sql, 'ii', array((int)$dtx, (int)$dty)) : array();
    $out = array();
    foreach ($rows as $r) {
        $lid = (int)$r['legacy_id'];
        $item = array(
            'id' => $lid,
            'name' => (string)$r['name'],
            'cmd' => (int)$r['page'],
            'color' => $r['color'] !== null && $r['color'] !== '' ? (string)$r['color'] : 'blue',
            'pos' => $r['pos'] !== null && $r['pos'] !== '' ? (string)$r['pos'] : 'below_img',
        );
        if (isset($oldById[$lid]) && is_array($oldById[$lid])) {
            foreach ($oldById[$lid] as $k => $v) {
                if (!in_array($k, array('id', 'name', 'cmd', 'color', 'pos'), true)) $item[$k] = $v;
            }
        }
        $out[] = $item;
    }
    return $out;
}

function map_editor_sync_dtx_to_file($dtx, $change)
{
    $dtx = (int)$dtx;
    $zone = gm_one('SELECT * FROM map_zone WHERE dtx=?', 'i', array($dtx));
    if (!$zone) return array('ok' => false, 'error' => '找不到地图区域，无法同步文件。');
    $mapKey = map_editor_safe_key($zone['map_key']);
    if ($mapKey === '') return array('ok' => false, 'error' => 'map_key 不合法，未写入文件。');
    if (!map_editor_update_file_map($dtx, $mapKey)) {
        return array('ok' => false, 'error' => '更新 map_file_map.php 失败，请检查文件权限。');
    }
    $file = map_editor_data_file($mapKey);
    $kind = isset($change['changed']) ? $change['changed'] : 'zone';
    $focusDty = isset($change['dty']) ? (int)$change['dty'] : -1;
    $data = map_editor_load_map_data($mapKey);

    if ($kind === 'zone') {
        if (!is_file($file)) {
            if (!map_editor_write_map_data($mapKey, $data)) {
                return array('ok' => false, 'error' => '创建地图文件失败，请检查 data 目录权限。');
            }
        }
        return array('ok' => true, 'error' => '');
    }

    if ($focusDty < 0) return array('ok' => true, 'error' => '');

    if (!isset($data[$focusDty]) || !is_array($data[$focusDty])) $data[$focusDty] = array();
    $room = $data[$focusDty];

    if ($kind === 'loc') {
        $loc = gm_one('SELECT * FROM map_loc WHERE dtx=? AND dty=?', 'ii', array($dtx, $focusDty));
        if (!$loc) return array('ok' => true, 'error' => '');
        $room['name'] = $loc['name'];
        if ($loc['descr'] !== null && $loc['descr'] !== '') $room['desc'] = $loc['descr'];
        else unset($room['desc']);
        if ($loc['monster_inc'] !== null && $loc['monster_inc'] !== '') $room['gw'] = $loc['monster_inc'];
        else unset($room['gw']);
        if ($loc['include_before'] !== null && $loc['include_before'] !== '') $room['include_before'] = $loc['include_before'];
        else unset($room['include_before']);
        if ($loc['body'] !== null && trim((string)$loc['body']) !== '') {
            $decoded = json_decode($loc['body'], true);
            $room['body'] = (json_last_error() === JSON_ERROR_NONE) ? $decoded : $loc['body'];
        } else {
            unset($room['body']);
        }
        if (!isset($room['exits']) || !is_array($room['exits'])) $room['exits'] = array();
    } elseif ($kind === 'exits') {
        $old = isset($room['exits']) && is_array($room['exits']) ? $room['exits'] : array();
        $room['exits'] = map_editor_db_exits_for_file($dtx, $focusDty, $old);
    } elseif ($kind === 'npcs') {
        $old = isset($room['npcs']) && is_array($room['npcs']) ? $room['npcs'] : array();
        $npcs = map_editor_db_npcs_for_file($dtx, $focusDty, $old);
        if ($npcs) $room['npcs'] = $npcs;
        else unset($room['npcs']);
    }

    $data[$focusDty] = $room;
    if (!map_editor_write_map_data($mapKey, $data)) {
        return array('ok' => false, 'error' => '数据库已保存，但写入 map/data/' . $mapKey . '.php 失败，请检查文件权限。');
    }
    return array('ok' => true, 'error' => '');
}

function map_editor_copy_key_file($oldKey, $newKey)
{
    $oldKey = map_editor_safe_key($oldKey);
    $newKey = map_editor_safe_key($newKey);
    if ($oldKey === '' || $newKey === '' || $oldKey === $newKey) return true;
    $oldFile = map_editor_data_file($oldKey);
    $newFile = map_editor_data_file($newKey);
    if ($oldFile === '' || $newFile === '') return false;
    if (is_file($oldFile) && !is_file($newFile)) {
        return @copy($oldFile, $newFile) ? true : false;
    }
    return true;
}

function map_editor_find_or_create_npc($legacyId, $name, $page, $color)
{
    if (!gm_table_exists('npc_def')) return 0;
    $legacyId = (int)$legacyId;
    $name = (string)$name;
    $page = (int)$page;
    $color = ($color !== null && $color !== '') ? (string)$color : 'blue';
    if ($color === '') $color = 'blue';
    if (strlen($color) > 16) $color = substr($color, 0, 16);
    $row = gm_one('SELECT id FROM npc_def WHERE legacy_id=? AND name=? AND page=? LIMIT 1', 'isi', array($legacyId, $name, $page));
    if ($row) return (int)$row['id'];
    $row = gm_one('SELECT id FROM npc_def WHERE legacy_id=? AND name=? LIMIT 1', 'is', array($legacyId, $name));
    if ($row) return (int)$row['id'];
    $ok = gm_exec('INSERT INTO npc_def (legacy_id,name,page,color) VALUES (?,?,?,?)', 'isis', array($legacyId, $name, $page, $color));
    if ($ok === false) return 0;
    return (int)gm_db()->insert_id;
}

function map_editor_empty_to_null($v)
{
    $v = trim((string)$v);
    return $v === '' ? null : $v;
}


function map_editor_insert_exit($dtx, $dty, $dir, $name, $label, $toDtx, $toDty, $seq)
{
    $cols = array('dtx', 'dty', 'dir', 'name', 'label', 'seq');
    $ph = array('?', '?', '?', '?', '?', '?');
    $types = 'iisssi';
    $params = array((int)$dtx, (int)$dty, (string)$dir, (string)$name, $label, (int)$seq);
    if ($toDtx !== null && $toDtx !== '') {
        $cols[] = 'to_dtx';
        $ph[] = '?';
        $types .= 'i';
        $params[] = (int)$toDtx;
    }
    if ($toDty !== null && $toDty !== '') {
        $cols[] = 'to_dty';
        $ph[] = '?';
        $types .= 'i';
        $params[] = (int)$toDty;
    }
    $sql = 'INSERT INTO map_exit (' . implode(',', $cols) . ') VALUES (' . implode(',', $ph) . ')';
    return gm_exec($sql, $types, $params) !== false;
}

function map_editor_import_dtx($dtx, $mapKey)
{
    $dtx = (int)$dtx;
    $mapKey = map_editor_safe_key($mapKey);
    if ($dtx < 0 || $mapKey === '') return array('ok' => false, 'error' => '地图编号或 map_key 不正确。', 'cnt' => array());
    $file = map_editor_data_file($mapKey);
    if ($file === '' || !is_file($file)) {
        return array('ok' => false, 'error' => '找不到地图文件 map/data/' . $mapKey . '.php。', 'cnt' => array());
    }
    $data = include $file;
    if (!is_array($data)) return array('ok' => false, 'error' => '地图文件格式不正确。', 'cnt' => array());

    $first = null;
    foreach ($data as $loc) {
        if (is_array($loc)) { $first = $loc; break; }
    }
    $zoneName = (is_array($first) && isset($first['name']) && $first['name'] !== '') ? (string)$first['name'] : $mapKey;
    $existZone = gm_one('SELECT name FROM map_zone WHERE dtx=?', 'i', array($dtx));
    if ($existZone && trim((string)$existZone['name']) !== '') $zoneName = $existZone['name'];

    $sameKey = gm_one('SELECT dtx FROM map_zone WHERE map_key=? AND dtx<>? LIMIT 1', 'si', array($mapKey, $dtx));
    if ($sameKey) {
        return array('ok' => false, 'error' => '地图键名已被地图编号 ' . $sameKey['dtx'] . ' 使用。', 'cnt' => array());
    }

    $db = gm_db();
    $db->begin_transaction();
    if (gm_exec('DELETE FROM map_npc WHERE dtx=?', 'i', array($dtx)) === false
        || gm_exec('DELETE FROM map_exit WHERE dtx=?', 'i', array($dtx)) === false
        || gm_exec('DELETE FROM map_loc WHERE dtx=?', 'i', array($dtx)) === false) {
        $db->rollback();
        return array('ok' => false, 'error' => '清理旧地图数据失败。', 'cnt' => array());
    }
    if ($existZone) {
        $okz = gm_exec('UPDATE map_zone SET map_key=?,name=? WHERE dtx=?', 'ssi', array($mapKey, $zoneName, $dtx));
    } else {
        $okz = gm_exec('INSERT INTO map_zone (dtx,map_key,name) VALUES (?,?,?)', 'iss', array($dtx, $mapKey, $zoneName));
    }
    if ($okz === false) {
        $db->rollback();
        return array('ok' => false, 'error' => '保存地图区域失败。', 'cnt' => array());
    }

    $cnt = array('zone' => 1, 'loc' => 0, 'exit' => 0, 'npc' => 0);
    foreach ($data as $dty => $loc) {
        if (!is_array($loc)) continue;
        $dty = (int)$dty;
        $name = isset($loc['name']) && $loc['name'] !== '' ? (string)$loc['name'] : '未知地点';
        $desc = isset($loc['desc']) ? (string)$loc['desc'] : null;
        $gw = isset($loc['gw']) && $loc['gw'] !== '' ? (string)$loc['gw'] : null;
        $ib = isset($loc['include_before']) && $loc['include_before'] !== '' ? (string)$loc['include_before'] : null;
        $body = null;
        if (isset($loc['body'])) {
            $body = is_string($loc['body']) ? $loc['body'] : json_encode($loc['body']);
        }
        $okl = gm_exec(
            'INSERT INTO map_loc (dtx,dty,name,descr,monster_inc,include_before,body) VALUES (?,?,?,?,?,?,?)',
            'iisssss',
            array($dtx, $dty, $name, $desc, $gw, $ib, $body)
        );
        if ($okl === false) {
            $db->rollback();
            return array('ok' => false, 'error' => '导入地点 ' . $dtx . '_' . $dty . ' 失败。', 'cnt' => $cnt);
        }
        $cnt['loc']++;
        if (!empty($loc['exits']) && is_array($loc['exits'])) {
            $exitSeq = 0;
            foreach ($loc['exits'] as $dir => $x) {
                if (!is_array($x)) continue;
                $dir = substr((string)$dir, 0, 16);
                if ($dir === '') continue;
                $xn = isset($x['name']) ? (string)$x['name'] : '';
                $xl = isset($x['label']) ? (string)$x['label'] : null;
                $seq = isset($x['seq']) ? (int)$x['seq'] : $exitSeq;
                $tx = isset($x['dtx']) ? (int)$x['dtx'] : null;
                $ty = isset($x['dty']) ? (int)$x['dty'] : null;
                $oke = map_editor_insert_exit($dtx, $dty, $dir, $xn, $xl, $tx, $ty, $seq);
                if ($oke === false) {
                    $db->rollback();
                    return array('ok' => false, 'error' => '导入出口 ' . $dtx . '_' . $dty . '_' . $dir . ' 失败。', 'cnt' => $cnt);
                }
                $cnt['exit']++;
                $exitSeq++;
            }
        }
        if (!empty($loc['npcs']) && is_array($loc['npcs'])) {
            $seq = 0;
            foreach (array_values($loc['npcs']) as $n) {
                if (!is_array($n)) continue;
                $nid = map_editor_find_or_create_npc(
                    isset($n['id']) ? $n['id'] : 0,
                    isset($n['name']) ? $n['name'] : '',
                    isset($n['cmd']) ? $n['cmd'] : 7,
                    isset($n['color']) ? $n['color'] : 'blue'
                );
                if ($nid <= 0) continue;
                $pos = isset($n['pos']) && $n['pos'] !== '' ? substr((string)$n['pos'], 0, 16) : 'below_img';
                $okn = gm_exec('INSERT INTO map_npc (dtx,dty,seq,npc_id,pos) VALUES (?,?,?,?,?)', 'iiiis', array($dtx, $dty, $seq, $nid, $pos));
                if ($okn === false) {
                    $db->rollback();
                    return array('ok' => false, 'error' => '导入地图 NPC 失败。', 'cnt' => $cnt);
                }
                $cnt['npc']++;
                $seq++;
            }
        }
    }
    $db->commit();
    map_editor_update_file_map($dtx, $mapKey);
    return array('ok' => true, 'error' => '', 'cnt' => $cnt);
}

function map_editor_import_all_maps()
{
    @set_time_limit(180);
    $mf = map_editor_load_file_map();
    if (!$mf) return array('ok' => false, 'error' => 'map_file_map.php 为空或无法读取。', 'cnt' => array());
    $db = gm_db();
    $db->begin_transaction();
    // 只清空地图四张表，绝不 DELETE npc_def
    if (!$db->query('DELETE FROM map_npc') || !$db->query('DELETE FROM map_exit') || !$db->query('DELETE FROM map_loc') || !$db->query('DELETE FROM map_zone')) {
        $err = $db->error;
        $db->rollback();
        return array('ok' => false, 'error' => '清空地图表失败：' . $err, 'cnt' => array());
    }
    $db->commit();
    $total = array('zone' => 0, 'loc' => 0, 'exit' => 0, 'npc' => 0, 'maps' => 0, 'fail' => 0);
    $errors = array();
    foreach ($mf as $dtx => $key) {
        $r = map_editor_import_dtx((int)$dtx, $key);
        if (!$r['ok']) {
            $total['fail']++;
            $errors[] = $key . '(dtx=' . (int)$dtx . '): ' . $r['error'];
            continue;
        }
        $total['maps']++;
        foreach (array('zone', 'loc', 'exit', 'npc') as $k) {
            if (isset($r['cnt'][$k])) $total[$k] += (int)$r['cnt'][$k];
        }
    }
    $ok = $total['maps'] > 0;
    $msg = $errors ? implode('；', $errors) : '';
    return array('ok' => $ok, 'error' => $msg, 'cnt' => $total);
}

function map_editor_flash_sync($ok, $sync, $okMsg)
{
    if ($ok && $sync && !empty($sync['ok'])) {
        return array($okMsg . ' 已同时写入游戏地图文件和数据库。', 'success');
    }
    if ($ok) {
        $err = ($sync && isset($sync['error'])) ? $sync['error'] : '同步地图文件失败。';
        return array($okMsg . ' 但' . $err, 'warn');
    }
    return array('保存失败：请查看数据库错误或表结构。', 'error');
}

function map_editor_restore_sql_path()
{
    return __DIR__ . '/data/restore_map_tables_20261118.sql';
}

function map_editor_split_sql($sql)
{
    $stmts = array();
    $buf = '';
    $inStr = false;
    $esc = false;
    $len = strlen($sql);
    for ($i = 0; $i < $len; $i++) {
        $ch = $sql[$i];
        $buf .= $ch;
        if ($inStr) {
            if ($esc) $esc = false;
            elseif ($ch === '\\') $esc = true;
            elseif ($ch === "'") $inStr = false;
            continue;
        }
        if ($ch === "'") $inStr = true;
        elseif ($ch === ';') {
            $stmt = trim($buf);
            $buf = '';
            if ($stmt !== '' && $stmt !== ';') $stmts[] = $stmt;
        }
    }
    $tail = trim($buf);
    if ($tail !== '') $stmts[] = $tail;
    return $stmts;
}

function map_editor_restore_map_backup()
{
    @set_time_limit(180);
    $path = map_editor_restore_sql_path();
    if (!is_file($path)) return array('ok' => false, 'error' => '找不到恢复文件 gm_admin/data/restore_map_tables_20261118.sql。');
    $sql = file_get_contents($path);
    if ($sql === false || trim($sql) === '') return array('ok' => false, 'error' => '恢复文件是空的。');
    $cleanLines = array();
    foreach (preg_split("/\r\n|\n|\r/", $sql) as $line) {
        if (strpos(ltrim($line), '--') === 0) continue;
        $cleanLines[] = $line;
    }
    $stmts = map_editor_split_sql(implode("
", $cleanLines));
    if (!$stmts) return array('ok' => false, 'error' => '恢复文件里没有可执行的语句。');
    $db = gm_db();
    $db->begin_transaction();
    foreach ($stmts as $stmt) {
        $trim = ltrim($stmt);
        if ($trim === '' || strpos($trim, '--') === 0) continue;
        if (!$db->query($stmt)) {
            $err = $db->error;
            $db->rollback();
            return array('ok' => false, 'error' => '恢复失败：' . $err);
        }
    }
    $db->commit();
    return array('ok' => true, 'error' => '');
}

function map_editor_export_dtx_to_file($dtx)
{
    $dtx = (int)$dtx;
    $zone = gm_one('SELECT * FROM map_zone WHERE dtx=?', 'i', array($dtx));
    if (!$zone) return array('ok' => false, 'error' => '找不到地图 ' . $dtx);
    $mapKey = map_editor_safe_key($zone['map_key']);
    if ($mapKey === '') return array('ok' => false, 'error' => 'map_key 不合法：地图 ' . $dtx);
    if (!map_editor_update_file_map($dtx, $mapKey)) {
        return array('ok' => false, 'error' => '更新 map_file_map.php 失败。');
    }
    $old = map_editor_load_map_data($mapKey);
    $locs = gm_rows('SELECT * FROM map_loc WHERE dtx=? ORDER BY dty', 'i', array($dtx));
    $data = array();
    foreach ($locs as $loc) {
        $dty = (int)$loc['dty'];
        $oldRoom = (isset($old[$dty]) && is_array($old[$dty])) ? $old[$dty] : array();
        $room = array('name' => (string)$loc['name']);
        if ($loc['descr'] !== null && $loc['descr'] !== '') $room['desc'] = (string)$loc['descr'];
        if ($loc['monster_inc'] !== null && $loc['monster_inc'] !== '') $room['gw'] = (string)$loc['monster_inc'];
        if ($loc['include_before'] !== null && $loc['include_before'] !== '') $room['include_before'] = (string)$loc['include_before'];
        if ($loc['body'] !== null && $loc['body'] !== '') {
            $decoded = json_decode($loc['body'], true);
            $room['body'] = (json_last_error() === JSON_ERROR_NONE) ? $decoded : (string)$loc['body'];
        }
        $exits = map_editor_db_exits_for_file($dtx, $dty, isset($oldRoom['exits']) ? $oldRoom['exits'] : array());
        if ($exits) $room['exits'] = $exits;
        $npcs = map_editor_db_npcs_for_file($dtx, $dty, isset($oldRoom['npcs']) ? $oldRoom['npcs'] : array());
        if ($npcs) $room['npcs'] = $npcs;
        $data[$dty] = $room;
    }
    if (!map_editor_write_map_data($mapKey, $data)) {
        return array('ok' => false, 'error' => '写入 map/data/' . $mapKey . '.php 失败，请检查文件权限。');
    }
    return array('ok' => true, 'error' => '', 'key' => $mapKey, 'loc' => count($data));
}

function map_editor_export_all_to_files()
{
    @set_time_limit(180);
    $zones = gm_rows('SELECT dtx FROM map_zone ORDER BY dtx', '', array());
    $okn = 0;
    $errors = array();
    foreach ($zones as $z) {
        $r = map_editor_export_dtx_to_file((int)$z['dtx']);
        if (!empty($r['ok'])) $okn++;
        else $errors[] = 'dtx=' . (int)$z['dtx'] . ' ' . (isset($r['error']) ? $r['error'] : '失败');
    }
    return array('ok' => $okn > 0, 'maps' => $okn, 'error' => $errors ? implode('；', $errors) : '');
}

function map_editor_snapshot_map_tables()
{
    return array(
        'zone' => gm_rows('SELECT * FROM map_zone ORDER BY dtx', '', array()),
        'loc' => gm_rows('SELECT * FROM map_loc ORDER BY dtx,dty', '', array()),
        'exit' => gm_rows('SELECT * FROM map_exit ORDER BY dtx,dty,dir', '', array()),
        'npc' => gm_rows('SELECT * FROM map_npc ORDER BY dtx,dty,seq', '', array()),
    );
}

function map_editor_group_by_dtx($rows)
{
    $out = array();
    if (!is_array($rows)) return $out;
    foreach ($rows as $r) {
        $dtx = (int)$r['dtx'];
        if (!isset($out[$dtx])) $out[$dtx] = array();
        $out[$dtx][] = $r;
    }
    return $out;
}

function map_editor_is_wsc_dtx($dtx, $zoneRow)
{
    if ((int)$dtx === 47) return true;
    if ($zoneRow && isset($zoneRow['map_key']) && $zoneRow['map_key'] === 'wsc') return true;
    return false;
}

function map_editor_layout_sig($locs, $exits)
{
    $parts = array();
    if (!is_array($locs)) $locs = array();
    if (!is_array($exits)) $exits = array();
    foreach ($locs as $r) {
        $parts[] = 'L:' . (int)$r['dty'] . ':'
            . (isset($r['name']) ? $r['name'] : '') . ':'
            . (isset($r['descr']) ? $r['descr'] : '') . ':'
            . (isset($r['monster_inc']) ? $r['monster_inc'] : '') . ':'
            . (isset($r['include_before']) ? $r['include_before'] : '');
    }
    foreach ($exits as $r) {
        $parts[] = 'E:' . (int)$r['dty'] . ':'
            . (isset($r['dir']) ? $r['dir'] : '') . ':'
            . (isset($r['name']) ? $r['name'] : '') . ':'
            . (isset($r['label']) ? $r['label'] : '') . ':'
            . (isset($r['to_dtx']) ? $r['to_dtx'] : '') . ':'
            . (isset($r['to_dty']) ? $r['to_dty'] : '') . ':'
            . (isset($r['seq']) ? $r['seq'] : '');
    }
    sort($parts);
    return implode("\n", $parts);
}

function map_editor_ensure_zone_row($row)
{
    $dtx = (int)$row['dtx'];
    $key = isset($row['map_key']) ? $row['map_key'] : '';
    $name = isset($row['name']) ? $row['name'] : '';
    $exist = gm_one('SELECT dtx FROM map_zone WHERE dtx=?', 'i', array($dtx));
    if ($exist) {
        return gm_exec('UPDATE map_zone SET map_key=?,name=? WHERE dtx=?', 'ssi', array($key, $name, $dtx)) !== false;
    }
    return gm_exec('INSERT INTO map_zone (dtx,map_key,name) VALUES (?,?,?)', 'iss', array($dtx, $key, $name)) !== false;
}

function map_editor_insert_loc_row($r)
{
    return gm_exec(
        'INSERT INTO map_loc (dtx,dty,name,descr,monster_inc,include_before,body) VALUES (?,?,?,?,?,?,?)',
        'iisssss',
        array(
            (int)$r['dtx'],
            (int)$r['dty'],
            (string)$r['name'],
            isset($r['descr']) ? $r['descr'] : null,
            isset($r['monster_inc']) ? $r['monster_inc'] : null,
            isset($r['include_before']) ? $r['include_before'] : null,
            isset($r['body']) ? $r['body'] : null,
        )
    ) !== false;
}

function map_editor_insert_exit_row($r)
{
    $toDtx = (isset($r['to_dtx']) && $r['to_dtx'] !== '') ? $r['to_dtx'] : null;
    $toDty = (isset($r['to_dty']) && $r['to_dty'] !== '') ? $r['to_dty'] : null;
    return map_editor_insert_exit(
        (int)$r['dtx'],
        (int)$r['dty'],
        (string)$r['dir'],
        isset($r['name']) ? (string)$r['name'] : '',
        isset($r['label']) ? $r['label'] : null,
        $toDtx,
        $toDty,
        isset($r['seq']) ? (int)$r['seq'] : 0
    );
}

function map_editor_insert_npc_row($r)
{
    return gm_exec(
        'INSERT INTO map_npc (dtx,dty,seq,npc_id,pos) VALUES (?,?,?,?,?)',
        'iiiis',
        array(
            (int)$r['dtx'],
            (int)$r['dty'],
            (int)$r['seq'],
            (int)$r['npc_id'],
            (isset($r['pos']) && $r['pos'] !== '') ? $r['pos'] : 'below_img',
        )
    ) !== false;
}

function map_editor_replace_dtx_layout($dtx, $locs, $exits)
{
    $dtx = (int)$dtx;
    if (gm_exec('DELETE FROM map_exit WHERE dtx=?', 'i', array($dtx)) === false) return '清理地图 ' . $dtx . ' 出口失败。';
    if (gm_exec('DELETE FROM map_loc WHERE dtx=?', 'i', array($dtx)) === false) return '清理地图 ' . $dtx . ' 地点失败。';
    if (is_array($locs)) {
        foreach ($locs as $r) {
            if (!map_editor_insert_loc_row($r)) return '写回地图 ' . $dtx . ' 地点失败。';
        }
    }
    if (is_array($exits)) {
        foreach ($exits as $r) {
            if (!map_editor_insert_exit_row($r)) return '写回地图 ' . $dtx . ' 出口失败。';
        }
    }
    return '';
}

function map_editor_replace_dtx_npcs($dtx, $npcs)
{
    $dtx = (int)$dtx;
    if (gm_exec('DELETE FROM map_npc WHERE dtx=?', 'i', array($dtx)) === false) return '清理地图 ' . $dtx . ' NPC 放置失败。';
    if (is_array($npcs)) {
        foreach ($npcs as $r) {
            if (!map_editor_insert_npc_row($r)) return '写回地图 ' . $dtx . ' NPC 放置失败。';
        }
    }
    return '';
}

function map_editor_merge_snapshot_npcs($dtx, $snapNpcs)
{
    $dtx = (int)$dtx;
    $cur = gm_rows('SELECT dty,npc_id,seq FROM map_npc WHERE dtx=?', 'i', array($dtx));
    $have = array();
    $maxSeq = -1;
    foreach ($cur as $c) {
        $have[(int)$c['dty'] . '_' . (int)$c['npc_id']] = 1;
        if ((int)$c['seq'] > $maxSeq) $maxSeq = (int)$c['seq'];
    }
    $seq = $maxSeq + 1;
    if (!is_array($snapNpcs)) return '';
    foreach ($snapNpcs as $r) {
        $k = (int)$r['dty'] . '_' . (int)$r['npc_id'];
        if (isset($have[$k])) continue;
        $r['seq'] = $seq;
        $seq++;
        if (!map_editor_insert_npc_row($r)) return '补回地图 ' . $dtx . ' 的新增 NPC 失败。';
    }
    return '';
}

function map_editor_merge_after_restore($snap)
{
    $zones = array();
    if (isset($snap['zone']) && is_array($snap['zone'])) {
        foreach ($snap['zone'] as $z) $zones[(int)$z['dtx']] = $z;
    }
    $sLoc = map_editor_group_by_dtx(isset($snap['loc']) ? $snap['loc'] : array());
    $sExit = map_editor_group_by_dtx(isset($snap['exit']) ? $snap['exit'] : array());
    $sNpc = map_editor_group_by_dtx(isset($snap['npc']) ? $snap['npc'] : array());
    $bLoc = map_editor_group_by_dtx(gm_rows('SELECT * FROM map_loc ORDER BY dtx,dty', '', array()));
    $bExit = map_editor_group_by_dtx(gm_rows('SELECT * FROM map_exit ORDER BY dtx,dty,dir', '', array()));

    $dtxs = array();
    foreach (array_keys($zones) as $d) $dtxs[(int)$d] = 1;
    foreach (array_keys($sLoc) as $d) $dtxs[(int)$d] = 1;
    foreach (array_keys($sExit) as $d) $dtxs[(int)$d] = 1;

    $kept = array();
    foreach ($dtxs as $dtx => $unused) {
        $zone = isset($zones[$dtx]) ? $zones[$dtx] : null;
        $isWsc = map_editor_is_wsc_dtx($dtx, $zone);
        $sn = isset($sLoc[$dtx]) ? count($sLoc[$dtx]) : 0;
        $bn = isset($bLoc[$dtx]) ? count($bLoc[$dtx]) : 0;
        $sigS = map_editor_layout_sig(isset($sLoc[$dtx]) ? $sLoc[$dtx] : array(), isset($sExit[$dtx]) ? $sExit[$dtx] : array());
        $sigB = map_editor_layout_sig(isset($bLoc[$dtx]) ? $bLoc[$dtx] : array(), isset($bExit[$dtx]) ? $bExit[$dtx] : array());
        $layoutChanged = ($sigS !== $sigB);
        $useSnapLayout = $isWsc || $sn > $bn || ($layoutChanged && $sn >= $bn && $sn > 0);
        if (!$useSnapLayout) continue;
        if ($zone) {
            if (!map_editor_ensure_zone_row($zone)) return array('ok' => false, 'error' => '写回地图区域 ' . $dtx . ' 失败。', 'kept' => $kept);
        }
        $err = map_editor_replace_dtx_layout($dtx, isset($sLoc[$dtx]) ? $sLoc[$dtx] : array(), isset($sExit[$dtx]) ? $sExit[$dtx] : array());
        if ($err !== '') return array('ok' => false, 'error' => $err, 'kept' => $kept);
        if ($isWsc || $sn > $bn) {
            $err = map_editor_replace_dtx_npcs($dtx, isset($sNpc[$dtx]) ? $sNpc[$dtx] : array());
        } else {
            $err = map_editor_merge_snapshot_npcs($dtx, isset($sNpc[$dtx]) ? $sNpc[$dtx] : array());
        }
        if ($err !== '') return array('ok' => false, 'error' => $err, 'kept' => $kept);
        if ($isWsc) $kept[] = '地图编号 47（枉死城，键名 wsc）';
        else {
            $key = ($zone && isset($zone['map_key'])) ? $zone['map_key'] : '';
            $kept[] = '地图编号 ' . $dtx . ($key !== '' ? '（' . $key . '）' : '');
        }
    }
    return array('ok' => true, 'error' => '', 'kept' => $kept);
}

function map_editor_restore_map_backup_keep_edits()
{
    @set_time_limit(180);
    $snap = map_editor_snapshot_map_tables();
    $r = map_editor_restore_map_backup();
    if (empty($r['ok'])) return $r;
    $m = map_editor_merge_after_restore($snap);
    if (empty($m['ok'])) {
        $m['restored'] = true;
        return $m;
    }
    $ex = map_editor_export_all_to_files();
    return array(
        'ok' => true,
        'error' => '',
        'kept' => isset($m['kept']) ? $m['kept'] : array(),
        'export' => $ex,
    );
}

/**
 * 解析批量地点文本。
 * 每行一种写法：
 *   坐标,名称
 *   坐标,名称,描述
 *   坐标 名称
 *   名称(x, y) 描述   （含可选 (危)，如城南荒野(6, 0)(危)  城南荒野，往哪走呢？…）
 *   名称          （未写坐标时从 $nextDty 起依次占用）
 * 空行和 # 开头的行会跳过。已占用的坐标由调用方再判断。
 */
function map_editor_parse_batch_locs($text, $nextDty)
{
    $nextDty = (int)$nextDty;
    if ($nextDty < 0) $nextDty = 0;
    $rows = array();
    $errors = array();
    $seen = array();
    $lines = preg_split('/\r\n|\r|\n/', (string)$text);
    $lineNo = 0;
    foreach ($lines as $raw) {
        $lineNo++;
        $line = trim($raw);
        if ($line === '' || (isset($line[0]) && $line[0] === '#')) continue;

        $dty = null;
        $name = '';
        $descr = '';

        // 识别「城南荒野(6, 0)(危)  描述…」这种从地图/攻略直接粘贴的行
        if (preg_match('/^(?:(\d+)\s+)?(.+?(?:\(|（)\s*\d+\s*[,，]\s*\d+\s*(?:\)|）)(?:\s*(?:\(|（)\s*危\s*(?:\)|）))?)\s+(.+)$/u', $line, $m)) {
            if ($m[1] !== '') {
                $dty = (int)$m[1];
            } else {
                $dty = $nextDty;
                $nextDty = $dty + 1;
            }
            $name = trim($m[2]);
            $descr = trim($m[3]);
        } elseif (preg_match('/^(\d+)\s*[,，]\s*(.+)$/u', $line, $m)) {
            $dty = (int)$m[1];
            $rest = trim($m[2]);
            $parts = preg_split('/[,，]/u', $rest, 2);
            $name = trim($parts[0]);
            $descr = isset($parts[1]) ? trim($parts[1]) : '';
        } elseif (preg_match('/^(\d+)\s+(.+)$/u', $line, $m)) {
            $dty = (int)$m[1];
            $name = trim($m[2]);
        } else {
            $dty = $nextDty;
            $name = $line;
            $nextDty = $dty + 1;
        }

        if ($dty === null || $dty < 0) {
            $errors[] = '第' . $lineNo . '行：坐标无效。';
            continue;
        }
        if ($name === '') {
            $errors[] = '第' . $lineNo . '行：缺少地点名称。';
            continue;
        }
        if (function_exists('mb_substr')) {
            $name = mb_substr($name, 0, 64, 'UTF-8');
            $descr = mb_substr($descr, 0, 500, 'UTF-8');
        } else {
            $name = substr($name, 0, 64);
            $descr = substr($descr, 0, 500);
        }
        if (isset($seen[$dty])) {
            $errors[] = '第' . $lineNo . '行：坐标 ' . $dty . ' 在本次清单里重复，已跳过。';
            continue;
        }
        $seen[$dty] = true;
        $rows[] = array('dty' => $dty, 'name' => $name, 'descr' => $descr, 'line' => $lineNo);
        if ($dty >= $nextDty) $nextDty = $dty + 1;
    }
    if (!$rows && !$errors) {
        $errors[] = '请至少填写一行地点。';
    }
    return array('rows' => $rows, 'errors' => $errors);
}

function map_editor_sync_locs_to_file($dtx, $dtys)
{
    $last = array('ok' => true, 'error' => '');
    if (!is_array($dtys)) return $last;
    foreach ($dtys as $dty) {
        $last = map_editor_sync_dtx_to_file((int)$dtx, array('changed' => 'loc', 'dty' => (int)$dty));
        if (empty($last['ok'])) return $last;
    }
    return $last;
}
