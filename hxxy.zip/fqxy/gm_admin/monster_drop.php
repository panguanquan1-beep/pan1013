<?php
// 兼容旧入口：统一转到 index.php 的掉落管理，避免旧页面 GET 删除绕过 CSRF。
require_once __DIR__ . '/bootstrap.php';
gm_require_login();
header('Location: index.php?page=drops');
exit;
