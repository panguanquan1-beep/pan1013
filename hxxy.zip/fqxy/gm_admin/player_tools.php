<?php
require_once __DIR__ . '/extra_layout.php';
$pid=isset($_GET['player_id'])?(int)$_GET['player_id']:(isset($_POST['player_id'])?(int)$_POST['player_id']:0);
if($_SERVER['REQUEST_METHOD']==='POST'){
 gm_extra_post_guard();$action=isset($_POST['action'])?$_POST['action']:'';$ok=false;$msg='操作失败，请检查玩家、编号和对应数据表。';
 $valid=($pid>=10000000) && ((gm_table_exists('player_char') && gm_one('SELECT player_id FROM player_char WHERE player_id=?','i',array($pid))!==null) || (gm_table_exists('all_zt') && gm_one('SELECT wjid FROM all_zt WHERE wjid=?','i',array($pid))!==null));
 if(!$valid){$msg='玩家 ID 不存在。';}
 elseif($action==='give_item'||$action==='give_beans'){
  $item=$action==='give_beans'?9322:(int)$_POST['item_id'];$qty=isset($_POST['qty'])?(int)$_POST['qty']:0;
  if($qty<1||$qty>999999)$msg='数量必须在 1 到 999999 之间。';
  else{require_once XYGM_ROOT.'/lib/ItemDb.php';$result=ItemDb::give($pid,$item,$qty,'GM后台发放',gm_current_user()['username']);$ok=$result!==false;$msg=$ok?'发放成功，当前持有数量：'.$result:'发放失败：请确认物品定义已启用、玩家物品表已初始化。';if($ok)gm_log($action,'玩家 '.$pid,'item='.$item.', qty='.$qty);}
 }
 elseif($action==='remove_item'){
  $rowId=(int)$_POST['row_id'];$qty=(int)$_POST['qty'];
  if($qty<1)$msg='扣除数量必须大于 0。';else{require_once XYGM_ROOT.'/lib/ItemDb.php';$result=ItemDb::consumeRow($pid,$rowId,$qty,'GM后台扣除',gm_current_user()['username']);$ok=$result!==false;$msg=$ok?'已扣除，剩余数量：'.$result:'扣除失败：只能扣除未锁定的背包或仓库物品，且数量不能超过持有数量。';if($ok)gm_log('player_remove_item','玩家 '.$pid,'row='.$rowId.', qty='.$qty);}
 }
 elseif($action==='save_quest'){
  $qid=(int)$_POST['quest_id'];$progress=isset($_POST['progress'])?max(0,(int)$_POST['progress']):0;$state=isset($_POST['state'])&&$_POST['state']==='done'?'done':'active';
  if(!gm_table_exists('quest_def')||!gm_one('SELECT id FROM quest_def WHERE id=?','i',array($qid)))$msg='任务 ID 不存在。';
  else{$exists=gm_one('SELECT quest_id FROM player_quest WHERE player_id=? AND quest_id=? LIMIT 1','ii',array($pid,$qid));if($exists)$ok=gm_exec("UPDATE player_quest SET state=?,progress=?,done_at=IF(?='done',NOW(),NULL) WHERE player_id=? AND quest_id=?",'sisii',array($state,$progress,$state,$pid,$qid))!==false;else $ok=gm_exec("INSERT INTO player_quest (player_id,quest_id,state,progress,done_at) VALUES (?,?,?,?,IF(?='done',NOW(),NULL))",'iisis',array($pid,$qid,$state,$progress,$state))!==false;
   $msg=$ok?'任务记录已修改。注意：这只修改任务状态和进度，不会自动发放任务奖励、触发后续任务或执行 NPC 对话。':'任务记录保存失败。';if($ok)gm_log('player_quest_debug','玩家 '.$pid,'quest='.$qid.', state='.$state.', progress='.$progress);}
 }
 elseif($action==='give_title'){
  $tid=(int)$_POST['title_id'];$level=max(1,min(999999,(int)$_POST['level']));$def=gm_one('SELECT id FROM title_def WHERE id=?','i',array($tid));
  if(!$def)$msg='称号 ID 不存在。';else{$has=gm_one('SELECT title_id FROM player_title WHERE player_id=? AND title_id=? LIMIT 1','ii',array($pid,$tid));$ok=$has?gm_exec('UPDATE player_title SET level=? WHERE player_id=? AND title_id=?','iii',array($level,$pid,$tid))!==false:gm_exec('INSERT INTO player_title (player_id,title_id,level) VALUES (?,?,?)','iii',array($pid,$tid,$level))!==false;$msg=$ok?'称号已授予/更新。':'称号保存失败。';if($ok)gm_log('player_give_title','玩家 '.$pid,'title='.$tid.', level='.$level);}
 }
 elseif($action==='remove_title'){
  $tid=(int)$_POST['title_id'];$ok=gm_exec('DELETE FROM player_title WHERE player_id=? AND title_id=?','ii',array($pid,$tid))!==false;$msg=$ok?'玩家称号记录已移除。':'称号移除失败。';if($ok)gm_log('player_remove_title','玩家 '.$pid,'title='.$tid);
 }
 elseif($action==='give_achievement'){
  $aid=(int)$_POST['ach_id'];$def=gm_one('SELECT id FROM achievement_def WHERE id=?','i',array($aid));
  if(!$def)$msg='成就 ID 不存在。';else{$has=gm_one('SELECT ach_id FROM player_achievement WHERE player_id=? AND ach_id=? LIMIT 1','ii',array($pid,$aid));$ok=$has?true:gm_exec('INSERT INTO player_achievement (player_id,ach_id) VALUES (?,?)','ii',array($pid,$aid))!==false;$msg=$ok?'成就已授予。':'成就授予失败。';if($ok)gm_log('player_give_achievement','玩家 '.$pid,'achievement='.$aid);}
 }
 elseif($action==='remove_achievement'){
  $aid=(int)$_POST['ach_id'];$ok=gm_exec('DELETE FROM player_achievement WHERE player_id=? AND ach_id=?','ii',array($pid,$aid))!==false;$msg=$ok?'玩家成就记录已移除。':'成就移除失败。';if($ok)gm_log('player_remove_achievement','玩家 '.$pid,'achievement='.$aid);
 }
 elseif($action==='set_ruyi_points'){
  $points=gm_safe_int(isset($_POST['ruyi_points'])?$_POST['ruyi_points']:0,0,2000000000,-1);
  if($points<0)$msg='如意积分必须是 0 到 2,000,000,000 之间的整数。';
  elseif(!gm_table_exists('player_kv'))$msg='缺少 player_kv 数据表，不能修改如意积分。';
  else{$ok=gm_exec("INSERT INTO player_kv (player_id,k,v) VALUES (?,'ruyi_points',?) ON DUPLICATE KEY UPDATE v=VALUES(v)",'is',array($pid,(string)$points))!==false;
   if($ok){$rd=gm_player_ruyi_data($pid);$msg=$rd['available']?'如意积分已设置为 '.$points.'，当前正式等级为如意 '.(int)$rd['level'].' 级。':'积分已保存，但等级读取失败：'.$rd['error'];gm_log('player_set_ruyi_points','玩家 '.$pid,'ruyi_points='.$points.', level='.(isset($rd['level'])?$rd['level']:'unknown'));}
   else $msg='如意积分保存失败：'.gm_last_db_error();}
 }
 elseif($action==='give_xiyou'){
  $amount=gm_safe_int(isset($_POST['amount'])?$_POST['amount']:0,1,2000000000,0);
  if($amount<=0)$msg='西游币数量不正确。';
  elseif(!is_file(XYGM_ROOT.'/lib/RuyiDb.php'))$msg='找不到游戏核心文件 lib/RuyiDb.php。';
  else{require_once XYGM_ROOT.'/lib/RuyiDb.php';$newBalance=RuyiDb::addXiyouCoin($pid,$amount);$ok=((int)RuyiDb::getXiyouCoin($pid)===(int)$newBalance);$msg=$ok?'西游币已发放，当前余额：'.(int)$newBalance:'西游币发放失败，请检查 player_kv。';if($ok)gm_log('player_add_xiyou','玩家 '.$pid,'xiyou_coin +'.$amount.', balance='.(int)$newBalance);}
 }

 elseif($action==='give_gm_badge'||$action==='remove_gm_badge'){
  require_once XYGM_ROOT.'/lib/ConditionalBadgeDb.php';
  $key=isset($_POST['badge_key'])?trim($_POST['badge_key']):'';
  $bname=ConditionalBadgeDb::badgeName($key);
  if(!ConditionalBadgeDb::isGmBadge($key))$msg='没有这个GM徽章。';
  elseif($action==='give_gm_badge'){
   if(ConditionalBadgeDb::hasGrant($pid,$key)){$ok=true;$msg='该玩家已拥有【'.$bname.'】。';}
   else{$ok=ConditionalBadgeDb::grant($pid,$key,gm_current_user()['username']);$msg=$ok?'已发放【'.$bname.'】，并获得同名称号。':'发放失败。';if($ok)gm_log('player_give_gm_badge','玩家 '.$pid,'badge='.$key);}
  }else{
   if(!ConditionalBadgeDb::hasGrant($pid,$key)){$ok=true;$msg='该玩家没有【'.$bname.'】。';}
   else{$ok=ConditionalBadgeDb::revoke($pid,$key);$msg=$ok?'已收回【'.$bname.'】，同名称号一并收回。':'收回失败。';if($ok)gm_log('player_remove_gm_badge','玩家 '.$pid,'badge='.$key);}
  }
 }
 gm_set_flash($ok?'success':'error',$msg);gm_extra_redirect('player_tools.php?player_id='.$pid);
}
$player=null;
if($pid>=10000000){if(gm_table_exists('player_char'))$player=gm_one('SELECT * FROM player_char WHERE player_id=?','i',array($pid));if(!$player&&gm_table_exists('all_zt'))$player=gm_one('SELECT * FROM all_zt WHERE wjid=?','i',array($pid));}
$items=$player&&gm_table_exists('player_item')?gm_rows('SELECT p.*,d.name,d.color FROM player_item p LEFT JOIN item_def d ON d.id=p.item_id WHERE p.player_id=? ORDER BY FIELD(p.location,"bag","equip","warehouse","listing"),p.id DESC LIMIT 300','i',array($pid)):array();
$quests=$player&&gm_table_exists('player_quest')?gm_rows('SELECT p.*,q.name AS quest_name,q.kind FROM player_quest p LEFT JOIN quest_def q ON q.id=p.quest_id WHERE p.player_id=? ORDER BY p.accepted_at DESC LIMIT 200','i',array($pid)):array();
$titles=$player&&gm_table_exists('player_title')?gm_rows('SELECT p.*,d.name,d.disp,d.color FROM player_title p LEFT JOIN title_def d ON d.id=p.title_id WHERE p.player_id=? ORDER BY d.sort,p.title_id','i',array($pid)):array();
$achievements=$player&&gm_table_exists('player_achievement')?gm_rows('SELECT p.*,d.name,d.category FROM player_achievement p LEFT JOIN achievement_def d ON d.id=p.ach_id WHERE p.player_id=? ORDER BY p.claimed_at DESC','i',array($pid)):array();
$logs=$player&&gm_table_exists('item_log')?gm_rows('SELECT l.*,d.name FROM item_log l LEFT JOIN item_def d ON d.id=l.item_id WHERE l.player_id=? ORDER BY l.id DESC LIMIT 60','i',array($pid)):array();
$name=$player?(isset($player['name'])?$player['name']:(isset($player['username'])?$player['username']:'未命名')):'';
$allTitles=gm_table_exists('title_def')?gm_rows('SELECT id,name FROM title_def ORDER BY sort,id','',array()):array();$allAch=gm_table_exists('achievement_def')?gm_rows('SELECT id,name FROM achievement_def ORDER BY id','',array()):array();
$ruyiData=$player?gm_player_ruyi_data($pid):array('available'=>false,'error'=>'尚未选择玩家','points'=>null,'level'=>null,'stored_level'=>null,'claimed_tiers'=>'','next_points'=>null);
$xybBalance=null;if($player&&is_file(XYGM_ROOT.'/lib/RuyiDb.php')){require_once XYGM_ROOT.'/lib/RuyiDb.php';if(class_exists('RuyiDb'))$xybBalance=(int)RuyiDb::getXiyouCoin($pid);}
require_once XYGM_ROOT.'/lib/ConditionalBadgeDb.php';$gmBadgeDefs=ConditionalBadgeDb::gmDefs();$gmBadgeHolders=ConditionalBadgeDb::holders();
gm_extra_header('玩家资料与调试中心','player_tools.php');
?>
<div class="panel extra-panel"><div class="panel-head"><h2>查找玩家</h2><span class="muted">输入玩家 ID 后查看背包、任务、称号和成就</span></div><form method="get" class="search-row"><input type="number" name="player_id" min="10000000" value="<?php echo $pid>0?$pid:''; ?>" placeholder="玩家 ID，例如 10000003" required><button class="btn primary">打开玩家</button></form></div>
<?php if($pid>0&&!$player): ?><div class="notice warn">没有找到玩家 ID <?php echo $pid; ?>。检查玩家 ID，或确认 all_zt / player_char 表中存在该角色。</div><?php endif; ?>

<div class="panel extra-panel" id="gm-badges"><div class="panel-head"><h2>GM徽章发放</h2><span class="muted">仅由 GM 发放，只展示、不附带属性。之后新增徽章只需放图片并在 ConditionalBadgeDb::$GM_DEFS 登记一行。</span></div>
<?php if(gm_can_write() && $gmBadgeDefs): ?>
<form method="post" class="search-row"><?php echo gm_token_field(); ?><input type="hidden" name="action" value="give_gm_badge"><input type="number" name="player_id" min="10000000" value="<?php echo $pid>0?$pid:''; ?>" placeholder="玩家 ID" required><select name="badge_key"><?php foreach($gmBadgeDefs as $b): ?><option value="<?php echo gm_h($b['badge_key']); ?>"><?php echo gm_h($b['badge_name']); ?></option><?php endforeach; ?></select><button class="btn primary">发放</button></form>
<?php elseif(!$gmBadgeDefs): ?><p class="empty">还没有可发放的 GM 徽章定义。</p><?php endif; ?>
<div class="table-wrap"><table><thead><tr><th>玩家ID</th><th>昵称</th><th>徽章</th><th>发放人</th><th>发放时间</th><th>操作</th></tr></thead><tbody>
<?php foreach($gmBadgeHolders as $h): ?>
<tr><td><a href="player_tools.php?player_id=<?php echo (int)$h['player_id']; ?>"><?php echo (int)$h['player_id']; ?></a></td><td><?php echo gm_h($h['player_name']); ?></td><td><?php echo gm_h($h['badge_name']); ?></td><td><?php echo gm_h($h['granted_by']); ?></td><td><?php echo gm_h($h['granted_at']); ?></td><td><?php if(gm_can_write()): ?><form method="post" class="inline-form" onsubmit="return confirm('确定收回该玩家的此徽章？');"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo (int)$h['player_id']; ?>"><input type="hidden" name="action" value="remove_gm_badge"><input type="hidden" name="badge_key" value="<?php echo gm_h($h['badge_key']); ?>"><button class="link-button danger-link">收回</button></form><?php endif; ?></td></tr>
<?php endforeach; ?>
<?php if(!$gmBadgeHolders): ?><tr><td colspan="6" class="empty">目前没有玩家持有 GM 徽章。</td></tr><?php endif; ?>
</tbody></table></div></div>

<?php if($player): ?>
<div class="panel extra-panel"><div class="panel-head"><h2><?php echo gm_h($name); ?></h2><span class="tag">玩家 ID：<?php echo $pid; ?></span></div><div class="detail-grid"><?php foreach($player as $k=>$v): if(in_array($k,array('updated_at','created_at','vip','vipjy')))continue; ?><div><small><?php echo gm_h($k); ?></small><b><?php echo gm_h($v); ?></b></div><?php endforeach; ?></div></div>
<div class="panel extra-panel"><div class="panel-head"><h2>如意回馈管理</h2><span class="muted">使用游戏核心 RuyiDb.php 读取正式等级</span></div>
<?php if($ruyiData['available']): ?><div class="detail-grid"><div><small>当前如意回馈等级</small><b>如意 <?php echo (int)$ruyiData['level']; ?> 级</b></div><div><small>如意积分</small><b><?php echo number_format((int)$ruyiData['points']); ?></b></div><div><small>等级保留记录</small><b><?php echo (int)$ruyiData['stored_level']; ?></b></div><div><small>已领取档位</small><b><?php echo gm_h($ruyiData['claimed_tiers']!==''?$ruyiData['claimed_tiers']:'暂无记录'); ?></b></div><?php if($ruyiData['next_points']!==null): ?><div><small>下一档积分门槛</small><b><?php echo number_format((int)$ruyiData['next_points']); ?></b></div><?php endif; ?></div>
<?php if(gm_can_write()): ?><form method="post" class="extra-form-grid" style="padding:14px"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="set_ruyi_points"><label>设置如意积分<input type="number" name="ruyi_points" min="0" max="2000000000" value="<?php echo (int)$ruyiData['points']; ?>" required></label><button class="btn primary">保存如意积分</button></form><?php endif; ?>
<p class="extra-note" style="padding:0 14px 14px">如意回馈等级根据如意积分门槛和游戏保存的等级记录计算。此处只调整如意积分，不修改旧 VIP 字段，也不会改动已领取档位。</p>
<?php else: ?><div class="notice warn"><?php echo gm_h($ruyiData['error']); ?>。请确认 player_kv 表和 lib/RuyiDb.php 存在。</div><?php endif; ?></div>
<div class="panel extra-panel"><div class="panel-head"><h2>西游币</h2><span class="muted">与 pan.php 相同，使用 RuyiDb::addXiyouCoin</span></div>
<?php if($xybBalance!==null): ?><div class="detail-grid"><div><small>当前西游币余额</small><b><?php echo number_format((int)$xybBalance); ?></b></div></div>
<?php if(gm_can_write()): ?><form method="post" class="extra-form-grid" style="padding:14px"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="give_xiyou"><label>增加数量<input type="number" name="amount" min="1" max="2000000000" required></label><button class="btn primary">确认增加西游币</button></form><?php endif; ?>
<?php else: ?><div class="notice warn">无法读取西游币。请确认 player_kv 表和 lib/RuyiDb.php 存在。</div><?php endif; ?></div>
<div class="panel extra-panel"><div class="panel-head"><h2>物品发放 / 扣除</h2><span class="muted">使用统一 player_item 和 item_log 数据层</span></div><?php if(gm_can_write()): ?><div class="extra-form-grid" style="padding:14px"><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="give_item"><label>物品 ID<input type="number" name="item_id" min="1" required></label><label>数量<input type="number" name="qty" min="1" max="999999" value="1" required></label><button class="btn primary">发放物品</button></form><form method="post"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="give_beans"><label>金豆数量（物品 ID 9322）<input type="number" name="qty" min="1" max="999999" value="1" required></label><button class="btn primary">发放金豆</button></form></div><?php endif; ?><div class="table-wrap"><table class="extra-table"><thead><tr><th>实例 ID</th><th>物品</th><th>位置</th><th>数量</th><th>绑定</th><th>锁定</th><th>操作</th></tr></thead><tbody><?php foreach($items as $it): ?><tr><td><?php echo (int)$it['id']; ?></td><td><?php echo (int)$it['item_id'].' - '.gm_h($it['name']); ?></td><td><?php echo gm_h($it['location']); ?></td><td><?php echo (int)$it['qty']; ?></td><td><?php echo (int)$it['bound']?'是':'否'; ?></td><td><?php echo (int)$it['locked']?'是':'否'; ?></td><td><?php if(gm_can_write()&&in_array($it['location'],array('bag','warehouse'))&&!(int)$it['locked']): ?><form method="post" class="extra-inline" onsubmit="return confirm('确定从该实例扣除 1 件物品？');"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="remove_item"><input type="hidden" name="row_id" value="<?php echo (int)$it['id']; ?>"><input type="hidden" name="qty" value="1"><button class="link-button danger-link">扣除 1 件</button></form><?php else: ?>不可直接扣除<?php endif; ?></td></tr><?php endforeach; ?><?php if(!$items): ?><tr><td colspan="7" class="empty">没有物品记录，或 player_item 表不存在。</td></tr><?php endif; ?></tbody></table></div></div>
<div class="panel extra-panel"><div class="panel-head"><h2>任务进度调试</h2><span class="muted">修改记录不等于执行任务奖励流程</span></div><?php if(gm_can_write()&&gm_table_exists('quest_def')): ?><form method="post" style="padding:14px;background:#f8fafc;margin:12px;border-radius:8px"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="save_quest"><div class="extra-form-grid"><label>任务 ID<input type="number" name="quest_id" min="1" required></label><label>进度数量<input type="number" name="progress" min="0" value="0"></label><label>状态<select name="state"><option value="active">进行中 active</option><option value="done">已完成 done</option></select></label></div><button class="btn primary">保存任务进度</button></form><?php endif; ?><div class="table-wrap"><table><thead><tr><th>任务 ID</th><th>任务名称</th><th>状态</th><th>进度</th><th>接取时间</th><th>完成时间</th></tr></thead><tbody><?php foreach($quests as $q): ?><tr><td><?php echo (int)$q['quest_id']; ?></td><td><?php echo gm_h($q['quest_name']); ?></td><td><?php echo gm_h($q['state']); ?></td><td><?php echo (int)$q['progress']; ?></td><td><?php echo gm_h($q['accepted_at']); ?></td><td><?php echo gm_h($q['done_at']); ?></td></tr><?php endforeach; ?><?php if(!$quests): ?><tr><td colspan="6" class="empty">没有任务记录。</td></tr><?php endif; ?></tbody></table></div></div>
<div class="panel extra-panel"><div class="panel-head"><h2>称号管理</h2></div><?php if(gm_can_write()): ?><form method="post" class="search-row"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="give_title"><select name="title_id"><?php foreach($allTitles as $t): ?><option value="<?php echo (int)$t['id']; ?>"><?php echo (int)$t['id'].' - '.gm_h($t['name']); ?></option><?php endforeach; ?></select><input type="number" name="level" min="1" value="1" style="max-width:110px"><button class="btn primary">授予 / 设置等级</button></form><?php endif; ?><div class="table-wrap"><table><thead><tr><th>ID</th><th>称号</th><th>显示格式</th><th>等级</th><th>获得时间</th><th>操作</th></tr></thead><tbody><?php foreach($titles as $t): ?><tr><td><?php echo (int)$t['title_id']; ?></td><td><?php echo gm_h($t['name']); ?></td><td><?php echo gm_h($t['disp']); ?></td><td><?php echo (int)$t['level']; ?></td><td><?php echo gm_h($t['got_at']); ?></td><td><?php if(gm_can_write()): ?><form method="post" class="inline-form" onsubmit="return confirm('确定移除此玩家称号？');"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="remove_title"><input type="hidden" name="title_id" value="<?php echo (int)$t['title_id']; ?>"><button class="link-button danger-link">移除</button></form><?php endif; ?></td></tr><?php endforeach; ?><?php if(!$titles): ?><tr><td colspan="6" class="empty">没有称号记录。</td></tr><?php endif; ?></tbody></table></div></div>
<div class="panel extra-panel"><div class="panel-head"><h2>成就管理</h2></div><?php if(gm_can_write()): ?><form method="post" class="search-row"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="give_achievement"><select name="ach_id"><?php foreach($allAch as $a): ?><option value="<?php echo (int)$a['id']; ?>"><?php echo (int)$a['id'].' - '.gm_h($a['name']); ?></option><?php endforeach; ?></select><button class="btn primary">授予成就</button></form><?php endif; ?><div class="table-wrap"><table><thead><tr><th>ID</th><th>成就</th><th>分类</th><th>获得时间</th><th>操作</th></tr></thead><tbody><?php foreach($achievements as $a): ?><tr><td><?php echo (int)$a['ach_id']; ?></td><td><?php echo gm_h($a['name']); ?></td><td><?php echo gm_h($a['category']); ?></td><td><?php echo gm_h($a['claimed_at']); ?></td><td><?php if(gm_can_write()): ?><form method="post" class="inline-form" onsubmit="return confirm('确定移除此玩家成就？');"><?php echo gm_token_field(); ?><input type="hidden" name="player_id" value="<?php echo $pid; ?>"><input type="hidden" name="action" value="remove_achievement"><input type="hidden" name="ach_id" value="<?php echo (int)$a['ach_id']; ?>"><button class="link-button danger-link">移除</button></form><?php endif; ?></td></tr><?php endforeach; ?><?php if(!$achievements): ?><tr><td colspan="5" class="empty">没有成就记录。</td></tr><?php endif; ?></tbody></table></div></div>
<div class="panel"><div class="panel-head"><h2>最近物品流水</h2><span class="muted">最多显示 60 条</span></div><div class="table-wrap"><table><thead><tr><th>时间</th><th>物品</th><th>位置</th><th>变化</th><th>剩余</th><th>原因</th><th>操作人</th></tr></thead><tbody><?php foreach($logs as $l): ?><tr><td><?php echo gm_h($l['created_at']); ?></td><td><?php echo (int)$l['item_id'].' - '.gm_h($l['name']); ?></td><td><?php echo gm_h($l['location']); ?></td><td><?php echo (int)$l['delta']; ?></td><td><?php echo (int)$l['qty_after']; ?></td><td><?php echo gm_h($l['reason']); ?></td><td><?php echo gm_h($l['operator']); ?></td></tr><?php endforeach; ?><?php if(!$logs): ?><tr><td colspan="7" class="empty">没有物品流水记录。</td></tr><?php endif; ?></tbody></table></div></div>
<?php endif; ?>
<?php gm_extra_footer(); ?>
