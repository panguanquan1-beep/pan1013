<?php
require_once __DIR__ . '/extra_layout.php';
$checks = array();
$checks[] = array('PHP 版本', PHP_VERSION, version_compare(PHP_VERSION, '5.6.0', '>=') ? 'ok' : 'bad', '本后台最低要求 PHP 5.6。');
$checks[] = array('mysqli 扩展', extension_loaded('mysqli') ? '已加载' : '未加载', extension_loaded('mysqli') ? 'ok' : 'bad', '游戏数据库连接依赖 mysqli。');
$checks[] = array('JSON 扩展', extension_loaded('json') ? '已加载' : '未加载', extension_loaded('json') ? 'ok' : 'bad', '地图正文和部分物品效果会用到 JSON。');
$mysqlClient = function_exists('mysqli_get_client_info') ? mysqli_get_client_info() : '未知';
$mysqlnd = stripos($mysqlClient, 'mysqlnd') !== false;
$checks[] = array('MySQL 客户端', $mysqlClient, $mysqlnd ? 'ok' : 'warn', '原后台使用 mysqli_stmt::get_result()；该方法需要 mysqlnd。');
$checks[] = array('数据库连接', '已连接', 'ok', 'GM 后台已成功连接 config/app.php 指定的游戏数据库。');
$must = array(
    'all_zt'=>'旧版角色基础表','all_yl'=>'玩家银两表','player_char'=>'统一角色表（可选）',
    'item_def'=>'物品定义','player_item'=>'玩家物品实例','item_log'=>'物品流水',
    'npc_def'=>'NPC 定义','map_zone'=>'地图区域','map_loc'=>'地图地点','map_exit'=>'地图出口','map_npc'=>'地图 NPC 放置',
    'monster_def'=>'怪物定义','monster_drop'=>'怪物掉落','quest_def'=>'任务定义','player_quest'=>'玩家任务进度',
    'title_def'=>'称号定义','player_title'=>'玩家称号','achievement_def'=>'成就定义','player_achievement'=>'玩家成就'
);
foreach ($must as $table=>$label) {
    $exists = gm_table_exists($table);
    $optional = ($table === 'player_char');
    $checks[] = array($label.'（'.$table.'）', $exists?'存在':'缺少', $exists?'ok':($optional?'warn':'bad'), $exists?'表可访问。':($optional?'当前后台可回退读取 all_zt。':'当前功能可能无法正常工作，请检查数据库迁移。'));
}
$cfg = XYGM_ROOT.'/config/app.php';
$checks[] = array('配置文件', is_file($cfg)?'存在':'不存在', is_file($cfg)?'ok':'bad', '路径：config/app.php');
$mapDir = XYGM_GAME_ROOT.'/map/data';
$checks[] = array('地图 PHP 资源目录', is_dir($mapDir)?'存在':'不存在', is_dir($mapDir)?'ok':'warn', '本编辑器修改数据库地图配置，不直接改写 map/data/*.php。');
$bean = gm_table_exists('item_def') ? gm_one('SELECT id,name,enabled FROM item_def WHERE id=9322 LIMIT 1','',array()) : null;
$checks[] = array('金豆物品定义（ID 9322）', $bean ? ($bean['name'].' / '.((int)$bean['enabled']?'启用':'停用')) : '未找到', $bean && (int)$bean['enabled'] ? 'ok' : 'warn', 'GM 发放金豆将通过统一物品系统 ItemDb::give()，不再写旧 wp玩家ID 表。');
$dbInfo = gm_one('SELECT DATABASE() AS dbname, VERSION() AS version, @@character_set_database AS charset','',array());
gm_extra_header('系统体检中心','system_check.php');
?>
<div class="panel extra-panel"><div class="panel-head"><h2>自动检查结果</h2><span class="muted">只读检测，不会修改游戏数据</span></div><div class="table-wrap"><table class="extra-table"><thead><tr><th>检查项目</th><th>结果</th><th>说明</th></tr></thead><tbody>
<?php foreach ($checks as $c): ?><tr><td><b><?php echo gm_h($c[0]); ?></b></td><td><?php echo $c[2]==='ok'?'<span class="tag">正常</span>':($c[2]==='warn'?'<span class="tag">注意</span>':'<span class="tag">异常</span>'); ?><br><?php echo gm_h($c[1]); ?></td><td><?php echo gm_h($c[3]); ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<div class="panel"><div class="panel-head"><h2>数据库信息</h2></div><?php if($dbInfo): ?><div class="detail-grid"><div><small>当前数据库</small><b><?php echo gm_h($dbInfo['dbname']); ?></b></div><div><small>MySQL 版本</small><b><?php echo gm_h($dbInfo['version']); ?></b></div><div><small>数据库字符集</small><b><?php echo gm_h($dbInfo['charset']); ?></b></div></div><?php endif; ?><p class="extra-note">提示：体检页只验证连接、扩展和表是否存在，不会执行自动修复。发现缺表时，请先确认当前数据库是否导入了正确版本的 hxxy.sql。</p></div>
<?php gm_extra_footer(); ?>
