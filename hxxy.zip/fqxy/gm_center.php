<?php
require_once __DIR__ . '/../lib/CurrencyDb.php';
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/**
 * 幻想西游 · 全局开发 / GM 控制台
 * 兼容 PHP 5.3+
 *
 * 访问：http://你的地址/fqxy/gm_center.php
 * 建议仅本机或加密码使用
 *
 * 功能：
 * - 总览仪表盘
 * - 玩家管理（查号、改坐标、改基础属性、清缓存）
 * - 地图编辑入口
 * - 传送点管理
 * - 全服公告
 * - 缓存清理
 * - 简易 ini 浏览
 */

header('Content-Type: text/html; charset=utf-8');

// ========== 可选：简单密码（改成你的密码，留空则不验证）==========
define('GM_PASSWORD', ''); // 例如：define('GM_PASSWORD', 'admin123');

require_once __DIR__ . '/../class/gm_auth.php';
gm_require(); // 统一 GM 鉴权
if (false) {
    if (isset($_POST['gm_login'])) {
        if ($_POST['gm_pass'] === GM_PASSWORD) {
            $_SESSION['gm_ok'] = 1;
        }
    }
    if (isset($_GET['logout'])) {
        unset($_SESSION['gm_ok']);
    }
    if (empty($_SESSION['gm_ok'])) {
        echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GM登录</title>
<style>body{font-family:sans-serif;background:#0f1419;color:#eee;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
form{background:#1e2732;padding:24px;border-radius:12px}input{padding:10px;width:200px;margin:8px 0;border-radius:8px;border:1px solid #38444d;background:#0f1419;color:#fff}
button{padding:10px 20px;background:#1d9bf0;border:0;border-radius:8px;color:#fff}</style></head><body>
<form method="post"><h2>GM 控制台</h2><input type="password" name="gm_pass" placeholder="密码"><br><button name="gm_login" value="1">登录</button></form></body></html>';
        exit;
    }
}

// ---------- 路径 ----------
$ROOT = __DIR__;
$ACHE = $ROOT . '/ache';
$ACHER = $ROOT . '/acher';
$MAP_DATA = $ROOT . '/map/data';
$MAP_FILE_MAP = $ROOT . '/map/map_file_map.php';
$TELEPORT = $ROOT . '/map/teleport_data.php';
$NOTICE_FILE = $ACHER . '/gm_notice.txt';

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function arr_get($a, $k, $d = '') { return isset($a[$k]) ? $a[$k] : $d; }
function load_php_arr($f) {
    if (!DbIniStore::fileExists($f)) return array();
    $d = include($f);
    return is_array($d) ? $d : array();
}

/** 简易解析 ini 文本为数组 */
function parse_ini_text($text) {
    $result = array();
    $section = '';
    $lines = preg_split('/\r\n|\r|\n/', $text);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === ';' || $line[0] === '#') continue;
        if (preg_match('/^\[(.+)\]$/u', $line, $m)) {
            $section = $m[1];
            if (!isset($result[$section])) $result[$section] = array();
            continue;
        }
        $pos = strpos($line, '=');
        if ($pos === false) continue;
        $key = trim(substr($line, 0, $pos));
        $val = trim(substr($line, $pos + 1));
        if ($section === '') $section = '全局';
        $result[$section][$key] = $val;
    }
    return $result;
}

function write_ini_array($path, $data) {
    $out = '';
    foreach ($data as $sec => $items) {
        $out .= '[' . $sec . "]\n";
        if (is_array($items)) {
            foreach ($items as $k => $v) {
                $out .= $k . '=' . $v . "\n";
            }
        }
        $out .= "\n";
    }
    return DbIniStore::filePutContents($path, $out) !== false;
}

function list_players($ache) {
    $list = array();
    foreach (DbIniStore::pathsByPrefix($ache) as $key) {
        if (preg_match('#^fqxy/ache/(\d+)/user\.ini$#', $key, $m)) $list[] = $m[1];
    }
    $list = array_values(array_unique($list));
    sort($list, SORT_STRING);
    return $list;
}

function read_player_summary($ache, $wjid) {
    $dir = $ache . '/' . $wjid;
    $sum = array(
        'wjid' => $wjid,
        'name' => '-',
        'level' => '-',
        'vip' => '-',
        'x' => '?',
        'y' => '?',
        'silver' => '-',
        'bean' => '-',
    );
    // user.ini 坐标
    $uf = $dir . '/user.ini';
    if (DbIniStore::fileExists($uf)) {
        $u = parse_ini_text(DbIniStore::fileGetContents($uf));
        if (isset($u['地图坐标']['x'])) $sum['x'] = $u['地图坐标']['x'];
        if (isset($u['地图坐标']['y'])) $sum['y'] = $u['地图坐标']['y'];
    }
    // zt.ini 玩家信息（常见命名）
    foreach (array('zt.ini', 'zt_ini.ini') as $zn) {
        $zf = $dir . '/' . $zn;
        if (DbIniStore::fileExists($zf)) {
            $z = parse_ini_text(DbIniStore::fileGetContents($zf));
            if (isset($z['玩家信息'])) {
                $pi = $z['玩家信息'];
                if (isset($pi['玩家名字'])) $sum['name'] = $pi['玩家名字'];
                if (isset($pi['等级'])) $sum['level'] = $pi['等级'];
                if (isset($pi['vip等级'])) $sum['vip'] = $pi['vip等级'];
            }
            break;
        }
    }
    // 银两统一读取 all_yl，不再从 yl.ini / game_state_store 读取缓存。
    $sum['silver'] = CurrencyDb::balance((int)$wjid, 'bag');
    // 金豆 商城数量 127
    foreach (array('sc.ini', 'ck.ini') as $fn) {
        $f = $dir . '/' . $fn;
        if (!DbIniStore::fileExists($f)) continue;
        $d = parse_ini_text(DbIniStore::fileGetContents($f));
        if (isset($d['商城数量']['127'])) { $sum['bean'] = $d['商城数量']['127']; break; }
    }
    return $sum;
}

function set_user_xy($ache, $wjid, $x, $y) {
    $uf = $ache . '/' . $wjid . '/user.ini';
    if (!DbIniStore::fileExists($uf)) return false;
    $data = parse_ini_text(DbIniStore::fileGetContents($uf));
    if (!isset($data['地图坐标'])) $data['地图坐标'] = array();
    $data['地图坐标']['x'] = (string)intval($x);
    $data['地图坐标']['y'] = (string)intval($y);
    return write_ini_array($uf, $data);
}

function set_ini_value($path, $section, $key, $value) {
    if (!DbIniStore::fileExists($path)) return false;
    $data = parse_ini_text(DbIniStore::fileGetContents($path));
    if (!isset($data[$section])) $data[$section] = array();
    $data[$section][$key] = $value;
    return write_ini_array($path, $data);
}

function clear_player_cache($ache, $wjid) {
    $dir = $ache . '/' . $wjid;
    if (!is_dir($dir)) return 0; // 这里只清理真实 lock 文本文件，不读取角色 INI 数据。
    $n = 0;
    $dh = opendir($dir);
    if (!$dh) return 0;
    while (($f = readdir($dh)) !== false) {
        if ($f === '.' || $f === '..') continue;
        // 保留 user.ini，清其它 ini 缓存让系统重建（谨慎：有的服全靠 ini）
        // 这里只删 lock 和明确的临时文件
        if (substr($f, -4) === '.txt' && strpos($f, 'lock') !== false) {
            @DbIniStore::unlinkPath($dir . '/' . $f);
            $n++;
        }
    }
    closedir($dh);
    return $n;
}

// ---------- 路由 ----------
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'dash';
$msg = '';
$players = list_players($ACHE);
$mapFileMap = load_php_arr($MAP_FILE_MAP);
$teleports = load_php_arr($TELEPORT);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = isset($_POST['act']) ? $_POST['act'] : '';

    if ($act === 'set_pos') {
        $wjid = trim($_POST['wjid']);
        $x = intval($_POST['dtx']);
        $y = intval($_POST['dty']);
        if (set_user_xy($ACHE, $wjid, $x, $y)) $msg = "成功：{$wjid} → ({$x},{$y})";
        else $msg = '错误：写入失败，检查玩家目录';
        $tab = 'player';
    }

    if ($act === 'edit_attr') {
        $wjid = trim($_POST['wjid']);
        $section = trim($_POST['section']);
        $key = trim($_POST['key']);
        $value = trim($_POST['value']);
        $file = trim($_POST['file']);
        $path = $ACHE . '/' . $wjid . '/' . $file;
        // 安全：只允许改自己目录下 ini
        $path = realpath($path);
        $base = realpath($ACHE . '/' . $wjid);
        if ($path && $base && strpos($path, $base) === 0 && DbIniStore::isFile($path)) {
            if (set_ini_value($path, $section, $key, $value)) $msg = "成功：{$file} [{$section}] {$key}={$value}";
            else $msg = '错误：写入失败';
        } else {
            $msg = '错误：文件不合法';
        }
        $tab = 'player';
        $_GET['wjid'] = $wjid;
    }

    if ($act === 'notice') {
        $text = isset($_POST['notice']) ? $_POST['notice'] : '';
        if (!is_dir($ACHER)) @mkdir($ACHER, 0777, true);
        DbIniStore::filePutContents($NOTICE_FILE, $text);
        $msg = '成功：全服公告已保存（需游戏侧读取该文件才显示）';
        $tab = 'sys';
    }

    if ($act === 'clear_lock') {
        $wjid = trim($_POST['wjid']);
        $n = clear_player_cache($ACHE, $wjid);
        $msg = "成功：清理 {$wjid} 锁文件 {$n} 个";
        $tab = 'player';
        $_GET['wjid'] = $wjid;
    }

    if ($act === 'del_tele') {
        $tid = intval($_POST['tid']);
        if (isset($teleports[$tid])) {
            unset($teleports[$tid]);
            $lines = array("<?php\nreturn array(");
            foreach ($teleports as $id => $t) {
                $lines[] = "    {$id} => array('name'=>" . var_export($t['name'],true) . ",'dtx'=>".intval($t['dtx']).",'dty'=>".intval($t['dty'])."),";
            }
            $lines[] = ");\n";
            DbIniStore::filePutContents($TELEPORT, implode("\n", $lines));
            $msg = "成功：删除传送 {$tid}";
        }
        $tab = 'tele';
    }
}

$viewWjid = isset($_GET['wjid']) ? trim($_GET['wjid']) : '';
$viewSum = $viewWjid !== '' ? read_player_summary($ACHE, $viewWjid) : null;
$viewFiles = array();
if ($viewWjid !== '' && DbIniStore::fileExists($ACHE . '/' . $viewWjid . '/user.ini')) {
    foreach (DbIniStore::pathsByPrefix($ACHE . '/' . $viewWjid) as $dbPath) {
        $baseName = basename($dbPath);
        if (preg_match('/\.ini$/i', $baseName)) $viewFiles[] = $baseName;
    }
    $viewFiles = array_values(array_unique($viewFiles));
    sort($viewFiles);
}
$viewIni = null;
$viewIniName = isset($_GET['ini']) ? $_GET['ini'] : '';
if ($viewWjid && $viewIniName && preg_match('/^[a-zA-Z0-9_\-\.]+$/', $viewIniName)) {
    $p = $ACHE . '/' . $viewWjid . '/' . $viewIniName;
    if (DbIniStore::fileExists($p)) $viewIni = parse_ini_text(DbIniStore::fileGetContents($p));
}

$notice = DbIniStore::fileExists($NOTICE_FILE) ? DbIniStore::fileGetContents($NOTICE_FILE) : '';
$mapCount = count($mapFileMap);
$playerCount = count($players);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>全局开发控制台</title>
<style>
*{box-sizing:border-box}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#0b0f14;color:#e7e9ea;font-size:14px}
a{color:#1d9bf0;text-decoration:none}
.layout{display:flex;min-height:100vh}
.side{width:200px;background:#15202b;padding:16px 12px;flex-shrink:0}
.side h1{font-size:16px;margin:0 0 16px;color:#fff}
.side a{display:block;padding:10px 12px;border-radius:8px;color:#c8d0d8;margin-bottom:4px}
.side a.on,.side a:hover{background:#1d9bf0;color:#fff}
.main{flex:1;padding:16px;max-width:900px}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:16px}
.stat{background:#1e2732;border-radius:12px;padding:14px}
.stat b{display:block;font-size:22px;color:#fff}
.stat span{color:#8b98a5;font-size:12px}
.card{background:#1e2732;border-radius:12px;padding:16px;margin-bottom:14px}
.card h2{margin:0 0 12px;font-size:16px}
.msg{padding:10px 12px;border-radius:8px;margin-bottom:12px;background:#083d2e;color:#5eead4}
.msg.err{background:#3b1212;color:#fca5a5}
table{width:100%;border-collapse:collapse}
th,td{padding:8px;border-bottom:1px solid #2f3b47;text-align:left;font-size:13px}
th{color:#8b98a5}
input,select,textarea{background:#0b0f14;border:1px solid #38444d;color:#e7e9ea;padding:8px;border-radius:8px;margin:2px 0}
button,.btn{background:#1d9bf0;color:#fff;border:0;padding:8px 14px;border-radius:8px;cursor:pointer}
button.green{background:#00ba7c}
button.red{background:#f4212e}
button.orange{background:#ff7a00}
.row{margin:8px 0}
label{display:inline-block;min-width:90px;color:#8b98a5}
.tip{color:#8b98a5;font-size:12px;line-height:1.5}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
@media(max-width:700px){
  .layout{flex-direction:column}
  .side{width:100%;display:flex;flex-wrap:wrap;gap:4px}
  .side h1{width:100%}
  .side a{margin:0}
  .grid2{grid-template-columns:1fr}
}
</style>
</head>
<body>
<div class="layout">
<aside class="side">
<h1>GM 控制台</h1>
<a href="?tab=dash" class="<?php echo $tab==='dash'?'on':''; ?>">总览</a>
<a href="?tab=player" class="<?php echo $tab==='player'?'on':''; ?>">玩家管理</a>
<a href="?tab=map" class="<?php echo $tab==='map'?'on':''; ?>">地图系统</a>
<a href="?tab=tele" class="<?php echo $tab==='tele'?'on':''; ?>">传送管理</a>
<a href="?tab=sys" class="<?php echo $tab==='sys'?'on':''; ?>">系统公告</a>
<a href="?tab=files" class="<?php echo $tab==='files'?'on':''; ?>">文件工具</a>
<a href="map/map_editor.php">→ 地图编辑器</a>
<a href="map/dev_center.php">→ 开发中心(旧)</a>
<?php if (GM_PASSWORD !== ''): ?><a href="?logout=1">退出</a><?php endif; ?>
</aside>

<main class="main">
<?php if ($msg): ?>
<div class="msg <?php echo strpos($msg,'错误')!==false?'err':''; ?>"><?php echo h($msg); ?></div>
<?php endif; ?>

<?php if ($tab === 'dash'): ?>
<div class="cards">
<div class="stat"><b><?php echo $playerCount; ?></b><span>在线缓存玩家</span></div>
<div class="stat"><b><?php echo $mapCount; ?></b><span>数据地图</span></div>
<div class="stat"><b><?php echo count($teleports); ?></b><span>传送点</span></div>
<div class="stat"><b><?php echo is_dir($MAP_DATA)?'OK':'无'; ?></b><span>地图data目录</span></div>
</div>
<div class="card">
<h2>全局掌控入口</h2>
<div class="grid2">
<a class="btn" href="?tab=player">管理玩家 / 改属性 / 改坐标</a>
<a class="btn" href="map/map_editor.php">编辑地图 · 出口 · NPC</a>
<a class="btn" href="?tab=tele">管理传送点</a>
<a class="btn" href="?tab=sys">发全服公告</a>
</div>
</div>
<div class="card">
<h2>推荐工作流</h2>
<p class="tip">
1. 【玩家管理】把测试号传到目标地图<br>
2. 【地图编辑器】改出口 / 加 NPC / 加传送<br>
3. 游戏内刷新验证<br>
4. 属性、银两、金豆等在【玩家管理】里改对应 ini<br>
5. 出问题用【清锁文件】，不要随便删全部 ini
</p>
</div>
<div class="card">
<h2>快捷传送（第一个玩家）</h2>
<?php $pw = !empty($players) ? $players[0] : '10000001'; ?>
<form method="post" style="display:inline"><input type="hidden" name="act" value="set_pos"><input type="hidden" name="wjid" value="<?php echo h($pw); ?>">
<input type="hidden" name="dtx" value="1"><input type="hidden" name="dty" value="0">
<button>长安十字街</button></form>
<form method="post" style="display:inline"><input type="hidden" name="act" value="set_pos"><input type="hidden" name="wjid" value="<?php echo h($pw); ?>">
<input type="hidden" name="dtx" value="91"><input type="hidden" name="dty" value="1">
<button>渔村广场</button></form>
<form method="post" style="display:inline"><input type="hidden" name="act" value="set_pos"><input type="hidden" name="wjid" value="<?php echo h($pw); ?>">
<input type="hidden" name="dtx" value="0"><input type="hidden" name="dty" value="0">
<button>新手村</button></form>
<form method="post" style="display:inline"><input type="hidden" name="act" value="set_pos"><input type="hidden" name="wjid" value="<?php echo h($pw); ?>">
<input type="hidden" name="dtx" value="2"><input type="hidden" name="dty" value="0">
<button>龙宫</button></form>
</div>
<?php endif; ?>

<?php if ($tab === 'player'): ?>
<div class="card">
<h2>玩家列表（ache 缓存）</h2>
<?php if (empty($players)): ?>
<p class="tip">未找到 ache 下的玩家目录。请确认路径 fqxy/ache/玩家ID/user.ini</p>
<?php else: ?>
<table>
<tr><th>ID</th><th>名字</th><th>等级</th><th>VIP</th><th>坐标</th><th></th></tr>
<?php foreach ($players as $p): $s = read_player_summary($ACHE, $p); ?>
<tr>
<td><?php echo h($p); ?></td>
<td><?php echo h($s['name']); ?></td>
<td><?php echo h($s['level']); ?></td>
<td><?php echo h($s['vip']); ?></td>
<td><?php echo h($s['x'].','.$s['y']); ?></td>
<td><a href="?tab=player&amp;wjid=<?php echo h(urlencode($p)); ?>">管理</a></td>
</tr>
<?php endforeach; ?>
</table>
<?php endif; ?>
</div>

<?php if ($viewSum): ?>
<div class="card">
<h2>管理玩家 <?php echo h($viewWjid); ?></h2>
<p>
名字：<?php echo h($viewSum['name']); ?> ·
等级：<?php echo h($viewSum['level']); ?> ·
VIP：<?php echo h($viewSum['vip']); ?> ·
坐标：(<?php echo h($viewSum['x'].','.$viewSum['y']); ?>) ·
银两：<?php echo h($viewSum['silver']); ?> ·
金豆：<?php echo h($viewSum['bean']); ?>
</p>

<h3>修改坐标</h3>
<form method="post">
<input type="hidden" name="act" value="set_pos">
<input type="hidden" name="wjid" value="<?php echo h($viewWjid); ?>">
<div class="row"><label>dtx</label><input type="number" name="dtx" value="<?php echo h($viewSum['x']); ?>"></div>
<div class="row"><label>dty</label><input type="number" name="dty" value="<?php echo h($viewSum['y']); ?>"></div>
<button class="green">保存坐标</button>
</form>

<h3>清理锁文件</h3>
<form method="post" onsubmit="return confirm('仅删除 lock 类 txt？');">
<input type="hidden" name="act" value="clear_lock">
<input type="hidden" name="wjid" value="<?php echo h($viewWjid); ?>">
<button class="orange">清理锁</button>
</form>

<h3>玩家状态记录（数据库）</h3>
<p class="tip">点记录名查看或修改数据库中的状态。改属性前请先确认字段所在记录。</p>
<?php foreach ($viewFiles as $f): ?>
<a class="btn" style="margin:2px;display:inline-block;background:#38444d" href="?tab=player&amp;wjid=<?php echo h(urlencode($viewWjid)); ?>&amp;ini=<?php echo h(urlencode($f)); ?>"><?php echo h($f); ?></a>
<?php endforeach; ?>
</div>

<?php if ($viewIni !== null): ?>
<div class="card">
<h2>编辑 <?php echo h($viewIniName); ?></h2>
<p class="tip">修改单个键值。请谨慎，错误数值可能导致角色异常。</p>
<table>
<tr><th>段</th><th>键</th><th>值</th><th></th></tr>
<?php foreach ($viewIni as $sec => $items): if (!is_array($items)) continue;
foreach ($items as $k => $v): ?>
<tr>
<form method="post">
<input type="hidden" name="act" value="edit_attr">
<input type="hidden" name="wjid" value="<?php echo h($viewWjid); ?>">
<input type="hidden" name="file" value="<?php echo h($viewIniName); ?>">
<input type="hidden" name="section" value="<?php echo h($sec); ?>">
<input type="hidden" name="key" value="<?php echo h($k); ?>">
<td><?php echo h($sec); ?></td>
<td><?php echo h($k); ?></td>
<td><input type="text" name="value" value="<?php echo h($v); ?>" style="width:100%"></td>
<td><button type="submit">改</button></td>
</form>
</tr>
<?php endforeach; endforeach; ?>
</table>
</div>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?>

<?php if ($tab === 'map'): ?>
<div class="card">
<h2>地图系统</h2>
<p class="tip">数据地图 <?php echo $mapCount; ?> 张。点编辑进入可视化编辑器。</p>
<p><a class="btn green" href="map/map_editor.php">打开地图编辑器</a></p>
<table>
<tr><th>dtx</th><th>文件</th><th>地点数</th><th></th></tr>
<?php foreach ($mapFileMap as $dtx => $key):
  $rooms = 0;
  $f = $MAP_DATA . '/' . $key . '.php';
  if (DbIniStore::fileExists($f)) $rooms = count(load_php_arr($f));
?>
<tr>
<td><?php echo intval($dtx); ?></td>
<td><?php echo h($key); ?></td>
<td><?php echo $rooms; ?></td>
<td><a href="map/map_editor.php?map=<?php echo h(urlencode($key)); ?>">编辑</a></td>
</tr>
<?php endforeach; ?>
</table>
</div>
<?php endif; ?>

<?php if ($tab === 'tele'): ?>
<div class="card">
<h2>传送点（teleport_data.php）</h2>
<p class="tip">在地图编辑器添加 cmd=20 的 NPC 时写入。编号建议 ≥500。需已给 xy020.php 打补丁。</p>
<?php if (empty($teleports)): ?>
<p>暂无</p>
<?php else: ?>
<table>
<tr><th>编号</th><th>名称</th><th>dtx</th><th>dty</th><th></th></tr>
<?php foreach ($teleports as $id => $t): ?>
<tr>
<td><?php echo intval($id); ?></td>
<td><?php echo h(arr_get($t,'name','')); ?></td>
<td><?php echo intval(arr_get($t,'dtx',0)); ?></td>
<td><?php echo intval(arr_get($t,'dty',0)); ?></td>
<td>
<form method="post" style="display:inline" onsubmit="return confirm('删除？');">
<input type="hidden" name="act" value="del_tele">
<input type="hidden" name="tid" value="<?php echo intval($id); ?>">
<button class="red">删</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</table>
<?php endif; ?>
<p style="margin-top:10px"><a class="btn" href="map/map_editor.php">去地图编辑器添加</a></p>
</div>
<?php endif; ?>

<?php if ($tab === 'sys'): ?>
<div class="card">
<h2>全服公告</h2>
<p class="tip">保存在 acher/gm_notice.txt。若游戏主页未读取此文件，需要你在 xy002 等模板里自行 echo 文件内容。</p>
<form method="post">
<input type="hidden" name="act" value="notice">
<textarea name="notice" rows="5" style="width:100%"><?php echo h($notice); ?></textarea>
<div class="row"><button class="green">保存公告</button></div>
</form>
</div>
<div class="card">
<h2>接入公告到游戏（可选）</h2>
<pre class="tip" style="white-space:pre-wrap">在 template/xy002.php 合适位置加入：

$gmNoticeFile = __DIR__ . '/../acher/gm_notice.txt';
if (DbIniStore::fileExists($gmNoticeFile)) {
    $gmNotice = trim(DbIniStore::fileGetContents($gmNoticeFile));
    if ($gmNotice !== '') {
        echo "&lt;font color=red&gt;【公告】".$gmNotice."&lt;/font&gt;&lt;br&gt;";
    }
}
</pre>
</div>
<?php endif; ?>

<?php if ($tab === 'files'): ?>
<div class="card">
<h2>路径检测</h2>
<table>
<tr><th>路径</th><th>状态</th></tr>
<tr><td>ache/</td><td><?php echo is_dir($ACHE)?'存在':'缺失'; ?></td></tr>
<tr><td>acher/</td><td><?php echo is_dir($ACHER)?'存在':'缺失'; ?></td></tr>
<tr><td>map/data/</td><td><?php echo is_dir($MAP_DATA)?'存在':'缺失'; ?></td></tr>
<tr><td>map/map_editor.php</td><td><?php echo DbIniStore::fileExists($ROOT.'/map/map_editor.php')?'存在':'缺失'; ?></td></tr>
<tr><td>map/MapMover.php</td><td><?php echo DbIniStore::fileExists($ROOT.'/map/MapMover.php')?'存在':'缺失'; ?></td></tr>
<tr><td>map/teleport_hook.php</td><td><?php echo DbIniStore::fileExists($ROOT.'/map/teleport_hook.php')?'存在':'缺失'; ?></td></tr>
</table>
</div>
<div class="card">
<h2>说明</h2>
<p class="tip">
本控制台直接读写 ache 缓存 ini，适合单机/内网开发。<br>
正式公网请务必设置 GM_PASSWORD，并限制 IP。<br>
改玩家数值后若游戏仍显示旧值，可能是内存/二次缓存，可清锁或重登。
</p>
</div>
<?php endif; ?>

</main>
</div>
</body>
</html>
