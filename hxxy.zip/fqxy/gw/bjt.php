<?php
/**
 * 冰晶塔普通怪：按房间动态刷新
 * 当天该房间打完就消失，次日 00:00:00 由 IceTower::sync 懒重置后重新出现。
 */
require_once __DIR__ . '/../../lib/IceTower.php';

$__icePid = (int)$wjid;
$__iceDty = isset($mapDty) ? (int)$mapDty : -1;
if (!IceTower::active($__icePid)) return;
if (IceTower::roomClear($__icePid, $__iceDty)) return;

// 无可见普通怪、但需要倒计时开战的房间（如塔阶的石佛怪）：
// 输出隐藏 bjtm0。四大 BOSS 房间不再挂隐藏开战锚点，BOSS 必须手动点。
if (!isset(IceTower::$ROOM_MOBS[$__iceDty])) {
    foreach (IceTower::$BOSSES as $__iceBossDef) {
        if ((int)$__iceBossDef[0] === $__iceDty) return;
    }
    if (!isset(IceTower::$COUNTDOWN[$__iceDty])) return;
    $__iceCdName = IceTower::$COUNTDOWN[$__iceDty];
    // 只给普通石佛怪补隐藏锚点，守护者/BOSS 不自动跳。
    if ($__iceCdName !== '石佛怪') return;
    $__iceMid = 90047;
    $cmid = $cmid + 1;
    $cdid[] = $cmid;
    $clj[] = 10;
    $npc[] = $__iceMid;
    echo "<a id='bjtm0' href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1' style='display:none'>{$__iceCdName}</a>";
    return;
}

if (!isset(IceTower::$ROOM_MOBS[$__iceDty])) return;

$__iceDef  = IceTower::$ROOM_MOBS[$__iceDty];
$__iceMid  = (int)$__iceDef[0];
$__iceNeed = (int)$__iceDef[1];
$__iceDone = IceTower::roomKillCount($__icePid, $__iceDty);
$__iceNum  = $__iceNeed - $__iceDone;
if ($__iceNum <= 0) return;
$__iceNames = array(90040 => '石佛怪', 90047 => '石佛怪', 90041 => '光明守护者', 90042 => '黑暗守护者');
$__iceName = isset($__iceNames[$__iceMid]) ? $__iceNames[$__iceMid] : '石佛怪';

for ($__iceI = 0; $__iceI < $__iceNum; $__iceI++) {
    if ($__iceI > 0) echo ',';
    $cmid = $cmid + 1;
    $cdid[] = $cmid;
    $clj[] = 10;
    $npc[] = $__iceMid;
    $__iceIdAttr = $__iceI === 0 ? " id='bjtm0'" : '';
    echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'$__iceIdAttr><font color=blue>{$__iceName}</font></a>";
}
echo "<br/>";
