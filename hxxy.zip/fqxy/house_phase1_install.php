<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/* 住宅系统第一阶段安装器：只建表和初始化房间规则，不清理旧数据。安装完成后请删除本文件。 */
if (session_id() === '') session_start();
header('Content-Type: text/html; charset=utf-8');
$root = dirname(__DIR__);
$configFile = $root . '/config/app.php';
$sqlFile = $root . '/sql_schema/027_house_system.sql';
$message = '';
$ok = false;
if (!DbIniStore::fileExists($configFile) || !DbIniStore::fileExists($sqlFile)) {
    $message = '缺少 config/app.php 或 sql_schema/027_house_system.sql，请按目录结构覆盖。';
} elseif (!extension_loaded('mysqli')) {
    $message = '当前 PHP 未启用 mysqli 扩展。';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cfg = include $configFile;
    $d = $cfg['db'];
    mysqli_report(MYSQLI_REPORT_OFF);
    $db = new mysqli($d['host'], $d['user'], $d['pass'], $d['game_db'], (int)$d['port']);
    if ($db->connect_errno) {
        $message = '数据库连接失败：' . htmlspecialchars($db->connect_error, ENT_QUOTES, 'UTF-8');
    } else {
        $db->set_charset('utf8mb4');
        $sql = DbIniStore::fileGetContents($sqlFile);
        if (!$db->multi_query($sql)) {
            $message = '执行失败：' . htmlspecialchars($db->error, ENT_QUOTES, 'UTF-8');
        } else {
            $failed = '';
            while (true) {
                if ($res = $db->store_result()) $res->free();
                if ($db->errno) { $failed = $db->error; break; }
                if (!$db->more_results()) break;
                if (!$db->next_result()) { $failed = $db->error; break; }
            }
            if ($failed !== '') $message = '安装未完成：' . htmlspecialchars($failed, ENT_QUOTES, 'UTF-8');
            else {
                $ok = true;
                $message = '住宅系统第一阶段数据库结构安装成功。已建立 16 张新表，并初始化 11 个房间、三类房屋权限、房间连接和摆放位置。没有创建任何住宅实例或家具，也没有删除旧数据。';
                DbIniStore::filePutContents(__DIR__ . '/house_schema_installed.flag', date('c'));
            }
        }
        $db->close();
    }
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>住宅系统数据库安装</title>
<style>body{font-family:Arial,'Microsoft YaHei',sans-serif;margin:18px;line-height:1.7;color:#222} .box{max-width:680px;border:1px solid #ddd;border-radius:10px;padding:18px;margin:auto}button{padding:12px 20px;background:#1769aa;color:white;border:0;border-radius:6px;font-size:16px}.ok{color:#147a32}.msg{background:#f5f6f7;padding:12px;border-radius:6px}</style></head><body><div class="box"><h2>住宅系统第一阶段：数据库安装</h2>
<p>本页面只创建新住宅系统的数据表和 11 个房间基础配置，不清空旧住宅/家具数据。</p>
<div class="msg <?php echo $ok ? 'ok' : ''; ?>"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
<?php if (!$ok) { ?><form method="post"><p>确认连接当前游戏数据库 hxxy 并安装新表：</p><button type="submit">安装住宅系统数据库</button></form><?php } else { ?><p><b>下一步：</b>确认安装成功后，执行单独的旧数据清理页面；清理页面需要再次输入确认文字。</p><?php } ?>
<p>安装完成后删除：<code>fqxy/house_phase1_install.php</code></p></div></body></html>
