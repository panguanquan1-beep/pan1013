<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/*
 * 住宅系统第三阶段结构校正器。
 * 兼容曾由旧 GM V1 建立的同名旧结构；仅清理住宅/家具业务表，不操作其他玩家数据。
 * 成功后立即删除本文件。
 */
require_once __DIR__ . '/gm_admin/bootstrap.php';
gm_require_super();
header('Content-Type: text/html; charset=utf-8');
$root = dirname(__DIR__);
$sqlFile = $root . '/sql_schema/027_house_system.sql';
$doneFile = __DIR__ . '/house_phase3_repair.done';
$phrase = 'REPAIR_NEW_HOUSE_SCHEMA_AND_CLEAR_LEGACY_DATA';
$message = '';
$success = false;
$legacy = false;
$details = array();

function hp3_table_exists($db, $table)
{
    $table = $db->real_escape_string($table);
    $r = $db->query("SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='".$table."' LIMIT 1");
    return $r && $r->num_rows > 0;
}
function hp3_columns($db, $table)
{
    $out = array();
    if (!hp3_table_exists($db, $table)) return $out;
    $r = $db->query('SHOW COLUMNS FROM `'.$db->real_escape_string($table).'`');
    if ($r) while ($row = $r->fetch_assoc()) $out[$row['Field']] = 1;
    return $out;
}
function hp3_add_column($db, $table, $column, $definition)
{
    $cols = hp3_columns($db, $table);
    if (isset($cols[$column])) return true;
    return (bool)$db->query('ALTER TABLE `'.$table.'` ADD COLUMN `'.$column.'` '.$definition);
}
function hp3_index_exists($db, $table, $index)
{
    $table = $db->real_escape_string($table);
    $index = $db->real_escape_string($index);
    $r = $db->query("SHOW INDEX FROM `".$table."` WHERE Key_name='".$index."'");
    return $r && $r->num_rows > 0;
}
function hp3_drop_column($db, $table, $column)
{
    $cols = hp3_columns($db, $table);
    if (!isset($cols[$column])) return true;
    return (bool)$db->query('ALTER TABLE `'.$table.'` DROP COLUMN `'.$column.'`');
}
function hp3_run_sql_file($db, $file, &$error)
{
    $sql = DbIniStore::fileGetContents($file);
    if ($sql === false || !$db->multi_query($sql)) { $error = $db->error; return false; }
    do {
        if ($res = $db->store_result()) $res->free();
        if ($db->errno) { $error = $db->error; return false; }
        if (!$db->more_results()) break;
        if (!$db->next_result()) { $error = $db->error; return false; }
    } while (true);
    return true;
}
function hp3_schema_ok($db, &$problem)
{
    $required = array(
        'xy_house_schema'=>array('schema_key','schema_value'),
        'xy_house_def'=>array('id','code','name','house_type','description','base_price','currency','max_furniture','enabled','sort_order'),
        'xy_house_instance'=>array('id','house_def_id','instance_code','house_name','world_map_code','location_code','location_name','world_x','world_y','entry_enabled','access_mode','instance_status'),
        'xy_player_house'=>array('player_id','house_instance_id','ownership_status','acquired_at'),
        'xy_house_room_def'=>array('room_code','room_name','description','map_x','map_y','sort_order','enabled'),
        'xy_house_type_room'=>array('house_type','room_code','enabled'),
        'xy_house_room_link'=>array('id','from_room_code','direction','to_room_code','sort_order','enabled'),
        'xy_house_slot_def'=>array('id','room_code','slot_code','slot_name','furniture_category','sort_order','enabled'),
        'xy_furniture_def'=>array('id','code','name','category','description','max_level','base_price','currency','enabled','sort_order'),
        'xy_furniture_room'=>array('furniture_id','room_code'),
        'xy_furniture_attr'=>array('furniture_id','level','attr_key','attr_value','value_type'),
        'xy_player_furniture'=>array('id','player_id','furniture_id','furniture_level','item_status','acquired_at'),
        'xy_house_furniture'=>array('id','player_house_id','player_id','player_furniture_id','room_code','slot_id','is_placed','placed_at'),
        'xy_house_guest'=>array('id','player_house_id','guest_player_id','permission','expires_at'),
        'xy_house_storage'=>array('id','player_house_id','player_id','item_id','quantity'),
        'xy_house_log'=>array('id','player_id','operator_id','action_code','object_type','object_id','detail')
    );
    foreach ($required as $table=>$columns) {
        $present = hp3_columns($db, $table);
        if (!$present) { $problem = '缺少数据表 '.$table; return false; }
        foreach ($columns as $column) {
            if (!isset($present[$column])) { $problem = '数据表 '.$table.' 缺少字段 '.$column; return false; }
        }
    }
    return true;
}

if (DbIniStore::fileExists($doneFile)) {
    $message = '结构校正已经执行过。为防止重复清理，本页面拒绝再次执行。';
} elseif (!DbIniStore::fileExists($sqlFile)) {
    $message = '缺少 sql_schema/027_house_system.sql。';
} elseif (!is_writable(__DIR__)) {
    $message = 'fqxy 目录不可写，无法可靠创建一次性完成标记；为避免重复清理，已阻止执行。请先给目录写入权限。';
} elseif (!extension_loaded('mysqli')) {
    $message = '当前 PHP 未启用 mysqli 扩展。';
} else {
    $db = gm_db();
    $db->set_charset('utf8mb4');
        $playerHouseCols = hp3_columns($db,'xy_player_house');
        $playerFurnitureCols = hp3_columns($db,'xy_player_furniture');
        $houseFurnitureCols = hp3_columns($db,'xy_house_furniture');
        $houseDefCols = hp3_columns($db,'xy_house_def');
        $furnitureDefCols = hp3_columns($db,'xy_furniture_def');
        $furnitureAttrCols = hp3_columns($db,'xy_furniture_attr');
        $dropTables = array();
        if ($playerHouseCols && !isset($playerHouseCols['house_instance_id'])) $dropTables[] = 'xy_player_house';
        if ($playerFurnitureCols && (!isset($playerFurnitureCols['item_status']) || !isset($playerFurnitureCols['acquired_at']))) $dropTables[] = 'xy_player_furniture';
        if ($houseFurnitureCols && (!isset($houseFurnitureCols['player_furniture_id']) || !isset($houseFurnitureCols['slot_id']))) $dropTables[] = 'xy_house_furniture';
        $legacy = count($dropTables)>0
            || ($houseDefCols && (!isset($houseDefCols['description']) || !isset($houseDefCols['sort_order']) || isset($houseDefCols['level_req']) || isset($houseDefCols['max_rooms']) || isset($houseDefCols['sort'])))
            || ($furnitureDefCols && (!isset($furnitureDefCols['description']) || !isset($furnitureDefCols['sort_order']) || isset($furnitureDefCols['sort'])))
            || ($furnitureAttrCols && !isset($furnitureAttrCols['value_type']));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_POST['confirm_text']) || $_POST['confirm_text'] !== $phrase) {
                $message = '确认文字不正确，没有执行操作。';
            } else {
                $ok = true;
                // 重建旧 GM V1 创建的归属/库存/摆放表。用户已要求旧住宅和家具全部清空。
                foreach ($dropTables as $table) {
                    if (!$db->query('DROP TABLE `'.$table.'`')) { $ok=false; $message='重建旧表失败 '.$table.'：'.$db->error; break; }
                    $details[] = $table.'：旧结构已移除，后续由新 SQL 重建';
                }
                if ($ok && hp3_table_exists($db,'xy_house_def')) {
                    if (!hp3_add_column($db,'xy_house_def','description','TEXT NULL AFTER house_type')) { $ok=false; $message='补齐 xy_house_def.description 失败：'.$db->error; }
                    if ($ok && !hp3_add_column($db,'xy_house_def','sort_order','INT NOT NULL DEFAULT 0 AFTER enabled')) { $ok=false; $message='补齐 xy_house_def.sort_order 失败：'.$db->error; }
                    if ($ok && isset($houseDefCols['sort'])) $db->query('UPDATE xy_house_def SET sort_order=sort');
                    if ($ok && hp3_index_exists($db,'xy_house_def','idx_house_enabled')) $db->query('ALTER TABLE xy_house_def DROP INDEX idx_house_enabled');
                    // 房屋不设等级：清除旧 GM V1 遗留的等级与房间数量字段。
                    if ($ok && !hp3_drop_column($db,'xy_house_def','level_req')) { $ok=false; $message='移除旧住宅等级字段失败：'.$db->error; }
                    if ($ok && !hp3_drop_column($db,'xy_house_def','max_rooms')) { $ok=false; $message='移除旧住宅房间等级限制字段失败：'.$db->error; }
                    if ($ok && !hp3_drop_column($db,'xy_house_def','sort')) { $ok=false; $message='移除旧住宅排序字段失败：'.$db->error; }
                    if ($ok && !hp3_index_exists($db,'xy_house_def','idx_house_def_type')) $db->query('ALTER TABLE xy_house_def ADD KEY idx_house_def_type (house_type,enabled,sort_order)');
                }
                if ($ok && hp3_table_exists($db,'xy_furniture_def')) {
                    if (!hp3_add_column($db,'xy_furniture_def','description','TEXT NULL AFTER category')) { $ok=false; $message='补齐 xy_furniture_def.description 失败：'.$db->error; }
                    if ($ok && !hp3_add_column($db,'xy_furniture_def','sort_order','INT NOT NULL DEFAULT 0 AFTER enabled')) { $ok=false; $message='补齐 xy_furniture_def.sort_order 失败：'.$db->error; }
                    if ($ok && isset($furnitureDefCols['sort'])) $db->query('UPDATE xy_furniture_def SET sort_order=sort');
                    if ($ok && hp3_index_exists($db,'xy_furniture_def','idx_furniture_enabled')) $db->query('ALTER TABLE xy_furniture_def DROP INDEX idx_furniture_enabled');
                    if ($ok && !hp3_drop_column($db,'xy_furniture_def','sort')) { $ok=false; $message='移除旧家具排序字段失败：'.$db->error; }
                    if ($ok && !hp3_index_exists($db,'xy_furniture_def','idx_furniture_category')) $db->query('ALTER TABLE xy_furniture_def ADD KEY idx_furniture_category (category,enabled,sort_order)');
                }
                if ($ok && hp3_table_exists($db,'xy_furniture_attr')) {
                    if (!hp3_add_column($db,'xy_furniture_attr','value_type',"VARCHAR(12) NOT NULL DEFAULT 'flat' AFTER attr_value")) { $ok=false; $message='补齐 xy_furniture_attr.value_type 失败：'.$db->error; }
                }
                if ($ok && $legacy) {
                    // 清空旧 GM 住宅/家具定义及所有新系统业务实例；保留 11 个房间、类型权限、房间连接和摆放位置模板。
                    $clearTables = array('xy_house_def','xy_house_instance','xy_player_house','xy_furniture_def','xy_furniture_room','xy_furniture_attr','xy_player_furniture','xy_house_furniture','xy_house_guest','xy_house_storage');
                    foreach ($clearTables as $table) {
                        if (hp3_table_exists($db,$table) && !$db->query('DELETE FROM `'.$table.'`')) { $ok=false; $message='清空旧住宅/家具数据失败 '.$table.'：'.$db->error; break; }
                        if ($ok) $details[] = $table.'：旧业务数据已清空';
                    }
                }
                if ($ok) {
                    $sqlError='';
                    if (!hp3_run_sql_file($db,$sqlFile,$sqlError)) { $ok=false; $message='执行新住宅 SQL 失败：'.$sqlError; }
                }
                if ($ok) {
                    $problem='';
                    if (!hp3_schema_ok($db,$problem)) { $ok=false; $message='结构复核失败：'.$problem; }
                }
                if ($ok) {
                    $db->query("INSERT INTO xy_house_schema (schema_key,schema_value) VALUES ('version','1.1.0-phase3') ON DUPLICATE KEY UPDATE schema_value='1.1.0-phase3'");
                    $details[] = '16 张住宅/家具表的关键字段检查通过';
                    $details[] = '11 个房间、三类房屋权限和房间连接保留';
                    $markerWritten = @DbIniStore::filePutContents($doneFile,date('c')."\n".implode("\n",$details),LOCK_EX);
                    if ($markerWritten === false) {
                        $success=true;
                        $message='住宅系统结构校正已成功，但完成标记写入失败。请立即删除 fqxy/house_phase3_repair.php，避免再次执行。';
                    } else {
                        $success=true;
                        $message='住宅系统数据结构校正成功。';
                    }
                }
            }
        }
    // 连接由 GM 公共层持有，不在此处关闭，避免影响本次请求的日志/会话清理。
}
?><!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>住宅系统结构校正</title><style>body{font-family:Arial,'Microsoft YaHei',sans-serif;margin:18px;line-height:1.7;color:#222}.box{max-width:760px;border:1px solid #ddd;border-radius:10px;padding:18px;margin:auto}input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #aaa;border-radius:6px}button{padding:12px 20px;background:#175f9e;color:#fff;border:0;border-radius:6px;font-size:16px}.msg{padding:12px;background:#f4f5f6;border-radius:6px}.ok{color:#147a32}.warn{color:#8a4d00}</style></head><body><div class="box"><h2>住宅系统第三阶段：数据库结构校正</h2>
<div class="msg <?php echo $success?'ok':''; ?>"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div>
<?php if (!$success && !DbIniStore::fileExists($doneFile) && $message !== '数据库连接失败：'): ?>
<p>检测结果：<?php echo $legacy?'发现旧 GM V1 与新住宅系统同名表字段冲突。':'没有发现旧 GM V1 的关键字段冲突。'; ?></p>
<?php if ($legacy): ?><p class="warn"><b>将清空的仅限住宅/家具业务数据：</b>住宅定义、住宅实例、房主归属、家具定义、家具属性、家具库存、家具摆放、访客及房屋仓库记录。旧结构的归属/库存/摆放表会重建。11 个房间定义、房屋类型权限、房间连接和通用摆放位置会保留。其他玩家数据完全不动。</p><?php else: ?><p>将重新执行住宅结构 SQL，并验证所有关键字段；不会清理当前业务数据。</p><?php endif; ?>
<form method="post"><label>输入确认文字：</label><input name="confirm_text" autocomplete="off" required><p><button type="submit" onclick="return confirm('确认校正住宅系统数据库结构？');">执行结构校正</button></p></form>
<p>确认文字：<code><?php echo htmlspecialchars($phrase,ENT_QUOTES,'UTF-8'); ?></code></p>
<?php endif; ?>
<?php if ($details): ?><h3>执行结果</h3><ul><?php foreach($details as $line): ?><li><?php echo htmlspecialchars($line,ENT_QUOTES,'UTF-8'); ?></li><?php endforeach; ?></ul><?php endif; ?>
<p>成功后删除本文件 <code>fqxy/house_phase3_repair.php</code>，保留完成标记 <code>fqxy/house_phase3_repair.done</code>。</p></div></body></html>
