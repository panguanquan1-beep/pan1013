<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/* 一次性清理旧房屋/家具数据。只操作 all_houres/all_gzhoures/all_qggz/all_zt住宅字段和 jj数字表。完成后删除此文件。 */
if (session_id() === '') session_start();
header('Content-Type: text/html; charset=utf-8');
$root=dirname(__DIR__);
$configFile=$root.'/config/app.php';
$doneFile=__DIR__.'/house_legacy_reset.done';
$phrase='CLEAR_OLD_HOUSES_AND_ALL_FURNITURE';
$message=''; $result=array(); $success=false;

function house_table_exists($db,$table) {
    $safe=$db->real_escape_string($table);
    $r=$db->query("SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='".$safe."'");
    if (!$r) return false;
    $row=$r->fetch_assoc();
    return ($row && (int)$row['n']>0);
}
function house_column_exists($db,$table,$column) {
    $t=$db->real_escape_string($table); $c=$db->real_escape_string($column);
    $r=$db->query("SHOW COLUMNS FROM `".$t."` LIKE '".$c."'");
    return ($r && $r->num_rows>0);
}
function house_set_ini_value($content,$section,$key,$value) {
    $lines=preg_split("/\r\n|\n|\r/",$content);
    $in=false; $found=false;
    foreach($lines as $i=>$line) {
        if (preg_match('/^\s*\[([^\]]+)\]\s*$/',$line,$m)) {
            $in=($m[1]===$section); continue;
        }
        if ($in && preg_match('/^\s*'.preg_quote($key,'/').'\s*=/u',$line)) {
            $lines[$i]=$key.' = '.$value; $found=true; break;
        }
    }
    return implode("\r\n",$lines);
}
function house_get_ini_value($content,$section,$key) {
    $lines=preg_split("/\r\n|\n|\r/",$content); $in=false;
    foreach($lines as $line) {
        if (preg_match('/^\s*\[([^\]]+)\]\s*$/',$line,$m)) { $in=($m[1]===$section); continue; }
        if ($in && preg_match('/^\s*'.preg_quote($key,'/').'\s*=\s*(.*?)\s*$/u',$line,$m)) return trim($m[1]);
    }
    return null;
}
function house_update_cache_files($fqxy,&$result) {
    $ache=$fqxy.'/ache'; $zt=0; $jj=0; $fz=0; $moved=0;
    $playerIds=array();
    foreach(DbIniStore::pathsByPrefix($ache) as $dbPath) {
        if (preg_match('#^fqxy/ache/(\d+)/(?:zt|user)\.ini$#',$dbPath,$m)) $playerIds[$m[1]]=true;
    }
    foreach(array_keys($playerIds) as $uid) {
            $dir=$ache.'/'.$uid;
            $ztFile=$dir.'/zt.ini';
            if (DbIniStore::isFile($ztFile)) {
                $c=DbIniStore::fileGetContents($ztFile);
                $c=house_set_ini_value($c,'玩家信息','住宅名字','');
                $c=house_set_ini_value($c,'玩家信息','住宅id','0');
                $c=house_set_ini_value($c,'玩家信息','住宅分类','0');
                DbIniStore::filePutContents($ztFile,$c,LOCK_EX); $zt++;
            }
            foreach(array('jj.ini','fz.ini','fzpp.ini') as $n) {
                $f=$dir.'/'.$n; if (DbIniStore::isFile($f) && @DbIniStore::unlinkPath($f)) { if ($n==='jj.ini') $jj++; else $fz++; }
            }
            $userFile=$dir.'/user.ini';
            if (DbIniStore::isFile($userFile)) {
                $u=DbIniStore::fileGetContents($userFile);
                $x=house_get_ini_value($u,'地图坐标','x');
                if ($x!==null && in_array((int)$x,array(71,72,73),true)) {
                    $px=house_get_ini_value($u,'上次坐标','x');
                    $py=house_get_ini_value($u,'上次坐标','y');
                    if ($px===null || $py===null || in_array((int)$px,array(71,72,73),true)) { $px='0'; $py='0'; }
                    $u=house_set_ini_value($u,'地图坐标','x',(string)(int)$px);
                    $u=house_set_ini_value($u,'地图坐标','y',(string)(int)$py);
                    $u=house_set_ini_value($u,'上次坐标','x',(string)(int)$px);
                    $u=house_set_ini_value($u,'上次坐标','y',(string)(int)$py);
                    DbIniStore::filePutContents($userFile,$u,LOCK_EX); $moved++;
                }
            }
    }
    $result[]='玩家住宅缓存重置：'.$zt.' 份';
    $result[]='旧家具缓存删除：'.$jj.' 份';
    $result[]='旧房间/访客缓存删除：'.$fz.' 份';
    $result[]='从旧住宅地图安全移回上一地点：'.$moved.' 名玩家';
    $gzDir=$fqxy.'/acher/gz';
    foreach(array('gz.ini','qggz.ini') as $n) { $f=$gzDir.'/'.$n; if (DbIniStore::isFile($f)) @DbIniStore::unlinkPath($f); }
    $mapDir=$fqxy.'/acher/map';
    if (is_dir($mapDir)) {
        foreach(glob($mapDir.'/*') as $f) {
            $b=basename($f);
            if (preg_match('/-(mz71|hz72|gzai73)/',$b) && DbIniStore::isFile($f)) @DbIniStore::unlinkPath($f);
        }
    }
}

if (DbIniStore::fileExists($doneFile)) {
    $message='此清理脚本已经执行过，禁止重复运行。';
} elseif ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!isset($_POST['confirm_text']) || $_POST['confirm_text']!==$phrase) {
        $message='确认文字不匹配，没有执行任何清理。';
    } elseif (!DbIniStore::fileExists($configFile)) {
        $message='找不到 config/app.php。';
    } else {
        $cfg=include $configFile; $d=$cfg['db']; mysqli_report(MYSQLI_REPORT_OFF);
        $db=new mysqli($d['host'],$d['user'],$d['pass'],$d['game_db'],(int)$d['port']);
        if ($db->connect_errno) $message='数据库连接失败：'.$db->connect_error;
        else {
            $db->set_charset('utf8mb4');
            $requiredHouseTables=array('xy_house_schema','xy_house_def','xy_house_instance','xy_player_house','xy_house_room_def','xy_house_type_room','xy_house_room_link','xy_house_slot_def','xy_furniture_def','xy_furniture_room','xy_furniture_attr','xy_player_furniture','xy_house_furniture','xy_house_guest','xy_house_storage','xy_house_log');
            $missingHouseTables=array();
            foreach($requiredHouseTables as $requiredTable) {
                if (!house_table_exists($db,$requiredTable)) $missingHouseTables[]=$requiredTable;
            }
            if ($missingHouseTables) {
                $message='新住宅系统数据库没有完整安装，缺少：'.implode('、',$missingHouseTables).'。已停止清理，未删除旧数据。请先运行 house_phase1_install.php。';
            } elseif (!house_table_exists($db,'all_zt')) {
                $message='找不到 all_zt，停止清理，未删除旧数据。';
            } elseif (!house_column_exists($db,'all_zt','zzid') || !house_column_exists($db,'all_zt','zzmz') || !house_column_exists($db,'all_zt','zzfl')) {
                $message='all_zt 缺少 zzid、zzmz、zzfl 住宅字段，停止清理；没有清空任何旧表。请先核对数据库结构。';
            } else {
                $db->query('SET FOREIGN_KEY_CHECKS=0');
                foreach(array('all_houres','all_gzhoures','all_qggz') as $t) {
                    if (house_table_exists($db,$t)) {
                        if ($db->query('TRUNCATE TABLE `'.$t.'`')) $result[]=$t.'：已清空';
                        else { $message='清空 '.$t.' 失败：'.$db->error; break; }
                    } else $result[]=$t.'：不存在，跳过';
                }
                if ($message==='') {
                    if (!$db->query("UPDATE all_zt SET zzid=0,zzmz='',zzfl=0")) $message='重置 all_zt 住宅字段失败：'.$db->error;
                    else $result[]='all_zt：全部玩家住宅 ID、名称、分类已重置';
                }
                if ($message==='') {
                    $r=$db->query("SHOW TABLES LIKE 'jj%'"); $drop=array();
                    if ($r) { while($row=$r->fetch_row()) { if (preg_match('/^jj[0-9]+$/',$row[0])) $drop[]=$row[0]; } }
                    foreach($drop as $t) {
                        if (!$db->query('DROP TABLE `'.$db->real_escape_string($t).'`')) { $message='删除旧家具表 '.$t.' 失败：'.$db->error; break; }
                    }
                    if ($message==='') $result[]='旧玩家家具表：成功删除 '.count($drop).' 张';
                }
                $db->query('SET FOREIGN_KEY_CHECKS=1');
                if ($message==='') {
                    house_update_cache_files($root.'/fqxy',$result);
                    DbIniStore::filePutContents($doneFile,date('c')."\n".implode("\n",$result),LOCK_EX);
                    $success=true;
                    $message='旧住宅、官宅、官宅求购和全部旧家具数据清理完成。新住宅系统房间定义与权限没有清除。';
                }
            }
            $db->close();
        }
    }
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>旧住宅与家具清理</title>
<style>body{font-family:Arial,'Microsoft YaHei',sans-serif;margin:18px;line-height:1.7;color:#222}.box{max-width:720px;border:1px solid #ddd;border-radius:10px;padding:18px;margin:auto}input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #aaa;border-radius:6px}button{padding:12px 20px;background:#a32626;color:#fff;border:0;border-radius:6px;font-size:16px}.msg{padding:12px;background:#f4f5f6;border-radius:6px}.ok{color:#147a32}</style></head><body><div class="box"><h2>旧住宅与家具数据清理</h2>
<p><b>将执行：</b>清空 all_houres、all_gzhoures、all_qggz；重置 all_zt 的 zzid/zzmz/zzfl；删除所有 jj数字 玩家旧家具表；清除住宅/家具缓存；把仍停留在旧住宅地图(71/72/73)的玩家移回上次坐标。</p>
<p><b>不会执行：</b>不会清理玩家背包、装备、宠物、银两、金豆、等级、任务或其他数据库表；不会清空新系统的 11 个房间和权限规则。</p>
<div class="msg <?php echo $success?'ok':''; ?>"><?php echo htmlspecialchars($message,ENT_QUOTES,'UTF-8'); ?></div>
<?php if (!$success && !DbIniStore::fileExists($doneFile)) { ?><form method="post"><p>输入安装说明中提供的确认文字（区分大小写）。确认文字不会显示在此页面。</p><input name="confirm_text" autocomplete="off" required><p><button type="submit" onclick="return confirm('确认清空全部旧住宅、官宅和家具数据？');">执行一次性清理</button></p></form><?php } ?>
<?php if ($result) { echo '<h3>执行结果</h3><ul>'; foreach($result as $line) echo '<li>'.htmlspecialchars($line,ENT_QUOTES,'UTF-8').'</li>'; echo '</ul>'; } ?>
<p>清理成功后立即删除 <code>fqxy/house_reset_legacy_once.php</code> 和本目录中的完成标记文件保留即可。</p></div></body></html>
