<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

header("Content-type: text/html; charset=utf-8");
error_reporting(E_ALL & ~E_NOTICE);

$wjid = isset($_GET['wjid']) ? $_GET['wjid'] : "";
$password = isset($_GET['pass']) ? $_GET['pass'] : "";
$ok = false;
$name = "";

if ($wjid !== "" && $password !== "") {
    $inina = "user.ini";
    $path = '../ache/' . $wjid;
    $ininame = $path . "/" . $inina;
    if (DbIniStore::fileExists($ininame)) {
        include("../class/iniclass.php");
        $iniFile = new iniFile($ininame);
        $pass = $iniFile->getItem('验证信息', '玩家验证');
        if ($pass == $password && $password != "" && $pass != "") {
            $ok = true;
            $name = $iniFile->getItem('验证信息', '玩家昵称');
        }
    }
}

if (!$ok) {
    header("Location: login.php");
    exit;
}

$xxjyurl = "?wjid=" . $wjid . "&pass=" . urlencode($password) . "&qy=1";
$dispName = htmlspecialchars($name);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>选区-幻想西游</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
body { background: #f5f5f5; font-family: -apple-system, Helvetica, Arial, sans-serif; font-size: 15px; color: #333; }
.wrap { width: 100%; max-width: 600px; margin: 0 auto; background: #fff; min-height: 100vh; }
.panel { padding: 18px 16px 30px; }
.logo { display: block; width: 100%; max-width: 280px; height: auto; margin: 8px auto 12px; }
.brand { text-align: center; font-size: 22px; font-weight: bold; color: #222; letter-spacing: 2px; }
.slogan { text-align: center; color: #888; font-size: 13px; margin: 6px 0 16px; }
.hello { text-align: center; font-size: 16px; margin: 8px 0 16px; }
.hello b { color: #c00; }
.announce { color: #333; font-size: 14px; line-height: 1.6; background: #fff8e8; border: 1px solid #ffe0a3; border-radius: 4px; padding: 10px 12px; margin-bottom: 16px; }
.sec { font-size: 15px; font-weight: bold; margin: 6px 0 10px; }
.card { border: 1px solid #eeeeee; border-radius: 4px; background: #fafafa; padding: 14px 12px; margin-bottom: 16px; }
.zone { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.zone .name { font-size: 16px; color: #222; }
.zone .name a { color: #0066cc; text-decoration: none; }
.pill { display: inline-block; background: #5cb85c; color: #fff; font-size: 12px; padding: 2px 8px; border-radius: 10px; margin-left: 6px; }
.btn { display: block; width: 100%; height: 48px; line-height: 48px; text-align: center; text-decoration: none; border: 0; border-radius: 4px; color: #fff; font-size: 18px; font-weight: bold; margin: 14px 0 0; background: linear-gradient(to bottom, #ffb400, #ff8c00); letter-spacing: 3px; }
.btn:active { opacity: 0.9; }
.links { text-align: center; margin: 18px 0 8px; }
.links a { color: #0066cc; text-decoration: none; font-size: 16px; }
.foot { text-align: center; color: #888; font-size: 13px; line-height: 1.7; margin-top: 20px; }
</style>
</head>
<body>
<div class="wrap">
  <div class="panel">
    <img class="logo" src="pic/login/1.jpg" alt="幻想西游" />
    <div class="brand">幻想西游</div>
    <div class="slogan">再走西游坎坷路 · 梦回昔日少年时</div>
    <div class="hello">欢迎【<?php echo $dispName; ?>】</div>
    <div class="announce">公告：自动浏览器若因缓存登陆异常，请用手机自带浏览器登陆。</div>
    <div class="sec">选择区服</div>
    <div class="card">
      <div class="zone">
        <div class="name">1. <a href="xyy.php<?php echo $xxjyurl; ?>">内测区</a><span class="pill">流畅</span></div>
      </div>
      <a class="btn" href="xyy.php<?php echo $xxjyurl; ?>">进入游戏</a>
    </div>
    <div class="links"><a href="login.php">退出登录</a></div>
    <div class="foot">
      官方QQ:2542709005，Q群:1129764691<br/>
      服务时间(09:30-21:00)
    </div>
  </div>
</div>
</body>
</html>
