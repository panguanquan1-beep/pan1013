<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

$iniFilexx=$iniFile;

$bugnowtime=date('Y-m-d H:i:s');

$bugfile="";
//判断ini文件是否存在如不没有则从数据库提取并且写入ini
//$inina="all_ip_ini.ini";
$buginina="bug___ID".$wjid."______YM".$bugym."_______ZBx".$bugx."_ZBy".$bugy."______".$bugstime1."ini.ini";

$bugpath='acher/bug';

$bugfile = $bugpath."/".$buginina;	

if(DbIniStore::fileExists($bugfile)){


}else{
//创建文件
DbIniStore::filePutContents($bugfile,"[玩家]");
$iniFile = new iniFile($bugfile);
$iniFile->addItem('bug检测所停留页面',['初始' => $bugym]); 
$iniFile->addItem('bug检测所停留坐标x',['初始' => $bugx]); 
$iniFile->addItem('bug检测所停留坐标y',['初始' => $bugy]); 
  $iniFile->addItem('bug检测所停留time',['初始' => $bugnowtime]);  	

}
 	
	
/*
//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="bug_".$wjid."_".$bugnowtime.".ini";
$path="acher/bug";
$bugfile = $path."/".$inina;	
if(DbIniStore::fileExists($bugfile)){

}else{
$inina="bug_".$wjid."_".$bugnowtime.".ini";
$path="acher/bug";
$bugfile = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($bugfile,"[玩家]");
$iniFile = new iniFile($bugfile);
$iniFile->addItem('bug检测所停留页面',['初始' => $bugym]); 
$iniFile->addItem('bug检测所停留坐标x',['初始' => $bugx]); 
$iniFile->addItem('bug检测所停留坐标y',['初始' => $bugy]); 

//初始
}
$iniFile = new iniFile($bugfile);

$iniFilexx=$iniFile;






*/
$iniFile=$iniFilexx;
?>