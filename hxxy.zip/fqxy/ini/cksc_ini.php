<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="cksc.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file)){

} else{
	

   //连接数据库提取数据写入ini 
   
$inina="cksc.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家背包]");
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
$iniFile->addItem('序列',['初始' => 123]); 
$iniFile->addItem('商城id',['初始' => 1]); 
$iniFile->addItem('商城数量',['初始' => 123]);
$iniFile->addItem('商城名字',['初始' => 123]); 
   
include("./sql/mysql.php");//调用数据库连接 
   
   
   


$q2="ckwp".$wjid;


PlayerSqlCompat::query("set names utf8");
$str="select wpid,wpsl,wpfl from $q2";
$result=PlayerSqlCompat::query($str) or die('SQL语句有误');
//把有值的数据存入一个数组
$m=0;




 while(!!$row=mysql_fetch_array($result)){

if($row[wpfl]==4){
if($row[wpsl]>0){  
$m=$m+1;
$npcc=$row[wpid];
$row[wpid];
$iniFile->addCategory('序列', [$row[wpid]=>$m ]);
$iniFile->addCategory('商城id', [$m=> $row[wpid]]);
$iniFile->addCategory('商城数量', [$row[wpid]=> $row[wpsl]]);
//调用物品信息
include("./wp/wpxx.php");
$iniFile->addCategory('商城名字', [$row[wpid]=> $wpmz]);  

   
   }
   
   
   
   
   
}
   







}








}

$iniFile = new iniFile($file);











?>