<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';
require_once __DIR__ . '/../../lib/ItemDb.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

// 每次按背包实际量重建，避免旧 dy.ini 缓存丢失新拿到的药
$__dy_npcc_save = isset($npcc) ? $npcc : null;
$inina="dy.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;
if (class_exists('DbIniStore', false)) {
	DbIniStore::unlinkPath($file);
}
DbIniStore::filePutContents($file,"[玩家背包]");
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
$iniFile->addItem('序列',['初始' => 123]);
$iniFile->addItem('丹药id',['初始' => 1]);
$iniFile->addItem('丹药数量',['初始' => 123]);
$iniFile->addItem('丹药名字',['初始' => 123]);

$m=0;
$__dySeen = array();

// 1) player_item：分类药品 + 战斗治疗（不含永久加属性丹、任务道具）
if (isset($wjid) && class_exists('ItemDb', false)) {
	$__bagRows = ItemDb::bagList($wjid, 3, 'bag');
	foreach ($__bagRows as $__bagRow) {
		if (!isset($__bagRow['effect_type']) || $__bagRow['effect_type'] !== 'heal') {
			continue;
		}
		if ((int)$__bagRow['qty'] <= 0) {
			continue;
		}
		$__id = (int)$__bagRow['item_id'];
		if (isset($__dySeen[$__id])) {
			continue;
		}
		$__dySeen[$__id] = 1;
		$m=$m+1;
		$iniFile->addCategory('序列', [$__id => $m]);
		$iniFile->addCategory('丹药id', [$m => $__id]);
		$iniFile->addCategory('丹药数量', [$__id => (int)$__bagRow['qty']]);
		$iniFile->addCategory('丹药名字', [$__id => $__bagRow['name']]);
	}
	unset($__bagRows, $__bagRow, $__id);
}

// 2) 合并 xy_player_wp 里旧的 wpfl=5 治疗药，按物品 ID 去重
$__healMap = array();
$__healFile = __DIR__ . '/../wp/data/heal.php';
if (is_file($__healFile)) {
	$__tmpHeal = include $__healFile;
	if (is_array($__tmpHeal)) {
		$__healMap = $__tmpHeal;
	}
	unset($__tmpHeal);
}
unset($__healFile);

include("./sql/mysql.php");//调用数据库连接
$q2="wp".$wjid;
PlayerSqlCompat::query("set names utf8");
$str="select wpid,wpsl,wpfl from $q2";
$result=PlayerSqlCompat::query($str) or die('SQL语句有误');
while(!!$row=mysql_fetch_array($result)){
	if($row['wpfl']==5){
		if($row['wpsl']>0){
			$__id = (int)$row['wpid'];
			if (isset($__dySeen[$__id])) {
				continue;
			}
			$__isHeal = isset($__healMap[$__id]);
			if (!$__isHeal && class_exists('ItemDb', false)) {
				$__dOld = ItemDb::def($__id);
				if ($__dOld && isset($__dOld['effect_type']) && $__dOld['effect_type'] === 'heal') {
					$__isHeal = true;
				}
				unset($__dOld);
			}
			if (!$__isHeal) {
				continue;
			}
			$__dySeen[$__id] = 1;
			$m=$m+1;
			$npcc=$__id;
			if (isset($__healMap[$__id]['name']) && $__healMap[$__id]['name'] !== '') {
				$wpmz = $__healMap[$__id]['name'];
			} else {
				include("./wp/wpxx.php");
			}
			$iniFile->addCategory('序列', [$__id => $m]);
			$iniFile->addCategory('丹药id', [$m => $__id]);
			$iniFile->addCategory('丹药数量', [$__id => $row['wpsl']]);
			$iniFile->addCategory('丹药名字', [$__id => $wpmz]);
		}
	}
}
unset($__healMap, $__dySeen, $__id, $__isHeal);

if ($__dy_npcc_save !== null) {
	$npcc = $__dy_npcc_save;
}
unset($__dy_npcc_save);

$iniFile = new iniFile($file);



?>
