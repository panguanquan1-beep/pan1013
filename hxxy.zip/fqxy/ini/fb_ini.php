<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina=$fb."_fb.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file)){

} else{


   //连接数据库提取数据写入ini 
   


//创建文件
DbIniStore::filePutContents($file,"[玩家副本]");


# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
$iniFile->addItem($fbid1,['初始' => 123]);
$iniFile->addItem($fbid2,['初始' => 123]);
$iniFile->addItem($fbid3,['初始' => 123]);
$iniFile->addItem($fbid4,['初始' => 123]);
include("./sql/mysql.php");//调用数据库连接 


$i=0;
for($d=0;$d<4;$d++){
$i=$i+1;
if($i==1){	
$fbid=$fbid1;
} elseif($i==2){  
$fbid=$fbid2;
} elseif($i==3){  
$fbid=$fbid3;
} elseif($i==4){  
$fbid=$fbid4;
} else {
$fbid=1;
} 
# 未设置 $fbid1-4 时（如旧入口脚本 wsc2.php / ttsf2.php）$fbid 会是空串。
# 活站 STRICT_TRANS_TABLES 下 INSERT id='' 会直接报错并 die，把场景页截断。
$fbid = (int)$fbid;
if ($fbid <= 0) {
    continue;
}

$q2="fb".$wjid;
$sql1=PlayerSqlCompat::query("select * from $q2 where id=$fbid",$conn);
$info1=@mysql_fetch_array($sql1);
$fbsj=$info1[fb];
$fb01=$info1[wc];
$fb02=$info1[cs];
$fbsj1=1;
if($fbsj==""){	
$fbsj1=2;
$fbsj=date('Y-m-d H:i:s',strtotime("-1 day"));

$sql = "insert into $q2 (id,fb,wc,cs)  values('$fbid','$fbsj','3','0')";
 if (!PlayerSqlCompat::query($sql,$conn)){
die('Error: ' . mysql_error());
 }

$fb01=3;
$fb02=0;
} else{
} 

$iniFile->addItem($fbid,['激活时间' => $fbsj]);
$iniFile->addItem($fbid,['完成情况' => $fb01]);
$iniFile->addItem($fbid,['重置次数' => $fb02]);
$ffbb=($iniFile->getItem($fbid,'怪物1'));
if($ffbb==""){	
$fbsj1=2;
} else{
} 
if($fbsj1==2){	
$iniFile->addCategory($fbid, ['怪物1' => '1', '怪物2' => '1', '怪物3' => '1', '怪物4' => '1','怪物5' => '1', '怪物6' => '1', '怪物7' => '1', '怪物8' => '1', '怪物9' => '1']);
} else{
} 








} 












}






$iniFile = new iniFile($file);






?>