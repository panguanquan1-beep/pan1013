<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="gz04.ini";
$path='acher/guoz';
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file))
{


}
else
{
   //连接数据库提取数据写入ini 

$inina="gz04.ini";
$path='acher/guoz';
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[国战信息]");
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
$iniFile->addItem('id',['初始' => 0]); 
$iniFile->addItem('玩家名字',['初始' => 0]); 
$iniFile->addItem('玩家id',['初始' => 0]); 
$iniFile->addItem('个人积分',['初始' => 0]); 
$iniFile->addItem('领取情况',['初始' => 0]); 

include("./sql/mysql.php");//调用数据库连接 
$q2="gz04";
PlayerSqlCompat::query("set names utf8");
$str="select * from $q2";
$result=PlayerSqlCompat::query($str) or die('SQL语句有误');
 while(!!$row=mysql_fetch_array($result)){
$iniFile->addCategory('id', [$row[id]=>$row[id]]);	 
$iniFile->addCategory('玩家名字', [$row[wjid]=>$row[wjname]]);
$iniFile->addCategory('玩家id', [$row[wjid]=>$row[wjid]]);
$iniFile->addCategory('个人积分', [$row[wjid]=>$row[wjgzjf]]);
$iniFile->addCategory('领取情况', [$row[wjid]=>$row[wjlq]]);

}





}

$iniFile = new iniFile($file);


?>