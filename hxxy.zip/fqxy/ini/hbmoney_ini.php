<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="hbmoney.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file)){


} else{



	
   //连接数据库提取数据写入ini 
   
$inina="hbmoney.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家信息]");
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
$iniFile->addItem('财神币',['初始' => 0]); 
include("./sql/mysql.php");//调用数据库连接 
$q2="all_hbmoney";
PlayerSqlCompat::query("set names utf8");
$sql1=PlayerSqlCompat::query("select * from $q2 where wjid=$wjid",$conn);
$info1=@mysql_fetch_array($sql1);
$mwjid=$info1[wjid];
$mwjmz=$info1[wjmz];
$mwjmoney=$info1[money];





 
 
 
 
 if($mwjid==""){	
$q2="all_hbmoney";	
PlayerSqlCompat::query("set names utf8");
$sql = "insert into $q2 (wjid,wjmz,money)  values('$wjid','$wjmz','0')";
 if (!PlayerSqlCompat::query($sql,$conn)){
   die('Error: ' . mysql_error());
 }
$iniFile->addCategory('财神币', ['初始'=>'0']);
} else{
$iniFile->addCategory('财神币', ['初始'=>$mwjmoney]);
}
 
 
 
 
 
 
 
 
 

}
$iniFile = new iniFile($file);











?>