<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/* 旧家具 INI 兼容层：新家具系统正式接管后，不再读取或重建 jj玩家ID 旧表。 */
$inina = 'jj.ini';
$path = 'ache/' . (int)$wjid;
$file = $path . '/' . $inina;
if (!is_dir($path)) @mkdir($path,0777,true);
if (!DbIniStore::fileExists($file)) {
    DbIniStore::filePutContents($file,"[玩家家具]\r\n",LOCK_EX);
}
$iniFile = new iniFile($file);
$iniFile->addItem('序列', array('初始'=>123));
$iniFile->addItem('家具id', array('初始'=>123));
$iniFile->addItem('家具等级', array('初始'=>123));
$iniFile->addItem('家具摆放', array('初始'=>123));
$iniFile->addItem('家具名字', array('初始'=>123));
?>
