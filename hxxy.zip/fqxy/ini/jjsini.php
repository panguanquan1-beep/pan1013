<?php
/**
 * 释放第5套锁（旧代码遗留命名，保持兼容）
 */
if (isset($zsspd5) && $zsspd5 == 1 && isset($fp5) && is_resource($fp5)) {
    flock($fp5, LOCK_UN);
} else {
    echo "fm";
}
if (isset($fp5) && is_resource($fp5)) {
    fclose($fp5);
}
?>
