<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}



//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="jn.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;
require_once __DIR__ . '/../../lib/QuestDb.php';
require_once __DIR__ . '/../../lib/MenpaiSkillSystem.php';
$__jnCacheOk = false;
if (DbIniStore::fileExists($file) && !QuestDb::skillIniStale($wjid, $file)) {
    $__jnCache = DbIniStore::parseIniFile($file, true, INI_SCANNER_RAW);
    $__jnVersion = isset($__jnCache['师门技能版本']['当前']) ? $__jnCache['师门技能版本']['当前'] : '';
    $__jnCacheOk = ($__jnVersion === MenpaiSkillSystem::VERSION && isset($__jnCache['技能熟练度']));
}
if ($__jnCacheOk) {
    // 缓存版本与新版技能表一致
} else{
    if (DbIniStore::fileExists($file)) {
        QuestDb::refreshSkillIni($wjid);
    }
   //连接数据库提取数据写入ini 
   
$inina="jn.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家技能]");
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
$iniFile->addItem('序列',['初始' => 123]); 
$iniFile->addItem('技能id',['初始' => 1]); 
$iniFile->addItem('技能名字',['初始' => 123]); 
$iniFile->addItem('技能等级',['初始' => 123]); 
$iniFile->addItem('技能熟练度',['初始' => 0]);
$iniFile->addItem('师门技能版本',['当前' => MenpaiSkillSystem::VERSION]);
include("./sql/mysql.php");//调用数据库连接 
   
   
   


PlayerSqlCompat::query("set names utf8");
$str="SELECT id,jnid,jndj,jnjy FROM xy_player_jnn WHERE wjid=" . (int)$wjid . " ORDER BY id";
$result=PlayerSqlCompat::query($str);
if (!$result) {
    // 表不存在或查询失败时跳过
    $result = false;
}
//把有值的数据存入一个数组
$m=0;




 while(!!$row=mysql_fetch_array($result)){

 
$m=$m+1;
$iniFile->addCategory('序列', [$row['jnid'] => $m]);
$iniFile->addCategory('技能id', [$m => $row['jnid']]);
$iniFile->addCategory('技能等级', [$row['jnid'] => $row['jndj']]);
$iniFile->addCategory('技能熟练度', [$row['jnid'] => isset($row['jnjy']) ? $row['jnjy'] : 0]);


$jnidd=$row['jnid'];
//调用技能信息
include("./wp/jnxx.php");
$iniFile->addCategory('技能名字', [$row['jnid'] => $jnmz]);


   







}



}

$iniFile = new iniFile($file);





?>