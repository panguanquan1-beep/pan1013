<?php
/**
 * 释放玩家操作锁
 * 保持与旧版完全兼容
 */

if ($zsspd == 1 && is_resource($fp)) {
    flock($fp, LOCK_UN);
    // echo "合法执行";
} elseif ($zsspd == 1) {
    // 已释放过（重复 include jsini.php），静默
} else {
    // 调用服务器繁忙页面（旧版注释掉了 include("fm.php")）
    echo "服务器开小差了";
}

if (is_resource($fp)) {
    fclose($fp);
}
$fp = null;
?>
