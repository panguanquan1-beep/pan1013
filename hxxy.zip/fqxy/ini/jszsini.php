<?php
/**
 * 释放玩家操作锁（另一套命名，保持兼容）
 */
if ($zsspd == 1 && is_resource($fp)) {
    flock($fp, LOCK_UN);
} else {
    echo "服务器开小差了";
}
if (is_resource($fp)) {
    fclose($fp);
}
$fp = null;
?>
