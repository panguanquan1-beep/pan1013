<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="ltbwsx.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file)){


}else{

   //连接数据库提取数据写入ini 
   
$inina="ltbwsx.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家属性]");
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
$iniFile->addItem('擂台玩家属性',['玩家id' => $lt01]); 
$iniFile->addItem('擂台玩家属性',['玩家名字' => $lt02]); 
$iniFile->addItem('擂台玩家属性',['玩家hp' => $lt03]);
$iniFile->addItem('擂台玩家属性',['玩家maxhp' => $lt03]);
$iniFile->addItem('擂台玩家属性',['玩家攻击' => $lt04]);
$iniFile->addItem('擂台玩家属性',['玩家魔攻' => $lt05]);
$iniFile->addItem('擂台玩家属性',['玩家防御' => $lt06]);
$iniFile->addItem('擂台玩家属性',['玩家门派' => $lt07]);
$iniFile->addItem('擂台玩家属性',['擂台编号' => $lt08]); 
}


$iniFile = new iniFile($file);




?>