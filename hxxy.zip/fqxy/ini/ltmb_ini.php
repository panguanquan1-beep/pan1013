<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="ltmb.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file))
{


}else{
 
 

$inina="ltmb.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家膜拜人员]");


# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
//数据库数据导入ini文件
# 添加一个分类并直接添加子项
$iniFile->addItem('擂台更新',['初始' => '3']);
$iniFile->addItem('擂台比武',['初始' => '3']);
$iniFile->addItem('膜拜人员',['1' => '123']);
$iniFile->addItem('膜拜人员',['2' => '123']);
$iniFile->addItem('膜拜人员',['3' => '123']);
$iniFile->addItem('膜拜人员',['4' => '123']);
$iniFile->addItem('膜拜人员',['5' => '123']);
$iniFile->addItem('膜拜人员',['6' => '123']);
$iniFile->addItem('膜拜人员',['7' => '123']);
$iniFile->addItem('膜拜人员',['8' => '123']);
$iniFile->addItem('膜拜人员',['9' => '123']);
$iniFile->addItem('膜拜人员',['10' => '123']);

}


$iniFile = new iniFile($file);



?>