<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}



//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="ltymid.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file))
{


}
else
{
 
$inina="ltymid.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家]");
$iniFile = new iniFile($file);
$iniFile->addItem('页面id',['公共页面' => 1]); 
$iniFile->addItem('页面id',['组队页面' => 123]); 
$iniFile->addItem('页面id',['国家页面' => 123]); 
$iniFile->addItem('页面id',['私聊页面' => 123]); 
$iniFile->addItem('页面id',['国家成员页面' => 123]); 
$iniFile->addItem('页面id',['任命国家成员页面' => 123]); 
$iniFile->addItem('页面id',['附近玩家页面' => 123]); 



/*
$inina="ltymid.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家]");
$iniFile = new iniFile($file);
$iniFile->addItem('公共页面',['初始' => 1]); 
$iniFile->addItem('组队页面',['初始' => 1]); 
$iniFile->addItem('国家页面',['初始' => 1]); 
$iniFile->addItem('私聊页面',['初始' => 1]); 


*/





}
$iniFile = new iniFile($file);





?>