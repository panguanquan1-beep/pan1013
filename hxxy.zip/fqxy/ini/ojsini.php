<?php
/**
 * 释放第二把锁
 */
if ($zsspd2 == 1 && is_resource($fp2)) {
    flock($fp2, LOCK_UN);
} else {
    echo "服务器开小差了";
}
if (is_resource($fp2)) {
    fclose($fp2);
}
$fp2 = null;
?>
