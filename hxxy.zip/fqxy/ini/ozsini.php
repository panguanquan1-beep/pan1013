<?php
/**
 * 第二把锁（用于需要同时锁两个资源的场景）
 * 变量：$ininalock2, $zsspd2, $fp2
 */

$zspd2  = 0;
$zsspd2 = 0;
$fp2    = null;

$path        = 'ache/' . $wjid;
$gglockname2 = $path . '/' . $ininalock2;

if (!is_dir($path)) {
    @mkdir($path, 0755, true);
}

$max_try  = 25;
$sleep_us = 200000;

for ($x = 0; $x <= $max_try; $x++) {
    $fp2 = @fopen($gglockname2, 'c+');
    if ($fp2 === false) {
        $zspd2++;
        if ($zspd2 >= $max_try) {
            $zsspd2 = 2;
            break;
        }
        usleep($sleep_us);
        continue;
    }

    if (flock($fp2, LOCK_EX | LOCK_NB)) {
        $zsspd2 = 1;
        break;
    }

    fclose($fp2);
    $fp2 = null;

    $zspd2++;
    if ($zspd2 >= $max_try) {
        $zsspd2 = 2;
        break;
    }
    usleep($sleep_us);
}
?>
