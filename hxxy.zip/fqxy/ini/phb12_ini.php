<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="phb12.ini";
$path='acher/phb';
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file))
{


}
else
{
   //连接数据库提取数据写入ini 
      
$inina="phb12.ini";
$path='acher/phb';
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[排行榜信息]");
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);

$iniFile->addItem('排行榜名字',['初始' => 123]);
$iniFile->addItem('排行榜值1',['初始' => 0]); 
$iniFile->addItem('排行榜值2',['初始' => 0]); 
$iniFile->addItem('排行榜值3',['初始' => 0]); 
$iniFile->addItem('排行榜值4',['初始' => 0]); 
include("./sql/mysql.php");//调用数据库连接 
   
$q2="all_yd04";
PlayerSqlCompat::query("set names utf8");
$str="select * from $q2";
$result=PlayerSqlCompat::query($str) or die('SQL语句有误');
//把有值的数据存入一个数组

 while(!!$row=mysql_fetch_array($result)){


$iniFile->addCategory('排行榜名字', [$row[id]=> $row[wjmz]]);
$iniFile->addCategory('排行榜值1', [$row[id]=> $row[wjid]]);
$iniFile->addCategory('排行榜值2', [$row[id]=> $row[ds02]]);
$iniFile->addCategory('排行榜值3', [$row[id]=> $row[vip]]);
$iniFile->addCategory('排行榜值4', [$row[id]=> $row[id]]); 


}
}

$iniFile = new iniFile($file);



?>