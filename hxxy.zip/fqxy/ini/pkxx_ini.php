<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="pkxx.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file)){


}else{
 
$inina="pkxx.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家]");
$iniFile = new iniFile($file);
$iniFile->addItem('怪物编号',['初始' => 123]); 
$iniFile->addItem('怪物1号属性',['初始' => 123]); 
$iniFile->addItem('怪物2号属性',['初始' => 123]); 
$iniFile->addItem('怪物3号属性',['初始' => 123]); 
# 添加一个分类并直接添加子项
$iniFile->addCategory('怪物编号', ['1号' => '0', '2号' => '0', '3号' => '0']);
$iniFile->addCategory('怪物1号属性', ['名字' => '99999999','hp' => '99999999', 'mp' => '99999999','攻击' => '99999999','魔攻'=> '99999999','防御'=> '99999999','魔防'=> '99999999','冰攻'=> '999','火攻'=> '999','雷攻'=> '999','冰防'=> '999','火防'=> '999','雷防'=> '999']);
$iniFile->addCategory('怪物2号属性', ['名字' => '99999999','hp' => '99999999', 'mp' => '99999999','攻击' => '99999999','魔攻'=> '99999999','防御'=> '99999999','魔防'=> '99999999','冰攻'=> '999','火攻'=> '999','雷攻'=> '999','冰防'=> '999','火防'=> '999','雷防'=> '999']);
$iniFile->addCategory('怪物3号属性', ['名字' => '99999999','hp' => '99999999', 'mp' => '99999999','攻击' => '99999999','魔攻'=> '99999999','防御'=> '99999999','魔防'=> '99999999','冰攻'=> '999','火攻'=> '999','雷攻'=> '999','冰防'=> '999','火防'=> '999','雷防'=> '999']);










//初始
}
$iniFile = new iniFile($file);



?>