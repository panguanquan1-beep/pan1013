<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}



$file="";
//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="qd.ini";
$path='ache/'.$wjid;

$file = $path."/".$inina;	

if(DbIniStore::fileExists($file))
{


}
else
{
   //连接数据库提取数据写入ini 
   
include("./sql/mysql.php");//调用数据库连接 
   
$q2="all_qd";
PlayerSqlCompat::query("set names utf8");
$sql1=PlayerSqlCompat::query("select * from $q2 where wjid=$wjid",$conn);
$info1=@mysql_fetch_array($sql1);
$id=$info1[id];
if($id ==""){

$sql1=PlayerSqlCompat::query("select MAX(id) from $q2");
$abc=@mysql_fetch_array($sql1);
$maxid=($abc && isset($abc[0]) && $abc[0]!=='' && $abc[0]!==null) ? (int)$abc[0] : 0;
$maxidd=$maxid+1;
$qdy= date('m')*1;
$qdsj='1970-01-01 00:00:00';
$qdcs=0;

$sql = "insert into $q2 (id,wjid,qdsj,qdcs,qdy,qd1,qd2,qd3,qd4,qd5)  values('$maxidd','$wjid','$qdsj','$qdcs','$qdy','1','1','1','1','1')";
 if (!PlayerSqlCompat::query($sql,$conn)){
   die('Error: ' . mysql_error());
 }
 
 PlayerSqlCompat::query("set names utf8");
$sql1=PlayerSqlCompat::query("select * from $q2 where wjid=$wjid",$conn);
$info1=@mysql_fetch_array($sql1);
  

$qdcs=$info1[qdcs];
$qdy=$info1[qdy];
$qd1=$info1[qd1];
$qd2=$info1[qd2];
$qd3=$info1[qd3];
$qd4=$info1[qd4];
$qd5=$info1[qd5];
 
 } else{	
 

$qdcs=$info1[qdcs];
$qdy=$info1[qdy];
$qd1=$info1[qd1];
$qd2=$info1[qd2];
$qd3=$info1[qd3];
$qd4=$info1[qd4];
$qd5=$info1[qd5];
 
}
 
 
 
 
 
 





$inina="qd.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家]");


# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
//数据库数据导入ini文件
# 添加一个分类并直接添加子项
$iniFile->addItem('签到信息',['初始' => 123]);
$iniFile->addCategory('签到信息', ['签到次数' => $qdcs,'签到月' => $qdy,'签到1' => $qd1,'签到2' => $qd2,'签到3' => $qd3,'签到4' => $qd4,'签到5' => $qd5]);
//数据库数据导入ini文件


}


$iniFile = new iniFile($file);




?>