<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/* 旧官宅求购 INI 兼容层：旧求购功能停用，不再从 all_qggz 重建缓存。 */
$path='acher/gz'; if (!is_dir($path)) @mkdir($path,0777,true);
$file=$path.'/qggz.ini'; if (!DbIniStore::fileExists($file)) DbIniStore::filePutContents($file,"[求购官宅信息]\r\n",LOCK_EX);
$iniFile=new iniFile($file);
foreach(array('排序id','求购信息','求购人','求购人id','求购价格') as $key) $iniFile->addItem($key,array('初始'=>123));
?>
