<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="sjyz.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file))
{
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);





}
else
{
 

$inina="sjyz.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[刷新时间]");


# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
# 添加一个分类并直接添加子项
$iniFile->addItem('时间验证',['初始' => 123]);
$iniFile->addItem('毫秒时间',['时间' => $time]);




}


$iniFile = new iniFile($file);



?>