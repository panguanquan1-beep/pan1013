<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="sw.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file))
{


}
else
{
	
	
	   
$inina="sw.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家]");
# 实例化ini文件操作类，并载入 .ini文件
$iniFile = new iniFile($file);
$iniFile->addItem('声望值',['初始' => 123]); 

	
	
	
	
	
   //连接数据库提取数据写入ini 
   
include("./sql/mysql.php");//调用数据库连接 


$q2="sw".$wjid;
PlayerSqlCompat::query("set names utf8");
$str="select swid,swzz from $q2";
$result=PlayerSqlCompat::query($str) or die('SQL语句有误');
//把有值的数据存入一个数组
 while(!!$row=mysql_fetch_array($result)){


//调用声望信息
$swid=$row[swid];
include("./wp/swxx.php");
$iniFile->addCategory('声望值', [$swmz=> $row[swzz]]);

}

}


$iniFile = new iniFile($file);

// 补齐 swxx.php 已登记、但缓存里还没有的声望名（只加缺失项，不改已有值）
$__swHave = $iniFile->getCategory('声望值');
if (!is_array($__swHave)) {
    $__swHave = array();
}
$__needFill = false;
for ($__i = 1; $__i <= 19; $__i++) {
    $swid = $__i;
    $swmz = '';
    include("./wp/swxx.php");
    if ($swmz === '' || $swmz === null) {
        continue;
    }
    if (!array_key_exists($swmz, $__swHave)) {
        $__needFill = true;
        break;
    }
}
if ($__needFill) {
    include("./sql/mysql.php");
    $q2 = "sw" . $wjid;
    $__res = PlayerSqlCompat::query("select swid,swzz from $q2");
    $__fromDb = array();
    if ($__res) {
        while ($__row = mysql_fetch_array($__res)) {
            $swid = $__row['swid'];
            $swmz = '';
            include("./wp/swxx.php");
            if ($swmz !== '' && $swmz !== null) {
                $__fromDb[$swmz] = $__row['swzz'];
            }
        }
    }
    for ($__i = 1; $__i <= 19; $__i++) {
        $swid = $__i;
        $swmz = '';
        include("./wp/swxx.php");
        if ($swmz === '' || $swmz === null) {
            continue;
        }
        if (array_key_exists($swmz, $__swHave)) {
            continue;
        }
        $__val = isset($__fromDb[$swmz]) ? $__fromDb[$swmz] : 0;
        $iniFile->addCategory('声望值', array($swmz => $__val));
    }
    unset($__fromDb, $__res, $__row, $__val);
}
unset($__swHave, $__needFill, $__i);


?>
