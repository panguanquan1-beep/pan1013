<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


$inina="user.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	


if(DbIniStore::fileExists($file)){
}else{
		//ini文件名字
$inina="user.ini";
//判断文件夹是否存在
//路径
$path='../ache/'.$wjid;
$dir = iconv("UTF-8", "GBK", "$path");
        if (!DbIniStore::fileExists($dir)){
            mkdir ($dir,0777,true);
        } else {
        }

//随机产生一个玩家的特征码写入数据库验证网址信息
function randomkeys($length) {
$returnStr='';
$pattern = '1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ';
for($i = 0; $i < $length; $i ++) {
$returnStr .= $pattern {mt_rand ( 0, 61 )}; //生成php随机数
}
return $returnStr;
}
$ka1=randomkeys(30);
$kcmid=0;
$ka4=1;
$ka5=1;
$ky= date('Y');
$km= date('m');
$kd= date('d');
$kh= date('H');
$ki= date('i');
$ks= date('s');
//创建文件
DbIniStore::filePutContents($file,"[".$wjid."]");
$iniFile = new iniFile($file);
$iniFile->addItem('验证信息',['玩家id' => $wjid,'玩家验证' => $wjid,'玩家游戏码' => $ka1,'cmid值' =>$kcmid,'xcmid值' =>$ka4,'dcmid值' =>$ka5,'年' => $ky,'月' => $km,'日' => $kd,'时' => $kh,'分' => $ki,'秒' => $ks]); 
$iniFile->addItem('地图坐标',['x' => '0','y' => '0']); 
$iniFile->addItem('最后页面id',['页面id' => '0','npcid' => '0']); 
$iniFile->addItem('超链接值',['初始' => 123]); 
//DbIniStore::filePutContents($file,"[超链接值]");
//DbIniStore::filePutContents($file,"[超链接npc值]");


}
$iniFile = new iniFile($file);





?>