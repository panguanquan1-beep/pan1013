<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="xydfw.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file)){


}else{
 
$inina="xydfw.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家]");
$iniFile = new iniFile($file);
$iniFile->addItem('所处楼层',['初始' => '1']); 
$iniFile->addItem('10',['初始' => '1']); 
$iniFile->addItem('20',['初始' => '1']); 
$iniFile->addItem('50',['初始' => '1']); 
$iniFile->addItem('60',['初始' => '1']); 
$iniFile->addItem('80',['初始' => '1']); 
$iniFile->addItem('100',['初始' => '1']); 
$iniFile->addItem('150',['初始' => '1']); 
$iniFile->addItem('200',['初始' => '1']); 
$iniFile->addItem('300',['初始' => '1']); 
$iniFile->addItem('400',['初始' => '1']); 
$iniFile->addItem('500',['初始' => '1']); 
$iniFile->addItem('600',['初始' => '1']); 
$iniFile->addItem('700',['初始' => '1']); 
$iniFile->addItem('800',['初始' => '1']); 
$iniFile->addItem('900',['初始' => '1']); 
$iniFile->addItem('1000',['初始' => '1']); 





}
$iniFile = new iniFile($file);



?>