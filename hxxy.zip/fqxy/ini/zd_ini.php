<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}


//判断ini文件是否存在如不没有则从数据库提取并且写入ini
$inina="zd.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
if(DbIniStore::fileExists($file)){


}else{
 
$inina="zd.ini";
$path='ache/'.$wjid;
$file = $path."/".$inina;	
//创建文件
DbIniStore::filePutContents($file,"[玩家]");
$iniFile = new iniFile($file);
$iniFile->addItem('快捷技能id',['初始' => 123]); 
$iniFile->addItem('快捷名字',['初始' => 123]); 
$iniFile->addItem('快捷分类',['初始' => 123]); 
$iniFile->addItem('快捷设置',['初始' => 123]); 
# 添加一个分类并直接添加子项
$iniFile->addCategory('快捷技能id', ['快捷1' => '0', '快捷2' => '0', '快捷3' => '0','快捷4' => '0', '快捷5' => '0', '快捷6' => '0','快捷7' => '0', '快捷8' => '0', '快捷9' => '0']);
$iniFile->addCategory('快捷名字', ['快捷1' => '0', '快捷2' => '0', '快捷3' => '0','快捷4' => '0', '快捷5' => '0', '快捷6' => '0','快捷7' => '0', '快捷8' => '0', '快捷9' => '0']);
$iniFile->addCategory('快捷分类', ['快捷1' => '0', '快捷2' => '0', '快捷3' => '0','快捷4' => '0', '快捷5' => '0', '快捷6' => '0','快捷7' => '0', '快捷8' => '0', '快捷9' => '0']);












//初始
}
$iniFile = new iniFile($file);



?>