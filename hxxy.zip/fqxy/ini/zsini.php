<?php
/**
 * 玩家操作互斥锁（阻塞获取）
 *
 * 保持与旧版完全兼容的变量：
 *   $ininalock  - 调用方事先设置的锁文件名（如 $wjid."_lock.txt"）
 *   $zsspd      - 1=成功拿到锁，2=超时失败
 *   $fp         - 锁文件句柄（成功时由本文件打开）
 *
 * 改进点：
 *   - 去掉重复的 LOCK_EX
 *   - 更清晰的超时与错误处理
 *   - 避免在 GM 号上输出调试信息影响正式环境（仅调试时开启）
 *   - 统一路径处理
 */

// 调试输出（仅对指定 GM 号，正式环境可整段注释）
if (isset($wjid) && $wjid == 10000001 && !empty($GLOBALS['DEBUG_LOCK'])) {
    echo "<font color=black>操作ID：</font>" . $wjid . "<br>";
}

$zspd  = 0;
$zsspd = 0;
$fp    = null;

// 锁文件完整路径
$path       = './ache/' . $wjid;
$gglockname = $path . '/' . $ininalock;

// 确保目录存在
if (!is_dir($path)) {
    @mkdir($path, 0755, true);
}

$max_try  = 25;          // 最多尝试次数
$sleep_us = 200000;      // 每次等待 200ms  → 约 5 秒超时

for ($x = 0; $x <= $max_try; $x++) {
    $fp = @fopen($gglockname, 'c+');   // c+ : 不存在则创建，存在不截断
    if ($fp === false) {
        $zspd++;
        if ($zspd >= $max_try) {
            $zsspd = 2;
            break;
        }
        usleep($sleep_us);
        continue;
    }

    // 非阻塞尝试独占锁
    if (flock($fp, LOCK_EX | LOCK_NB)) {
        $zsspd = 1;
        // 成功拿到锁后保持 LOCK_EX（不再重复调用 flock）
        break;
    }

    // 没拿到锁，关闭句柄再等
    fclose($fp);
    $fp = null;

    $zspd++;
    if ($zspd >= $max_try) {
        $zsspd = 2;
        break;
    }
    usleep($sleep_us);
}

// 此时：
//   $zsspd == 1 且 $fp 有效 → 业务代码可继续
//   $zsspd == 2             → 超时，后续 jsini 会提示服务器繁忙
?>
