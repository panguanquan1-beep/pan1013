<?php
require_once __DIR__ . '/../../lib/PlayerSqlCompat.php';

// 角色基础状态初始化：历史 zt.ini 路径仅作为数据库记录键，不读写磁盘文件。
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) {
        require_once $__dbini_root . '/lib/DbIniStore.php';
    }
    unset($__dbini_root, $__dbini_parent);
}

$file = 'ache/' . (int)$wjid . '/zt.ini';

// 数据库中已有角色状态时直接使用；不存在时从 all_zt 初始化一份。
if (!DbIniStore::fileExists($file)) {
    include('./sql/mysql.php');
    PlayerSqlCompat::query('set names utf8');

    $q2 = 'all_zt';
    $sql1 = PlayerSqlCompat::query('SELECT * FROM ' . $q2 . ' WHERE wjid=' . (int)$wjid, $conn);
    $info1 = $sql1 ? mysql_fetch_array($sql1, MYSQL_ASSOC) : false;
    if (!is_array($info1)) {
        // 角色资料不存在时，使用当前玩家 ID 初始化共享表；此处不输出临时调试信息。
        if (!class_exists('PlayerInit', false)) {
            require_once __DIR__ . '/../../lib/PlayerInit.php';
        }
        PlayerInit::ensure((int)$wjid);

        // 初始化后重新读取角色资料。
        $sql1 = PlayerSqlCompat::query('SELECT * FROM ' . $q2 . ' WHERE wjid=' . (int)$wjid, $conn);
        $info1 = $sql1 ? mysql_fetch_array($sql1, MYSQL_ASSOC) : false;
        if (!is_array($info1)) {
            die('角色资料初始化失败：all_zt 中没有找到当前玩家。');
        }
    }

    // 新角色等级最低为 1。账号注册时 all_zt 可能已经有一行，但 dj 尚为 0/空值。
    $dj = (isset($info1['dj']) && (int)$info1['dj'] > 0) ? (int)$info1['dj'] : 1;
    if (!isset($info1['dj']) || (int)$info1['dj'] < 1) {
        @PlayerSqlCompat::query('UPDATE all_zt SET dj=1 WHERE wjid=' . (int)$wjid, $conn);
    }

    $uname = isset($info1['username']) ? $info1['username'] : '';
    $sex = isset($info1['sex']) ? $info1['sex'] : 0;
    $tx = isset($info1['tx']) ? $info1['tx'] : '';
    $peiou = isset($info1['peiou']) ? $info1['peiou'] : '';
    $peiouid = isset($info1['peiouid']) ? $info1['peiouid'] : 0;
    $mpp = isset($info1['mpp']) ? $info1['mpp'] : 0;
    $bpname = isset($info1['bpmz']) ? $info1['bpmz'] : '';
    $bpid = isset($info1['bpid']) ? (int)$info1['bpid'] : 0;
    $vip = isset($info1['vip']) ? $info1['vip'] : 0;
    $vipjy = isset($info1['vipjy']) ? $info1['vipjy'] : 0;
    $gsrl = isset($info1['gsrl']) ? $info1['gsrl'] : 0;
    $bbrl = isset($info1['bbrl']) ? $info1['bbrl'] : 0;
    $ckrl = isset($info1['ckrl']) ? $info1['ckrl'] : 0;
    $emz = isset($info1['emz']) ? $info1['emz'] : 0;
    $lh = isset($info1['lh']) ? $info1['lh'] : '';

    $jy = 0;
    $xljy = 0;
    $fbjy = 0;
    $hp = 1000;
    $mp = 500;
    $xljykg = 0;
    $bpzw2 = '';

    if ($bpid >= 1) {
        include('bp_ini.php');
        $bpcs = $iniFile->getCategory('国家信息');
        if (isset($bpcs['辅助大臣id']) && $bpcs['辅助大臣id'] == $wjid) {
            $bpzw2 = '辅助大臣';
        } elseif (isset($bpcs['军机大臣id']) && $bpcs['军机大臣id'] == $wjid) {
            $bpzw2 = '军机大臣';
        } elseif (isset($bpcs['财政大臣id']) && $bpcs['财政大臣id'] == $wjid) {
            $bpzw2 = '财政大臣';
        } elseif (isset($bpcs['工部大臣id']) && $bpcs['工部大臣id'] == $wjid) {
            $bpzw2 = '工部大臣';
        } elseif (isset($bpcs['外交大臣id']) && $bpcs['外交大臣id'] == $wjid) {
            $bpzw2 = '外交大臣';
        } elseif (isset($bpcs['军团长id']) && $bpcs['军团长id'] == $wjid) {
            $bpzw2 = '军团长';
        } elseif (isset($bpcs['现任君主id']) && $bpcs['现任君主id'] == $wjid) {
            $bpzw2 = '君主';
        } else {
            $bpzw2 = '成员';
        }
    }

    // 初始化内容直接写入数据库，不创建 ache/<wjid>/zt.ini 磁盘文件。
    DbIniStore::filePutContents($file, "[玩家]\r\n");
    $iniFile = new iniFile($file);
    $iniFile->addItem('玩家信息', array('初始' => 123));
    $iniFile->addCategory('玩家信息', array(
        '玩家名字' => $uname, '性别' => $sex, '头衔' => $tx,
        '配偶名字' => $peiou, '配偶id' => $peiouid, '等级' => $dj,
        '门派' => $mpp, '帮派名字' => $bpname, '帮派id' => $bpid,
        'vip等级' => $vip, 'vip经验' => $vipjy, '挂售容量' => $gsrl,
        '背包容量' => $bbrl, '仓库容量' => $ckrl, '恶名值' => $emz, '靓号' => $lh
    ));
    $iniFile->addCategory('玩家信息', array(
        '经验' => $jy, '修炼经验' => $xljy, '法宝经验' => $fbjy,
        '红' => $hp, '蓝' => $mp, '修炼经验开关' => $xljykg, '帮派职务' => $bpzw2
    ));
}

$iniFile = new iniFile($file);
if (isset($wjid) && (int)$wjid > 10000000) {
    require_once __DIR__ . '/../../lib/PlayerDb.php';
    PlayerDb::reconcileLevel((int)$wjid);
    $iniFile = new iniFile($file);
}
?>
