<?php
// 物品调试页（GM 专用）：所有物品定义按分类序号排列 + 发放给玩家
// 访问：/fqxy/item_debug.php?gmkey=<gm_secret>  或 已登录GM会话 / ?wjid=..&pass=..
require_once __DIR__ . '/../class/gm_auth.php';
$gm = gm_require();
require_once __DIR__ . '/../lib/ItemDb.php';
header('Content-Type: text/html; charset=utf-8');
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf'], $_SESSION['item_debug_csrf']) || !gm_hash_equals($_SESSION['item_debug_csrf'], $_POST['csrf'])) {
        $msg = '<b style="color:red">CSRF 校验失败</b>';
    } else {
        $pid = (int)$_POST['player_id']; $iid = (int)$_POST['item_id']; $n = (int)$_POST['qty'];
        $r = ($n >= 0) ? ItemDb::give($pid, $iid, $n, 'debug_give', 'item_debug')
                       : ItemDb::consume($pid, $iid, -$n, 'debug_take', 'item_debug');
        $msg = $r === false ? '<b style="color:red">失败（物品不存在/数量不足/参数错误）</b>'
                            : '<b style="color:green">成功：玩家 ' . $pid . ' 物品 ' . $iid . ' 现有 ' . $r . '</b>';
    }
}
if (empty($_SESSION['item_debug_csrf'])) $_SESSION['item_debug_csrf'] = md5(uniqid(mt_rand(), true));
$cats = ItemDb::categories();
$slots = ItemDb::slots();
$slotFilter = isset($_GET['slot']) ? (int)$_GET['slot'] : 0;
$defs = ItemDb::defs();
$cols = $defs ? array_keys($defs[0]) : array();
$viewPid = isset($_GET['pid']) ? (int)$_GET['pid'] : 10000001;
?><!doctype html><html><head><meta charset="utf-8"><title>物品调试</title>
<style>body{font:13px sans-serif}table{border-collapse:collapse}td,th{border:1px solid #999;padding:2px 5px}th{background:#eee}.cat{background:#dfe}.slot{background:#eef}</style></head><body>
<h3>物品调试页（共 <?php echo count($defs); ?> 个定义）</h3><?php echo $msg; ?>
<form method="post"><input type="hidden" name="csrf" value="<?php echo h($_SESSION['item_debug_csrf']); ?>">
玩家ID <input name="player_id" value="<?php echo $viewPid; ?>" size="10">
物品 <select name="item_id"><?php foreach ($defs as $d) echo '<option value="'.(int)$d['id'].'">'.(int)$d['id'].' '.h($d['name']).'</option>'; ?></select>
数量 <input name="qty" value="1" size="6">（负数=扣除） <button>发放</button></form>
<p>装备部位筛选：<a href="?slot=0">全部</a><?php foreach ($slots as $sid => $sname) echo ' | <a href="?slot='.$sid.'"'.($slotFilter===$sid?' style="font-weight:bold"':'').'>'.$sid.'.'.h($sname).'</a>'; ?></p>
<table><tr><?php foreach ($cols as $c) echo '<th>'.h($c).'</th>'; ?></tr>
<?php $last = null;
foreach ($cats as $cid => $cname) {
    echo '<tr class="cat"><td colspan="'.count($cols).'">'.$cid.'. '.h($cname).'</td></tr>';
    $rowsOut = function ($list) use ($cols) { foreach ($list as $d) { $err = ItemDb::validateDef($d);
        echo '<tr'.($err ? ' style="background:#fdd" title="'.h(implode(';',$err)).'"' : '').'>'; foreach ($cols as $c) echo '<td>'.h($d[$c]).'</td>'; echo '</tr>'; } };
    $inCat = array(); foreach ($defs as $d) if ((int)$d['category_id'] === $cid) $inCat[] = $d;
    if ($cid === 1) { // 装备按部位分组
        foreach ($slots as $sid => $sname) {
            if ($slotFilter && $slotFilter !== $sid) continue;
            $g = array(); foreach ($inCat as $d) if ((int)$d['slot_id'] === $sid) $g[] = $d;
            echo '<tr class="slot"><td colspan="'.count($cols).'">　部位 '.$sid.'. '.h($sname).'（'.count($g).'）</td></tr>';
            $rowsOut($g);
        }
        $g = array(); foreach ($inCat as $d) if (empty($d['slot_id'])) $g[] = $d;
        if ($g) { echo '<tr class="slot"><td colspan="'.count($cols).'">　未设置部位</td></tr>'; $rowsOut($g); }
    } else {
        $rowsOut($inCat);
    }
}
foreach ($defs as $d) if (!isset($cats[(int)$d['category_id']])) {
    echo '<tr>'; foreach ($cols as $c) echo '<td>'.h($d[$c]).'</td>'; echo '</tr>';
} ?>
</table>
<h4>玩家 <?php echo $viewPid; ?> 的背包（?pid= 切换）</h4>
<table><tr><th>实例ID</th><th>位置</th><th>物品ID</th><th>名称</th><th>分类</th><th>数量</th><th>锁</th><th>孔/镶嵌</th></tr>
<?php foreach (array('bag','equip','warehouse') as $__loc) foreach (ItemDb::bagList($viewPid, 0, $__loc) as $b) echo '<tr><td>'.(int)$b['id'].'</td><td>'.$__loc.'</td><td>'.(int)$b['item_id'].'</td><td>'.h($b['name']).'</td><td>'.(int)$b['category_id'].'</td><td>'.(int)$b['qty'].'</td><td>'.(int)$b['locked'].'</td><td>'.(int)$b['holes'].'/'.(int)$b['gem_count'].'</td></tr>'; ?>
</table></body></html>
