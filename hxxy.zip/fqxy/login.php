<?php
require_once __DIR__ . '/../lib/PlayerSqlCompat.php';

// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

header("Content-type: text/html; charset=utf-8");
error_reporting(E_ALL & ~E_NOTICE);
date_default_timezone_set("PRC");

/* ========== 页面文案（按需改） ========== */
$SITE_NAME     = "幻想西游";
$NOTICE_DEFAULT= "公告:自动浏览器因缓存问题登陆异常，请用手机自带浏览器登陆";

$BAN_BAR       = "恶 意 或 批 量 注 册 等 一 律 封 号";
$FORGOT_URL    = "#";
$USER_CENTER   = "#";
/* ===================================== */

$err = "";
$reasons = array(
    '登录超时，请重新登录' => '登录超时，请重新登录',
    '登录失效，请重新登录' => '登录失效，请重新登录',
    '账号异常，请重新登录' => '账号异常，请重新登录',
    '请重新登录' => '请重新登录',
);
if (isset($_GET['r']) && $_GET['r'] !== '') {
    $r = $_GET['r'];
    $err = isset($reasons[$r]) ? $reasons[$r] : '请重新登录';
}

$tab = isset($_GET['tab']) ? $_GET['tab'] : 'login';
if (isset($_POST['tab'])) $tab = $_POST['tab'];
if ($tab !== 'reg') $tab = 'login';

$username_keep = "";

function xy_write_token($wjid, $pass, $name) {
    include_once(__DIR__ . "/../class/iniclass.php");
    $path = __DIR__ . "/../ache/" . $wjid;
    if (!is_dir($path)) mkdir($path, 0777, true);
    $file = $path . "/user.ini";
    if (!DbIniStore::fileExists($file)) {
        DbIniStore::filePutContents($file, "[小轩家园玩家信息]\r\n");
        $iniFile = new iniFile($file);
        $iniFile->addItem('验证信息', array('初始' => 123));
        $iniFile->addCategory('验证信息', array(
            '玩家id' => $wjid,
            '玩家验证' => $pass,
            '玩家昵称' => $name,
        ));
    } else {
        $iniFile = new iniFile($file);
        $iniFile->updItem('验证信息', array(
            '玩家id' => $wjid,
            '玩家验证' => $pass,
            '玩家昵称' => $name,
        ));
    }
}

if (isset($_POST['submit'])) {
    $act = isset($_POST['act']) ? $_POST['act'] : 'login';
    if ($act === 'register') {
        $tab = 'reg';
        $zh = trim(isset($_POST['username']) ? $_POST['username'] : "");
        $mm = isset($_POST['password']) ? $_POST['password'] : "";
        $username_keep = $zh;

        if ($zh === "") {
            $err = "账号不能为空";
        } elseif (!preg_match('/^[\w\-\.]{3,30}$/u', $zh)) {
            $err = "账号只能为3-30位字母、数字或下划线";
        } elseif ($mm === "") {
            $err = "密码不能为空";
        } elseif (strlen($mm) < 6 || strlen($mm) > 30) {
            $err = "密码长度需为6-30位";
        } else {
            include(__DIR__ . "/../sql/mysql.php");
            PlayerSqlCompat::query("set names utf8");
            $zh_e = mysql_real_escape_string($zh, $conn);
            // 昵称用账号，避免多填一项
            $nick = $zh;
            $nick_e = $zh_e;

            $sql_u = PlayerSqlCompat::query("select uid from o_user_list where username='$zh_e'", $conn);
            $info_u = @mysql_fetch_array($sql_u);
            if (isset($info_u['uid']) && $info_u['uid'] != "") {
                $err = "该账号已存在";
            } else {
                $sql_max = PlayerSqlCompat::query("select MAX(uid) from o_user_list", $conn);
                $abc = mysql_fetch_array($sql_max);
                $maxidd = ($abc[0] == "") ? 1 : ((int)$abc[0] + 1);
                foreach (array(__DIR__ . '/../ache', __DIR__ . '/ache') as $__d) {
                    foreach ((array)glob($__d . '/1*', GLOB_ONLYDIR) as $__p) {
                        $__n = (int)basename($__p) - 10000000;
                        if ($__n >= $maxidd) $maxidd = $__n + 1;
                    }
                }
                $y = date('Y') * 1; $m = date('m') * 1; $d = date('d') * 1;
                $h = date('H') * 1; $i = date('i') * 1; $s = date('s') * 1;
                $password_md5 = md5($mm . 'ALL_PS');
                $sql = "insert into o_user_list (uid, m_id, name, username, password, n, y, r, s, f, m, ma, aqm)
                        values('$maxidd', '0', '$nick_e', '$zh_e', '$password_md5', '$y', '$m', '$d', '$h', '$i', '$s', '$password_md5', '')";
                if (!PlayerSqlCompat::query($sql, $conn)) {
                    $err = "注册失败，请稍后再试";
                } else {
                    $wjid = $maxidd + 10000000;
                    xy_write_token($wjid, $password_md5, $nick);
                    header("Location: index.php?wjid=" . $wjid . "&pass=" . urlencode($password_md5));
                    exit;
                }
            }
        }
    } else {
        $tab = 'login';
        $username = isset($_POST['username']) ? trim($_POST['username']) : "";
        $password_raw = isset($_POST['password']) ? $_POST['password'] : "";
        $username_keep = $username;

        include(__DIR__ . "/../sql/mysql.php");
        PlayerSqlCompat::query("set names utf8");
        $username_e = mysql_real_escape_string($username, $conn);
        $sql = PlayerSqlCompat::query("select uid,password,name from o_user_list where username='$username_e'", $conn);
        $info = @mysql_fetch_array($sql);
        $pass_db = isset($info['password']) ? $info['password'] : "";
        $uid = isset($info['uid']) ? (int)$info['uid'] : 0;
        $name = isset($info['name']) ? $info['name'] : "";
        $pass = md5($password_raw . 'ALL_PS');

        if ($uid > 0 && $pass_db !== "" && $pass === $pass_db) {
            $wjid = $uid + 10000000;
            xy_write_token($wjid, $pass, $name);
            header("Location: index.php?wjid=" . $wjid . "&pass=" . urlencode($pass));
            exit;
        }
        $err = "账号或密码错误";
    }
}

$notice = ($err !== "") ? $err : $NOTICE_DEFAULT;
$is_reg = ($tab === 'reg');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title><?php echo $is_reg ? '注册' : '登录'; ?>-<?php echo htmlspecialchars($SITE_NAME); ?></title>
<style>
/* 强制重置所有默认样式，防止手机浏览器乱改 */
* { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
body { background: #f5f5f5; font-family: -apple-system, Helvetica, Arial, sans-serif; font-size: 15px; color: #333; }
.wrap { width: 100%; max-width: 600px; margin: 0 auto; background: #fff; min-height: 100vh; }

/* 顶部Tab复刻 */
.tabs { display: flex; width: 100%; height: 55px; }
.tabs a { flex: 1; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 18px; }
.tabs a.on { background: #ffffff; color: #222222; }
.tabs a.off { background: #555555; color: #ffffff; }

.panel { padding: 15px 15px 30px; }

/* 公告 */
.announce { color: #333; font-size: 15px; line-height: 1.5; margin-bottom: 15px; }
.announce.err { color: #c00; }

/* 输入框卡片 */
.card { border: 1px solid #eeeeee; border-radius: 2px; background: #fafafa; margin-bottom: 8px; }
.row { display: flex; align-items: center; padding: 16px 12px; border-bottom: 1px solid #eeeeee; position: relative; }
.row:last-child { border-bottom: 0; }
.row label { width: 5.5em; color: #333; font-size: 16px; }
.row input[type=text], .row input[type=password] { flex: 1; border: 0; background: transparent; outline: none; font-size: 16px; color: #333; padding-right: 35px; }
.row input::placeholder { color: #999; }
.eye { position: absolute; right: 10px; top: 50%; transform: translateY(-50%); border: 0; background: transparent; font-size: 20px; cursor: pointer; line-height: 1; color: #000; }

/* 记住密码 */
.remember { text-align: right; padding: 5px 0 15px; font-size: 15px; }
.remember label { cursor: pointer; display: inline-flex; align-items: center; }
.remember input { width: 18px; height: 18px; margin-right: 6px; accent-color: #06c; }

/* 红字提示 */
.redtip { color: #e60000; font-size: 15px; line-height: 1.5; margin: 10px 0; }
.redtip a { color: #e60000; text-decoration: underline; }

/* 按钮 */
.btn { display: block; width: 100%; height: 50px; border: 0; border-radius: 4px; color: #fff; font-size: 20px; font-weight: bold; cursor: pointer; margin: 15px 0;
    background: linear-gradient(to bottom, #ffb400, #ff8c00); letter-spacing: 5px; }
.btn:active { opacity: 0.9; }

/* 蓝字提示 */
.bluetip { color: #0000ff; font-size: 15px; line-height: 1.5; margin: 15px 0; text-align: justify; }

/* 封号条 */
.ban { background: #5cb85c; color: #fff; text-align: center; padding: 12px; font-size: 16px; border-radius: 4px; margin: 15px 0; letter-spacing: 2px; }

/* 底部链接 */
.footlinks { text-align: center; margin-top: 20px; font-size: 18px; font-weight: bold; }
.footlinks a { color: #0066cc; text-decoration: none; margin: 0 10px; }
</style>
</head>
<body>
<div class="wrap">
  <!-- 用 div + a 代替 ul + li，彻底解决浏览器兼容导致的挤在一起问题 -->
  <div class="tabs">
    <a class="<?php echo $is_reg?'off':'on'; ?>" href="login.php">登录</a>
    <a class="<?php echo $is_reg?'on':'off'; ?>" href="login.php?tab=reg">注册</a>
  </div>
  
  <div class="panel">
    <div class="announce<?php echo $err!==''?' err':''; ?>"><?php echo htmlspecialchars($notice); ?></div>

  <?php if (!$is_reg) { ?>
    <form method="post" action="login.php" id="fLogin" autocomplete="on">
      <input type="hidden" name="tab" value="login" />
      <input type="hidden" name="act" value="login" />
      <div class="card">
        <div class="row">
          <label>账　号:</label>
          <input type="text" name="username" id="uLogin" placeholder="ID/用户名" value="<?php echo htmlspecialchars($username_keep); ?>" />
        </div>
        <div class="row">
          <label>密　码:</label>
          <input type="password" name="password" id="pLogin" placeholder="请输入密码(区分大小写)" />
          <button type="button" class="eye" onclick="togglePw('pLogin',this)" aria-label="显示密码">👁</button>
        </div>
      </div>
      <div class="remember">
        <label><input type="checkbox" id="remember" /> 记住密码</label>
      </div>
      <div class="redtip">
        出现无效请求可刷新页面或用手机自带浏览器登陆后保存书签复制到自动浏览器 
      </div>
      <button class="btn" type="submit" name="submit" value="1">登　录</button>
      <div class="bluetip"><?php echo htmlspecialchars($HELP_BLUE); ?></div>
      <div class="footlinks"><a href="<?php echo htmlspecialchars($FORGOT_URL); ?>">忘记密码？</a> | <a href="<?php echo htmlspecialchars($USER_CENTER); ?>">用户中心</a></div>
    </form>
  <?php } else { ?>
    <form method="post" action="login.php?tab=reg" id="fReg" autocomplete="off">
      <input type="hidden" name="tab" value="reg" />
      <input type="hidden" name="act" value="register" />
      <div class="card">
        <div class="row">
          <label>账　号:</label>
          <input type="text" name="username" id="uReg" placeholder="用户名，3-30个字符" value="<?php echo htmlspecialchars($username_keep); ?>" />
        </div>
        <div class="row">
          <label>密　码:</label>
          <input type="password" name="password" id="pReg" placeholder="请输入密码(区分大小写)" />
          <button type="button" class="eye" onclick="togglePw('pReg',this)" aria-label="显示密码">👁</button>
        </div>
      </div>
      <div class="redtip">请求无效请刷新再试；请勿恶意或批量注册。</div>
      <button class="btn" type="submit" name="submit" value="1">注　册</button>
      <div class="ban"><?php echo htmlspecialchars($BAN_BAR); ?></div>
      <div class="bluetip"><?php echo htmlspecialchars($HELP_BLUE); ?></div>
    </form>
  <?php } ?>
  </div>
</div>
<script>
function togglePw(id, btn){
  var el=document.getElementById(id);
  if(!el) return;
  if(el.type==='password'){ el.type='text'; btn.textContent='🙈'; }
  else { el.type='password'; btn.textContent='👁'; }
}
(function(){
  var u=document.getElementById('uLogin');
  var p=document.getElementById('pLogin');
  var r=document.getElementById('remember');
  if(!u||!p||!r) return;
  try{
    if(localStorage.getItem('xy_remember')==='1'){
      r.checked=true;
      u.value=localStorage.getItem('xy_user')||u.value;
      p.value=localStorage.getItem('xy_pass')||'';
    }
  }catch(e){}
  document.getElementById('fLogin').addEventListener('submit', function(){
    try{
      if(r.checked){
        localStorage.setItem('xy_remember','1');
        localStorage.setItem('xy_user', u.value);
        localStorage.setItem('xy_pass', p.value);
      }else{
        localStorage.removeItem('xy_remember');
        localStorage.removeItem('xy_user');
        localStorage.removeItem('xy_pass');
      }
    }catch(e){}
  });
})();
</script>
</body>
</html>