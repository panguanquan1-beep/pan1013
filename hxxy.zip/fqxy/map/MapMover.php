<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/**
 * 数据驱动地图移动引擎
 * 已转换的地图直接读 data/ 改坐标，未转换的返回 false 走旧逻辑
 */
class MapMover
{
    const UP    = 'up';
    const DOWN  = 'down';
    const LEFT  = 'left';
    const RIGHT = 'right';

    private static $mapFileMap = null;

    private static function getMapFileMap()
    {
        if (self::$mapFileMap === null) {
            self::$mapFileMap = include __DIR__ . '/map_file_map.php';
        }
        return self::$mapFileMap;
    }

    /**
     * @param string $direction  up/down/left/right
     * @param int    $wjid
     * @return bool  true=已处理
     */
    public static function tryMove($direction, $wjid)
    {
        $path = 'ache/' . $wjid;
        $ininame = $path . '/user.ini';
        if (!DbIniStore::fileExists($ininame)) {
            return false;
        }

        $iniFile = new iniFile($ininame);
        $dtx = (int)$iniFile->getItem('地图坐标', 'x');
        $dty = (int)$iniFile->getItem('地图坐标', 'y');

        require_once __DIR__ . '/../../lib/MapStore.php';
        if (!MapStore::hasZone($dtx)) {
            return false;
        }
        $loc = MapStore::loc($dtx, $dty);
        if ($loc === null) {
            return false;
        }
        if (empty($loc['exits'][$direction])) {
            return true; // 无出口，不移动
        }

        $exit = $loc['exits'][$direction];
        if (!isset($exit['dty']) && !isset($exit['dtx'])) {
            return true;
        }

        $newDtx = isset($exit['dtx']) ? (int)$exit['dtx'] : $dtx;
        $newDty = isset($exit['dty']) ? (int)$exit['dty'] : $dty;

        // 住宅地图共用 dtx=92，但每名玩家仍绑定自己的住宅实例；房间开放权限在服务端再次校验。
        if ($dtx === 92 && $newDtx === 92) {
            $roomByDty = array(0=>'hall',1=>'jewelry',2=>'training',3=>'butler',4=>'banquet',5=>'fishing',6=>'master',7=>'storage',8=>'alchemy',9=>'study',10=>'bath');
            if (isset($roomByDty[$newDty])) {
                $state = $iniFile->getCategory('住宅状态');
                $instanceId = isset($state['instance_id']) ? (int)$state['instance_id'] : 0;
                require_once __DIR__ . '/../../lib/HouseDb.php';
                $house = $instanceId > 0 ? HouseDb::houseByInstance($instanceId) : null;
                if (!$house || !HouseDb::canVisitHouse($house, (int)$wjid)) {
                    echo "<font color=red>住宅访问状态失效，请重新进入住宅。</font><br/>";
                    return true;
                }
                if (!HouseDb::roomAccess($house['house_type'], $roomByDty[$newDty])) {
                    echo "<font color=red>当前住宅类型暂不开放这个房间。</font><br/>";
                    return true;
                }
            }
        }

        $iniFile->updItem('地图坐标', [
            'x' => $newDtx,
            'y' => $newDty,
        ]);

        // 通过地图数据中的 out 出口离开住宅时，清除住宅实例绑定。
        // 目的地由 map_exit.to_dtx/to_dty 决定，不再额外绕过 xy002 做手写跳转。
        if ($dtx === 92 && $newDtx !== 92) {
            $iniFile->delCategory('住宅状态');
        }

        return true;
    }
}
