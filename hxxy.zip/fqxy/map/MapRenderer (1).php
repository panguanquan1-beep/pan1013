<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/**
 * 地图渲染核心类
 *
 * NPC 相对地图图的位置（pos）：
 *   above_img  - 地图图片【上面】（紧跟地名后、出图前）
 *   below_img  - 地图图片【下面】
 *   after_name - 同 above_img（兼容旧数据）
 *   after_map  - 同 below_img（兼容旧数据，默认）
 *   before_desc / before_exits - 出口相关区域
 *
 * 地点图：
 *   'img' => 'pic/xxx.png'
 *   'img_always' => true  强制显示
 */
class MapRenderer
{
    // 村长家主线任务标记：从 xsc0.php 捕获后，移动到对应村长 NPC 链接前。
    private static $pendingNpcMarker = '';
    private static $villageChiefQuestArg = '';
    private static $isVillageChiefMap = false;
    private static $villageChiefLinkRendered = false;

    const DIR_UP    = 3;
    const DIR_DOWN  = 4;
    const DIR_LEFT  = 5;
    const DIR_RIGHT = 6;
    const CMD_REFRESH = 2;
    const CMD_VIEWMAP = 8;

    private static function getPlayerLevel($wjid)
    {
        static $cache = array();
        if (isset($cache[$wjid])) {
            return $cache[$wjid];
        }
        $lv = 0;
        $path = 'ache/' . $wjid . '/zt.ini';
        if (DbIniStore::isFile($path) && class_exists('iniFile')) {
            try {
                $ini = new iniFile($path);
                $lv = (int)$ini->getItem('玩家信息', '等级');
            } catch (Exception $e) {
                $lv = 0;
            }
        }
        if ($lv <= 0) {
            $ztFile = __DIR__ . '/../ini/zt_ini.php';
            if (DbIniStore::isFile($ztFile)) {
                $GLOBALS['wjid'] = $wjid;
                include $ztFile;
                if (isset($iniFile) && is_object($iniFile)) {
                    $lv = (int)$iniFile->getItem('玩家信息', '等级');
                }
            }
        }
        $cache[$wjid] = $lv > 0 ? $lv : 0;
        return $cache[$wjid];
    }

    public static function checkExitAccess($exit, $playerLv)
    {
        $minLv = 0;
        if (isset($exit['min_lv'])) {
            $minLv = (int)$exit['min_lv'];
        } elseif (isset($exit['need_lv'])) {
            $minLv = (int)$exit['need_lv'];
        }
        if ($minLv <= 0) {
            return array('ok' => true, 'tip' => '', 'min_lv' => 0);
        }
        if ($playerLv >= $minLv) {
            return array('ok' => true, 'tip' => '', 'min_lv' => $minLv);
        }
        $tip = isset($exit['lock_tip']) && $exit['lock_tip'] !== ''
            ? $exit['lock_tip']
            : ('需要' . $minLv . '级');
        return array('ok' => false, 'tip' => $tip, 'min_lv' => $minLv);
    }

    private static function renderImage($src, $tpbl = 0, $always = false)
    {
        if ($src === '' || $src === null) {
            return;
        }
        if (!$always && !(int)$tpbl) {
            return;
        }
        $src = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
        echo '<img src="' . $src . '" alt="图片"/><br>';
    }

    private static function renderLocImages($loc, $tpbl)
    {
        $always = !empty($loc['img_always']);
        if (!empty($loc['img'])) {
            self::renderImage($loc['img'], $tpbl, $always);
        }
        if (!empty($loc['imgs']) && is_array($loc['imgs'])) {
            foreach ($loc['imgs'] as $src) {
                self::renderImage($src, $tpbl, $always);
            }
        }
    }

    /**
     * 规范化 pos：
     *   above_img / after_name → above_img
     *   below_img / after_map / 未写 → below_img
     */
    private static function normalizePos($pos)
    {
        if ($pos === 'above_img' || $pos === 'after_name') {
            return 'above_img';
        }
        if ($pos === 'below_img' || $pos === 'after_map' || $pos === '' || $pos === null) {
            return 'below_img';
        }
        return $pos;
    }

    private static function renderNpcs($npcs, $pos, $wjid, $a1, &$cmid, &$cdid, &$clj, &$npc, $tpbl = 0)
    {
        if (empty($npcs) || !is_array($npcs)) {
            return;
        }
        $want = self::normalizePos($pos);
        foreach ($npcs as $n) {
            $nPos = isset($n['pos']) ? $n['pos'] : 'below_img';
            $nPos = self::normalizePos($nPos);
            if ($nPos !== $want) {
                continue;
            }
            if (isset($n['min_lv']) && (int)$n['min_lv'] > 0) {
                $plv = self::getPlayerLevel($wjid);
                if ($plv < (int)$n['min_lv']) {
                    continue;
                }
            }
            if (!empty($n['img'])) {
                self::renderImage($n['img'], $tpbl, !empty($n['img_always']));
            }

            $color  = isset($n['color']) ? $n['color'] : 'blue';
            $name   = isset($n['name']) ? $n['name'] : 'NPC';
            $plainName = html_entity_decode(strip_tags((string)$name), ENT_QUOTES, 'UTF-8');
            $isVillageChiefNpc = self::$isVillageChiefMap
                && strpos($plainName, '村长') !== false
                && strpos($plainName, '存钱罐') === false
                && strpos($plainName, '村长家') === false;

// 村长家只保留带主线的原村长入口；没有主线时隐藏普通“哎！老了”入口。
// (已废除村长特权，统一走数据库逻辑)

$cmid = $cmid + 1;
$cdid[] = $cmid;

// 所有 NPC 统一按数据库填写的 cmd 和 id 执行
$clj[]  = isset($n['cmd']) ? intval($n['cmd']) : 7;
$npc[]  = isset($n['id']) ? intval($n['id']) : 0;

// 参考：<a><img 头像 alt=NPC名/>NPC名</a>（仅同名 NPC、开图片时）
$face = '';
if (empty($n['img']) && (int)$tpbl) { 
    require_once(__DIR__ . '/../../lib/RefImg.php'); 
    $face = RefImg::npc(strip_tags($name)); 
}
$nm = $color !== '' ? "<font color={$color}>{$name}</font>" : $name; 
            echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'>{$face}{$nm}</a>" . "<br/>";
        }
    }

    /** 参考出口链接：标签原文，方向键 accesskey 2/8/4/6；非方向出口(进入X)走 xy003 带 dir */
    private static function exitLink($key, $exit, $wjid, $a1, &$cmid, &$cdid, &$clj, &$npc)
    {
        static $map = array('up' => array(3, '上:', 2), 'down' => array(4, '下:', 8), 'left' => array(5, '左:', 4), 'right' => array(6, '右:', 6));
        $lbl = isset($exit['label']) ? $exit['label'] : ((isset($map[$key]) ? $map[$key][1] : '') . $exit['name']);
        $cmid++; $cdid[] = $cmid;
        if (isset($map[$key])) { $clj[] = $map[$key][0]; $npc[] = 0; $ak = " accesskey=\"{$map[$key][2]}\""; }
        else { $clj[] = 3; $npc[] = 'go_' . $key; $ak = ''; }
        echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'$ak>{$lbl}</a><br/>";
    }

    /**
     * 在地点标题正下方显示登记在此地点的官宅。
     * world_map_code 使用玩家地图坐标中的 dtx，location_code 使用 dty。
     * 官宅入口统一回到 xy002；住宅实例和当前房间由 NPC 参数携带。
     */
    private static function renderOfficialHouseLinks($mapDtx, $mapDty, $wjid, $a1, &$cmid, &$cdid, &$clj, &$npc)
    {
        if ($mapDtx === null || $mapDty === null || $mapDtx === '' || $mapDty === '') {
            return;
        }
        try {
            require_once __DIR__ . '/../../lib/HouseDb.php';
            if (!class_exists('HouseDb') || !HouseDb::schemaReady()) {
                return;
            }
            $houses = HouseDb::officialHousesAt((string)(int)$mapDtx, (string)(int)$mapDty);
            if (!$houses) {
                return;
            }
            foreach ($houses as $house) {
                $instanceId = isset($house['id']) ? (int)$house['id'] : 0;
                if ($instanceId <= 0) {
                    continue;
                }
                $houseName = isset($house['house_name']) ? (string)$house['house_name'] : '未命名官宅';
                $cmid++;
                $cdid[] = $cmid;
                $clj[] = 2;
                $npc[] = 'HX2__' . $instanceId . '__hall__view__0__0';
                $url = 'xy.php?uid=' . (int)$wjid . '&&cmd=' . (int)$cmid . '&&sid=' . rawurlencode((string)$a1);
                echo "<a href='" . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . "'><font color='blue'>" . htmlspecialchars($houseName, ENT_QUOTES, 'UTF-8') . "</font></a><br/>";
            }
        } catch (Exception $e) {
            error_log('Official house map render failed: ' . $e->getMessage());
        }
    }

    public static function render($loc, $wjid, $a1, &$cmid, &$cdid, &$clj, &$npc, $tpbl = 0, $gwInclude = '', $mapDtx = null, $mapDty = null)
    {
        $npcs = isset($loc['npcs']) ? $loc['npcs'] : array();
        $playerLv = self::getPlayerLevel($wjid);

        // 旧村长家/xsc0.php 特殊逻辑已废止（地图已清空，待按参考服重做 dtx=0）。
        $isVillageChiefMap = false;
        self::$isVillageChiefMap = $isVillageChiefMap;
        self::$villageChiefLinkRendered = false;
        self::$pendingNpcMarker = '';
        self::$villageChiefQuestArg = '';

        // 1. 地名 + 刷新
        $cmid = $cmid + 1;
        $cdid[] = $cmid;
        $clj[]  = self::CMD_REFRESH;
        $npc[]  = 0;
        $rf = $cmid;
        $cmid++; $cdid[] = $cmid; $clj[] = 750; $npc[] = 'weijie'; $wj = $cmid;
        $cmid++; $cdid[] = $cmid; $clj[] = 750; $npc[] = 'renwu'; $rw = $cmid;
        // 参考：地名[未接]|[任务]|[刷新]
        echo $loc['name'] . "<a href='xy.php?uid=$wjid&&cmd=$wj&&sid=$a1'>未接</a>|<a href='xy.php?uid=$wjid&&cmd=$rw&&sid=$a1'>任务</a>|<a href='xy.php?uid=$wjid&&cmd=$rf&&sid=$a1' accesskey='5'>刷新</a><br/>";

        // 官宅入口紧跟地点标题显示，位置与普通 NPC 名称入口一致。
        self::renderOfficialHouseLinks($mapDtx, $mapDty, $wjid, $a1, $cmid, $cdid, $clj, $npc);

        // 没配图的场景：按同名取参考场景图（lib/ref_img_map.php），位置与参考一致：标题行下独占一行（在所有 NPC 之前）
        if (empty($loc['img']) && empty($loc['imgs']) && (int)$tpbl && isset($loc['name'])) {
            require_once(__DIR__ . '/../../lib/RefImg.php');
            $ri = RefImg::scene(preg_replace('/\(危\)|\(\d+,\d+\)/u', '', strip_tags($loc['name'])));
            if ($ri !== '') echo $ri . '<br/>';
        }
        // 村长家任务初始化延后到地图主体输出完成后执行。
        // 新玩家首次初始化 zxrw/yxrw 时，旧初始化逻辑可能中断请求；
        // 不可在地点标题后、地图正文前执行，否则页面会只剩标题。
        $__xsc0IncludedEarly = false;
        $__villageChiefMarkerHtml = '';
        $__villageChiefQuestArg = '';

        // 2. 地图图【上面】的 NPC
        self::renderNpcs($npcs, 'above_img', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl);

        // 3. 地点地图大图
        self::renderLocImages($loc, $tpbl);

        // 4. 地图图【下面】的 NPC；有参考正文顺序(body)时按其逐行输出（NPC/进入X/文字）
        $inBody = array();
        if (!empty($loc['body']) && is_array($loc['body'])) {
            $bySeq = array(); foreach ((array)$npcs as $i => $n) $bySeq[$i + 1] = $n;
            foreach ($loc['body'] as $b) {
                if (isset($b['n']) && isset($bySeq[$b['n']])) { if (!empty($b['sp'])) { ob_start(); self::renderNpcs(array($bySeq[$b['n']]), 'below_img', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl); echo preg_replace('#<br\s*/?>\s*$#', ' ', ob_get_clean()); } else self::renderNpcs(array($bySeq[$b['n']]), 'below_img', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl); }
                elseif (isset($b['x']) && isset($loc['exits'][$b['x']])) { self::exitLink($b['x'], $loc['exits'][$b['x']], $wjid, $a1, $cmid, $cdid, $clj, $npc); $inBody[$b['x']] = 1; }
                elseif (isset($b['t'])) echo htmlspecialchars($b['t'], ENT_QUOTES, 'UTF-8') . "<br/>";
            }
        } else {
            self::renderNpcs($npcs, 'below_img', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl);
        }

        // 5. 前置 include / 怪物
        if (!empty($loc['include_before']) && !$__xsc0IncludedEarly
            && !($isVillageChiefMap && basename(str_replace('\\', '/', $loc['include_before'])) === 'xsc0.php')) {
            $inc = $loc['include_before'];
            if (DbIniStore::fileExists($inc)) {
                include($inc);
            } elseif (DbIniStore::fileExists(__DIR__ . '/../' . ltrim($inc, './'))) {
                include(__DIR__ . '/../' . ltrim($inc, './'));
            }
        }

        if ($gwInclude !== '' && DbIniStore::fileExists($gwInclude)) {
            include($gwInclude);
        }

        // 6. 其他位置 NPC
        self::renderNpcs($npcs, 'before_desc', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl);
        self::renderNpcs($npcs, 'before_exits', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl);

        // 7. 出口
        echo "<!--SEEN-->请选择出口&nbsp;<br/>";
        if (!empty($loc['exits']) && is_array($loc['exits'])) {
            foreach ($loc['exits'] as $key => $exit) {
                if ($exit === null || isset($inBody[$key])) continue;
                $check = self::checkExitAccess($exit, $playerLv);
                if (!$check['ok']) {
                    if (isset($exit['hide_locked']) && !$exit['hide_locked']) echo "<font color=gray>" . (isset($exit['label']) ? $exit['label'] : $exit['name']) . "（{$check['tip']}）</font><br>";
                    continue;
                }
                self::exitLink($key, $exit, $wjid, $a1, $cmid, $cdid, $clj, $npc);
            }
        }

        // 参考：---更多操作--- / [查看地图(0)] | [快速回城]
        $cmid++; $cdid[] = $cmid; $clj[] = 750; $npc[] = 'map'; $mp = $cmid;
        $cmid++; $cdid[] = $cmid; $clj[] = 37; $npc[] = 1;
        echo "---更多操作---<br/><a href='xy.php?uid=$wjid&&cmd=$mp&&sid=$a1'>查看地图(0)</a>&nbsp;|&nbsp;<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'>快速回城</a><br/>";
        if (!empty($loc['desc']) && empty($loc['desc_after'])) {
            echo "<font color=black>{$loc['desc']}</font>" . "<br>";
        }
        if (!empty($loc['desc']) && !empty($loc['desc_after'])) {
            echo "<font color=black>{$loc['desc']}</font>" . "<br>";
        }

        self::$pendingNpcMarker = '';
        self::$villageChiefQuestArg = '';
        self::$isVillageChiefMap = false;
        self::$villageChiefLinkRendered = false;
    }
}
