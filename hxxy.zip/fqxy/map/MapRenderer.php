<?php
// 统一数据库状态存储：历史 .ini 路径不再访问磁盘
if (!class_exists('DbIniStore', false)) {
    $__dbini_root = __DIR__;
    while ($__dbini_root && !is_file($__dbini_root . '/config/app.php')) {
        $__dbini_parent = dirname($__dbini_root);
        if ($__dbini_parent === $__dbini_root) { $__dbini_root = false; break; }
        $__dbini_root = $__dbini_parent;
    }
    if ($__dbini_root && is_file($__dbini_root . '/lib/DbIniStore.php')) require_once $__dbini_root . '/lib/DbIniStore.php';
    unset($__dbini_root, $__dbini_parent);
}

/**
 * 地图渲染核心类
 *
 * NPC 相对地图图的位置（pos）：
 *   above_img  - 地图图片【上面】（紧跟地名后、出图前）
 *   below_img  - 地图图片【下面】
 *   after_name - 同 above_img（兼容旧数据）
 *   after_map  - 同 below_img（兼容旧数据，默认）
 *   before_desc / before_exits - 出口相关区域
 *
 * 地点图：
 *   'img' => 'pic/xxx.png'
 *   'img_always' => true  强制显示
 */
class MapRenderer
{
    // 村长家主线任务标记：从 xsc0.php 捕获后，移动到对应村长 NPC 链接前。
    private static $pendingNpcMarker = '';
    private static $villageChiefQuestArg = '';
    private static $isVillageChiefMap = false;
    private static $villageChiefLinkRendered = false;
    // 闪烁 NPC 的 CSS 只需输出一次
    private static $flashCssShown = false;

    const DIR_UP    = 3;
    const DIR_DOWN  = 4;
    const DIR_LEFT  = 5;
    const DIR_RIGHT = 6;
    const CMD_REFRESH = 2;
    const CMD_VIEWMAP = 8;

    private static function getPlayerLevel($wjid)
    {
        static $cache = array();
        if (isset($cache[$wjid])) {
            return $cache[$wjid];
        }
        $lv = 0;
        $path = 'ache/' . $wjid . '/zt.ini';
        if (DbIniStore::isFile($path) && class_exists('iniFile')) {
            try {
                $ini = new iniFile($path);
                $lv = (int)$ini->getItem('玩家信息', '等级');
            } catch (Exception $e) {
                $lv = 0;
            }
        }
        if ($lv <= 0) {
            $ztFile = __DIR__ . '/../ini/zt_ini.php';
            if (DbIniStore::isFile($ztFile)) {
                $GLOBALS['wjid'] = $wjid;
                include $ztFile;
                if (isset($iniFile) && is_object($iniFile)) {
                    $lv = (int)$iniFile->getItem('玩家信息', '等级');
                }
            }
        }
        $cache[$wjid] = $lv > 0 ? $lv : 0;
        return $cache[$wjid];
    }

    public static function checkExitAccess($exit, $playerLv)
    {
        $minLv = 0;
        if (isset($exit['min_lv'])) {
            $minLv = (int)$exit['min_lv'];
        } elseif (isset($exit['need_lv'])) {
            $minLv = (int)$exit['need_lv'];
        }
        if ($minLv <= 0) {
            return array('ok' => true, 'tip' => '', 'min_lv' => 0);
        }
        if ($playerLv >= $minLv) {
            return array('ok' => true, 'tip' => '', 'min_lv' => $minLv);
        }
        $tip = isset($exit['lock_tip']) && $exit['lock_tip'] !== ''
            ? $exit['lock_tip']
            : ('需要' . $minLv . '级');
        return array('ok' => false, 'tip' => $tip, 'min_lv' => $minLv);
    }

    private static function renderImage($src, $tpbl = 0, $always = false)
    {
        if ($src === '' || $src === null) {
            return;
        }
        if (!$always && (int)$tpbl !== 1) {
            return;
        }
        $src = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
        echo '<img src="' . $src . '" alt="图片"/><br>';
    }

    private static function renderLocImages($loc, $tpbl)
    {
        $always = !empty($loc['img_always']);
        if (!empty($loc['img'])) {
            self::renderImage($loc['img'], $tpbl, $always);
        }
        if (!empty($loc['imgs']) && is_array($loc['imgs'])) {
            foreach ($loc['imgs'] as $src) {
                self::renderImage($src, $tpbl, $always);
            }
        }
    }

    /**
     * 规范化 pos：
     *   above_img / after_name → above_img
     *   below_img / after_map / 未写 → below_img
     */
    private static function normalizePos($pos)
    {
        if ($pos === 'above_img' || $pos === 'after_name') {
            return 'above_img';
        }
        if ($pos === 'below_img' || $pos === 'after_map' || $pos === '' || $pos === null) {
            return 'below_img';
        }
        return $pos;
    }

    private static $mobNameCount = array();

    /** 场景上的野怪（战斗怪 / 名字带 *） */
    private static function isWildMonster($plainName, $cmd, $npcId)
    {
        $plainName = (string)$plainName;
        if ($plainName !== '' && isset($plainName[0]) && $plainName[0] === '*') {
            return true;
        }
        $cmd = (int)$cmd;
        if (($cmd === 10 || $cmd === 18) && (int)$npcId > 0) {
            require_once __DIR__ . '/../../lib/NpcStore.php';
            if (NpcStore::combat((int)$npcId) !== null) {
                return true;
            }
        }
        return false;
    }

    /**
     * 旧 gw 文件常把同名怪横排、逗号分隔且超过两只。
     * 整理成：同名最多两只，一只一行。
     */
    private static function formatGwMonsters($html)
    {
        if ($html === '' || $html === null) {
            return $html;
        }
        $counts = array();
        $re = '/(<a\s[^>]*>.*?<\/a>)(\s*,\s*)?/is';
        $out = '';
        $last = 0;
        if (!preg_match_all($re, $html, $ms, PREG_OFFSET_CAPTURE)) {
            return $html;
        }
        $n = count($ms[0]);
        for ($i = 0; $i < $n; $i++) {
            $start = $ms[0][$i][1];
            $full = $ms[0][$i][0];
            if ($start > $last) {
                $out .= substr($html, $last, $start - $last);
            }
            $a = $ms[1][$i][0];
            $name = trim(html_entity_decode(strip_tags($a), ENT_QUOTES, 'UTF-8'));
            $isMob = ($name !== '' && isset($name[0]) && $name[0] === '*');
            if ($isMob) {
                if (!isset($counts[$name])) {
                    $counts[$name] = 0;
                }
                if ($counts[$name] >= 2) {
                    $last = $start + strlen($full);
                    continue;
                }
                $counts[$name]++;
                $out .= $a . "<br/>";
            } else {
                $out .= $full;
            }
            $last = $start + strlen($full);
        }
        $out .= substr($html, $last);
        $out = preg_replace('/(?:<br\s*\/?>\s*){3,}/i', "<br/><br/>", $out);
        $out = preg_replace('/,(?=\s*(?:<br|<\/|$))/i', '', $out);
        return $out;
    }

    private static function renderNpcs($npcs, $pos, $wjid, $a1, &$cmid, &$cdid, &$clj, &$npc, $tpbl = 0)
    {
        if (empty($npcs) || !is_array($npcs)) {
            return;
        }
        $want = self::normalizePos($pos);
        foreach ($npcs as $n) {
            $nPos = isset($n['pos']) ? $n['pos'] : 'below_img';
            $nPos = self::normalizePos($nPos);
            if ($nPos !== $want) {
                continue;
            }
            // 39/79 级转职任务 NPC 按阶段显示（含梦魇、筋斗云~东营房）
            if (isset($n['id'])) {
                require_once(__DIR__ . '/../../lib/Zhuanzhi39.php');
                require_once(__DIR__ . '/../../lib/Zhuanzhi79.php');
                include_once(__DIR__ . '/../wp/player_view.php');
                $__zp = explode(',', pv_pos($wjid) . ',');
                if (Zhuanzhi39::hidden($wjid, (int)$n['id'], (int)$__zp[0], (int)$__zp[1])) continue;
                if (Zhuanzhi79::hidden($wjid, (int)$n['id'], (int)$__zp[0], (int)$__zp[1])) continue;
            }
            if (isset($n['min_lv']) && (int)$n['min_lv'] > 0) {
                $plv = self::getPlayerLevel($wjid);
                if ($plv < (int)$n['min_lv']) {
                    continue;
                }
            }
            if (!empty($n['img'])) {
                self::renderImage($n['img'], $tpbl, !empty($n['img_always']));
            }

            $color  = isset($n['color']) ? $n['color'] : 'blue';
            $name   = isset($n['name']) ? $n['name'] : 'NPC';
            $plainName = html_entity_decode(strip_tags((string)$name), ENT_QUOTES, 'UTF-8');
            $isVillageChiefNpc = self::$isVillageChiefMap
                && strpos($plainName, '村长') !== false
                && strpos($plainName, '存钱罐') === false
                && strpos($plainName, '村长家') === false;

// 村长家只保留带主线的原村长入口；没有主线时隐藏普通“哎！老了”入口。
// (已废除村长特权，统一走数据库逻辑)

$cmid = $cmid + 1;
$cdid[] = $cmid;

// 所有 NPC 统一按数据库填写的 cmd 和 id 执行。
// 可攻击战斗怪（page=10 且在 monster_def）先进遇怪页 xy018，再点「攻击XX」才进 xy010。
// 李白/张果老等 page=10 但不在 monster_def 的入口保持原样，直接走 10。
// 主线「教训xxx」「打败xxx」虽然也在 monster_def，但点下去要直接进战斗，不进遇怪对话页。
$__npcCmd = isset($n['cmd']) ? intval($n['cmd']) : 7;
$__npcId  = isset($n['id']) ? intval($n['id']) : 0;
$__isQuestFight = (strpos($plainName, '教训') === 0 || strpos($plainName, '打败') === 0);
if ($__npcCmd === 10 && $__npcId > 0 && !$__isQuestFight) {
    require_once(__DIR__ . '/../../lib/NpcStore.php');
    if (NpcStore::combat($__npcId) !== null) {
        $__npcCmd = 18;
    }
}
// 野怪：同名最多显示两只
if (self::isWildMonster($plainName, $__npcCmd, $__npcId)) {
    if (!isset(self::$mobNameCount[$plainName])) self::$mobNameCount[$plainName] = 0;
    if (self::$mobNameCount[$plainName] >= 2) {
        array_pop($cdid);
        $cmid = $cmid - 1;
        continue;
    }
    self::$mobNameCount[$plainName]++;
}
$clj[]  = $__npcCmd;
$npc[]  = $__npcId;

// 参考：<a><img 头像 alt=NPC名/>NPC名</a>（仅同名 NPC、开图片时）
$face = '';
if (empty($n['img']) && (int)$tpbl === 1) { 
    require_once(__DIR__ . '/../../lib/RefImg.php'); 
    $face = RefImg::npc(strip_tags($name)); 
}
$nm = $color !== '' ? "<font color={$color}>{$name}</font>" : $name;
// 特殊色值：color 写成 flash:#RRGGBB → 至尊闪烁 + 加粗（大唐帝王宫用）
if ($color !== '' && strpos($color, 'flash:') === 0) {
    $fc = trim(substr($color, 6));
    if ($fc === '') $fc = '#A62B2B';
    if (!self::$flashCssShown) {
        self::$flashCssShown = true;
        echo '<style>@keyframes npcflash{0%,100%{opacity:1;text-shadow:0 0 4px rgba(166,43,43,.9)}50%{opacity:.5;text-shadow:0 0 10px rgba(255,214,0,.75)}}.npc-flash{font-weight:bold;animation:npcflash 1.1s ease-in-out infinite;}</style>';
    }
    $nm = '<span class="npc-flash" style="color:' . htmlspecialchars($fc, ENT_QUOTES, 'UTF-8') . '">' . $name . '</span>';
}

// 任务 NPC 名字前的提示标记（用户原版 lib/QuestNpcUi.php：pic/ts/ts1.png 叹号=未接或完成待交，ts2.png 问号=已接未完成；
// 关图片时显示文字 ！/？）。以前由旧 rwmap/xsc*.php 输出，041/042 重建 dtx0 后丢了，这里对所有任务 NPC 统一输出。
// 注意：不要删掉或用开关关掉这段，见 docs/图片不要关.md。
$questMark = '';
if ((!isset($n['cmd']) || (int)$n['cmd'] === 7) && isset($n['id'])) {
    require_once(__DIR__ . '/../../lib/QuestNpcUi.php');
    include_once(__DIR__ . '/../wp/player_view.php');
    $__mp = explode(',', pv_pos($wjid) . ',');
    $questMark = QuestNpcUi::markerAt($wjid, (int)$n['id'], (int)$__mp[0], (int)$__mp[1], (int)$tpbl);
}
$promoBang = '';
        if (!empty($n['promo_icon'])) {
            require_once(__DIR__ . '/../../lib/RefImg.php');
            $promoBang = RefImg::tag($n['promo_icon'], '感叹号');
        }
        echo $questMark . "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'>{$promoBang}{$face}{$nm}</a>" . "<br/>";
        }
    }

    /** 参考出口链接：标签原文，方向键 accesskey 2/8/4/6；非方向出口(进入X)走 xy003 带 dir */
    /** 四个方向键 */
    private static function isDirExit($key)
    {
        return $key === 'up' || $key === 'down' || $key === 'left' || $key === 'right';
    }

    /** 四方向出口文案：有「上:地名」就原样用；库里只有地名时补上「上:」；迷宫格只有「上」则不重复加 */
    private static function exitLabel($key, $exit)
    {
        static $prefix = array('up' => '上:', 'down' => '下:', 'left' => '左:', 'right' => '右:');
        $name = (isset($exit['name']) && $exit['name'] !== '') ? $exit['name'] : '';
        $lbl = (isset($exit['label']) && $exit['label'] !== '') ? $exit['label'] : $name;
        if ($lbl === '') $lbl = '房间';
        if (!isset($prefix[$key])) return $lbl;
        if (preg_match('/^(上|下|左|右)[:：]/u', $lbl) || preg_match('/^(上|下|左|右)$/u', $lbl)) {
            return $lbl;
        }
        return $prefix[$key] . $lbl;
    }

    private static function exitLink($key, $exit, $wjid, $a1, &$cmid, &$cdid, &$clj, &$npc)
    {
        static $map = array('up' => array(3, '上:', 2), 'down' => array(4, '下:', 8), 'left' => array(5, '左:', 4), 'right' => array(6, '右:', 6));
        // 四方向各用一种绚丽色：上红、下橙、左黄、右绿
        static $dirColor = array('up' => '#FF2010', 'down' => '#FF8A00', 'left' => '#E6B800', 'right' => '#00B33C');
        $lbl = self::exitLabel($key, $exit);
        $cmid++; $cdid[] = $cmid;
        if (isset($map[$key])) { $clj[] = $map[$key][0]; $npc[] = 0; $ak = " accesskey=\"{$map[$key][2]}\""; }
        else { $clj[] = 3; $npc[] = 'go_' . $key; $ak = ''; }
        if (isset($dirColor[$key])) {
            // 四个方向一律横排一行，只上色加粗，不做竖排
            $lbl = '<span style="color:' . $dirColor[$key] . ';font-weight:bold;white-space:nowrap;">' . $lbl . '</span>';
        }
        echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'$ak>{$lbl}</a><br/>";

    }

    /** 场景特殊入口（如雪山迷宫进入【冰晶塔】）：不放在「请选择出口」区 */
    private static function isSceneEnterExit($exit)
    {
        return is_array($exit) && !empty($exit['scene_enter']);
    }

    /** 「发现新区域」入口：进入长安城 / 进入高家庄 等，显示在「请选择出口」之前 */
    private static function isDiscoverExit($key, $exit)
    {
        if (!is_array($exit) || self::isDirExit($key) || self::isSceneEnterExit($exit)) {
            return false;
        }
        $lbl = '';
        if (isset($exit['label']) && $exit['label'] !== '') {
            $lbl = $exit['label'];
        } elseif (isset($exit['name'])) {
            $lbl = $exit['name'];
        }
        $lbl = html_entity_decode(strip_tags((string)$lbl), ENT_QUOTES, 'UTF-8');
        $lbl = trim($lbl);
        return $lbl !== '' && preg_match('/^(进入|【)/u', $lbl);
    }

    /**
     * 在地图图（及图下 NPC/body）之后、怪物列表之前，单独画出 scene_enter 链接。
     * 点击协议与 exitLink 非方向出口相同：clj=3，npc=go_{dir}，由 xy003 / MapMover::tryMove 走 loc()['exits']。
     * 文案与样式跟旧地图「进入【xxx】」写法：<font color=blue>进入【冰晶塔】</font>
     */
    private static function renderSceneEnterLinks($loc, $wjid, $a1, &$cmid, &$cdid, &$clj, &$npc)
    {
        if (empty($loc['exits']) || !is_array($loc['exits'])) {
            return;
        }
        foreach ($loc['exits'] as $key => $exit) {
            if ($exit === null || !self::isSceneEnterExit($exit)) {
                continue;
            }
            $lbl = '进入【冰晶塔】';
            if (isset($exit['label']) && $exit['label'] !== '') {
                $lbl = $exit['label'];
            } elseif (isset($exit['name']) && $exit['name'] !== '') {
                $lbl = $exit['name'];
            }
            $cmid++;
            $cdid[] = $cmid;
            $clj[] = 3;
            $npc[] = 'go_' . $key;
            echo "<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'><font color=blue>" . htmlspecialchars($lbl, ENT_QUOTES, 'UTF-8') . "</font></a><br/>";
        }
    }

    /**
     * 在地点标题正下方显示登记在此地点的官宅。
     * world_map_code 使用玩家地图坐标中的 dtx，location_code 使用 dty。
     * 官宅链接沿用原版 xy.php 路由回到页面 2，由 xy002 识别住宅实例参数。
     */
    private static function renderOfficialHouseLinks($mapDtx, $mapDty, $wjid, $a1, &$cmid, &$cdid, &$clj, &$npc)
    {
        if ($mapDtx === null || $mapDty === null || $mapDtx === '' || $mapDty === '') {
            return;
        }
        try {
            require_once __DIR__ . '/../../lib/HouseDb.php';
            if (!class_exists('HouseDb') || !HouseDb::schemaReady()) {
                return;
            }
            $houses = HouseDb::officialHousesAt((string)(int)$mapDtx, (string)(int)$mapDty);
            if (!$houses) {
                return;
            }
            foreach ($houses as $house) {
                $instanceId = isset($house['id']) ? (int)$house['id'] : 0;
                if ($instanceId <= 0) {
                    continue;
                }
                $houseName = isset($house['house_name']) ? (string)$house['house_name'] : '未命名官宅';
                $cmid++;
                $cdid[] = $cmid;
                $clj[] = 2;
                $npc[] = 'house_enter_' . $instanceId;
                $url = 'xy.php?uid=' . (int)$wjid . '&&cmd=' . (int)$cmid . '&&sid=' . rawurlencode((string)$a1);
                echo "<a href='" . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . "'><font color='blue'>" . htmlspecialchars($houseName, ENT_QUOTES, 'UTF-8') . "</font></a><br/>";
            }
        } catch (Exception $e) {
            error_log('Official house map render failed: ' . $e->getMessage());
        }
    }

    /** 住宅房间出口权限：民宅不开放书房/浴室，豪宅不开放浴室。 */
    private static function checkHouseRoomAccess($mapDtx, $exit, $wjid)
    {
        if ((int)$mapDtx !== 92 || !isset($exit['dty'])) return array('ok' => true, 'locked' => false);
        $roomByDty = array(0=>'hall',1=>'jewelry',2=>'training',3=>'butler',4=>'banquet',5=>'fishing',6=>'master',7=>'storage',8=>'alchemy',9=>'study',10=>'bath');
        $target = (int)$exit['dty'];
        if (!isset($roomByDty[$target])) return array('ok' => true, 'locked' => false);
        try {
            $ini = new iniFile('ache/' . (int)$wjid . '/user.ini');
            $state = $ini->getCategory('住宅状态');
            $instanceId = isset($state['instance_id']) ? (int)$state['instance_id'] : 0;
            if ($instanceId <= 0) return array('ok' => false, 'locked' => true);
            require_once __DIR__ . '/../../lib/HouseDb.php';
            $house = HouseDb::houseByInstance($instanceId);
            if (!$house || !HouseDb::canVisitHouse($house, (int)$wjid)) return array('ok' => false, 'locked' => true);
            $ok = HouseDb::roomAccess($house['house_type'], $roomByDty[$target]);
            return array('ok' => $ok, 'locked' => !$ok);
        } catch (Exception $e) {
            error_log('House room access render error: ' . $e->getMessage());
            return array('ok' => false, 'locked' => true);
        }
    }


    public static function render($loc, $wjid, $a1, &$cmid, &$cdid, &$clj, &$npc, $tpbl = 0, $gwInclude = '', $mapDtx = null, $mapDty = null)
    {
        $npcs = isset($loc['npcs']) ? $loc['npcs'] : array();
        if ($mapDtx === null || $mapDty === null) {
            include_once(__DIR__ . '/../wp/player_view.php');
            $__cp = explode(',', pv_pos($wjid) . ',');
            if ($mapDtx === null) $mapDtx = (int)$__cp[0];
            if ($mapDty === null) $mapDty = (int)$__cp[1];
        }
        $__aa = __DIR__ . '/../../lib/FubenAutoAtk.php';
        if (is_file($__aa)) {
            require_once $__aa;
            if (class_exists('FubenAutoAtk', false)) {
                $GLOBALS['wjid'] = $wjid;
                $GLOBALS['a1'] = $a1;
                $GLOBALS['cmid'] = $cmid;
                $GLOBALS['cdid'] = $cdid;
                $GLOBALS['clj'] = $clj;
                $GLOBALS['npc'] = $npc;
                if (FubenAutoAtk::maybeStartFight($mapDtx, $mapDty, $wjid)) {
                    $cmid = $GLOBALS['cmid'];
                    $cdid = $GLOBALS['cdid'];
                    $clj = $GLOBALS['clj'];
                    $npc = $GLOBALS['npc'];
                    return;
                }
            }
        }
        require_once(__DIR__ . '/../../lib/QuestCargoChest.php');
        require_once(__DIR__ . '/../../lib/QuestHeiyi.php');
        $npcs = QuestCargoChest::applyToNpcs($npcs, $wjid, $mapDtx, $mapDty);
        $npcs = QuestHeiyi::applyToNpcs($npcs, $wjid, $mapDtx, $mapDty);
        $playerLv = self::getPlayerLevel($wjid);
        self::$mobNameCount = array();

        // 场景最顶部：晚间礼包公告（时限内未领时显示），再接升级公告、如意9补领蛋
        require_once __DIR__ . '/../../lib/EveningLogin.php';
        EveningLogin::renderBanner($wjid, $a1, $cmid, $cdid, $clj, $npc);
        require_once __DIR__ . '/../../lib/VipPackCorrect.php';
        VipPackCorrect::renderBanner($wjid, $a1, $cmid, $cdid, $clj, $npc);
        require_once __DIR__ . '/../../lib/HundunEggNotice.php';
        HundunEggNotice::renderBanner($wjid, $a1, $cmid, $cdid, $clj, $npc);
        require_once __DIR__ . '/../../lib/LevelGift.php';
        LevelGift::renderBanner($wjid, $a1, $cmid, $cdid, $clj, $npc, $playerLv);
        require_once __DIR__ . '/../../lib/Zhuanzhi79.php';
        Zhuanzhi79::renderBanner($wjid);

        // 旧村长家/xsc0.php 特殊逻辑已废止（地图已清空，待按参考服重做 dtx=0）。
        $isVillageChiefMap = false;
        self::$isVillageChiefMap = $isVillageChiefMap;
        self::$villageChiefLinkRendered = false;
        self::$pendingNpcMarker = '';
        self::$villageChiefQuestArg = '';

        // 1. 地名 + 刷新
        $cmid = $cmid + 1;
        $cdid[] = $cmid;
        $clj[]  = self::CMD_REFRESH;
        $npc[]  = class_exists('FubenAutoAtk', false) ? FubenAutoAtk::REFRESH_NPC : 0;
        $rf = $cmid;
        $cmid++; $cdid[] = $cmid; $clj[] = 750; $npc[] = 'weijie'; $wj = $cmid;
        $cmid++; $cdid[] = $cmid; $clj[] = 750; $npc[] = 'renwu'; $rw = $cmid;
        // 参考：地名[未接]|[任务]|[刷新]
        echo $loc['name'] . "<a href='xy.php?uid=$wjid&&cmd=$wj&&sid=$a1'>未接</a>|<a href='xy.php?uid=$wjid&&cmd=$rw&&sid=$a1'>任务</a>|<a href='xy.php?uid=$wjid&&cmd=$rf&&sid=$a1' accesskey='5'>刷新</a><br/>";

        // 官宅入口紧跟地点标题显示，位置与普通 NPC 名称入口一致。
        self::renderOfficialHouseLinks($mapDtx, $mapDty, $wjid, $a1, $cmid, $cdid, $clj, $npc);
        // 79 转职：东营房付费筋斗云（打完三只梦魇后的交任阶段）
        require_once __DIR__ . '/../../lib/Zhuanzhi79.php';
        Zhuanzhi79::renderSceneLinks($wjid, $mapDtx, $mapDty, $wjid, $a1, $cmid, $cdid, $clj, $npc);

        // 没配图的场景：按同名取参考场景图（lib/ref_img_map.php），位置与参考一致：标题行下独占一行（在所有 NPC 之前）
        if (empty($loc['img']) && empty($loc['imgs']) && (int)$tpbl === 1 && isset($loc['name'])) {
            require_once(__DIR__ . '/../../lib/RefImg.php');
            $ri = RefImg::scene(preg_replace('/\(危\)|\(\d+,\d+\)/u', '', strip_tags($loc['name'])));
            if ($ri !== '') echo $ri . '<br/>';
        }
        // 村长家任务初始化延后到地图主体输出完成后执行。
        // 新玩家首次初始化 zxrw/yxrw 时，旧初始化逻辑可能中断请求；
        // 不可在地点标题后、地图正文前执行，否则页面会只剩标题。
        $__xsc0IncludedEarly = false;
        $__villageChiefMarkerHtml = '';
        $__villageChiefQuestArg = '';

        // 2. 地图图【上面】的 NPC
        self::renderNpcs($npcs, 'above_img', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl);

        // 3. 地点地图大图
        self::renderLocImages($loc, $tpbl);

        // 4. 地图图【下面】的 NPC。有 body 编排时也要先画出全部 below_img 的 NPC，
        //    再按 body 输出文字与出口。只认 body 里的 n 会把任务 NPC 漏掉（例如大雁塔外的萧晓月）。
        self::renderNpcs($npcs, 'below_img', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl);
        $inBody = array();
        $crossBuf = array('up' => '', 'down' => '', 'left' => '', 'right' => '');
        if (!empty($loc['body']) && is_array($loc['body'])) {
            foreach ($loc['body'] as $b) {
                if (isset($b['n'])) continue;
                if (isset($b['x']) && isset($loc['exits'][$b['x']])) {
                    if (self::isSceneEnterExit($loc['exits'][$b['x']]) || self::isDiscoverExit($b['x'], $loc['exits'][$b['x']])) {
                        continue;
                    }
                    if (self::isDirExit($b['x'])) {
                        ob_start();
                        self::exitLink($b['x'], $loc['exits'][$b['x']], $wjid, $a1, $cmid, $cdid, $clj, $npc);
                        $crossBuf[$b['x']] .= ob_get_clean();
                    } else {
                        self::exitLink($b['x'], $loc['exits'][$b['x']], $wjid, $a1, $cmid, $cdid, $clj, $npc);
                    }
                    $inBody[$b['x']] = 1;
                }
                elseif (isset($b['t'])) {
                    if (trim((string)$b['t']) === '发现新区域') continue;
                    echo htmlspecialchars($b['t'], ENT_QUOTES, 'UTF-8') . "<br/>";
                }
            }
        }

        // 雪山迷宫(7，9) 进入【冰晶塔】等：地图图之后、怪物列表之前
        self::renderSceneEnterLinks($loc, $wjid, $a1, $cmid, $cdid, $clj, $npc);
        require_once __DIR__ . '/../../lib/FubenAlign.php';
        FubenAlign::renderHubLinks($mapDtx, $mapDty, $wjid, $a1, $cmid, $cdid, $clj, $npc);
        $__xh = __DIR__ . '/../../lib/XianhunUpgrade.php';
        if (is_file($__xh)) {
            require_once $__xh;
            if (class_exists('XianhunUpgrade', false)) {
                XianhunUpgrade::renderSceneLinks($mapDtx, $mapDty, $wjid, $a1, $cmid, $cdid, $clj, $npc);
            }
        }

        // 5. 前置 include / 怪物
        if (!empty($loc['include_before']) && !$__xsc0IncludedEarly
            && !($isVillageChiefMap && basename(str_replace('\\', '/', $loc['include_before'])) === 'xsc0.php')) {
            $inc = $loc['include_before'];
            $__incPath = '';
            if (DbIniStore::fileExists($inc)) $__incPath = $inc;
            elseif (DbIniStore::fileExists(__DIR__ . '/../' . ltrim($inc, './'))) $__incPath = __DIR__ . '/../' . ltrim($inc, './');
            if ($__incPath !== '') {
                ob_start();
                include($__incPath);
                echo self::stripAlreadyShownNpcs(ob_get_clean(), $npcs);
            }
        }

        $__gwHtml = '';
        if ($gwInclude !== '' && DbIniStore::fileExists($gwInclude)) {
            ob_start();
            include($gwInclude);
            $__gwHtml = self::formatGwMonsters(ob_get_clean());
        }
        $__aa = __DIR__ . '/../../lib/FubenAutoAtk.php';
        if (is_file($__aa)) {
            require_once $__aa;
            if (class_exists('FubenAutoAtk', false)) {
                $__gwHtml = FubenAutoAtk::emitMonsters($__gwHtml, $mapDtx, $mapDty, $wjid, $wjid, $a1, $cmid, $cdid, $clj, $npc);
            }
        }
        echo $__gwHtml;

        // 6. 其他位置 NPC
        self::renderNpcs($npcs, 'before_desc', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl);
        self::renderNpcs($npcs, 'before_exits', $wjid, $a1, $cmid, $cdid, $clj, $npc, $tpbl);

        // 7. 出口：先画「发现新区域」+ 进入XXX，再画「请选择出口」和四方向
        $discoverHtml = '';
        $otherExits = '';
        if (!empty($loc['exits']) && is_array($loc['exits'])) {
            foreach ($loc['exits'] as $key => $exit) {
                if ($exit === null || isset($inBody[$key])) continue;
                if (self::isSceneEnterExit($exit)) continue;
                if (!self::isDiscoverExit($key, $exit)) continue;
                $houseAccess = self::checkHouseRoomAccess($mapDtx, $exit, $wjid);
                if (!$houseAccess['ok']) continue;
                $check = self::checkExitAccess($exit, $playerLv);
                if (!$check['ok']) continue;
                ob_start();
                self::exitLink($key, $exit, $wjid, $a1, $cmid, $cdid, $clj, $npc);
                $discoverHtml .= ob_get_clean();
            }
        }
        if ($discoverHtml !== '') {
            echo "发现新区域<br/>";
            echo $discoverHtml;
        }

        echo "<!--SEEN-->请选择出口&nbsp;<br/>";
        if (!empty($loc['exits']) && is_array($loc['exits'])) {
            foreach ($loc['exits'] as $key => $exit) {
                if ($exit === null || isset($inBody[$key])) continue;
                if (self::isSceneEnterExit($exit)) continue;
                if (self::isDiscoverExit($key, $exit)) continue;
                $houseAccess = self::checkHouseRoomAccess($mapDtx, $exit, $wjid);
                if (!$houseAccess['ok']) {
                    $lockedLabel = self::exitLabel($key, $exit);
                    echo "<font color=gray>" . htmlspecialchars($lockedLabel, ENT_QUOTES, 'UTF-8') . "（当前住宅类型未开放）</font><br/>";
                    continue;
                }
                $check = self::checkExitAccess($exit, $playerLv);
                if (!$check['ok']) {
                    if (isset($exit['hide_locked']) && !$exit['hide_locked']) echo "<font color=gray>" . self::exitLabel($key, $exit) . "（{$check['tip']}）</font><br>";
                    continue;
                }
                if (self::isDirExit($key)) {
                    ob_start();
                    self::exitLink($key, $exit, $wjid, $a1, $cmid, $cdid, $clj, $npc);
                    $crossBuf[$key] .= ob_get_clean();
                } else {
                    ob_start();
                    self::exitLink($key, $exit, $wjid, $a1, $cmid, $cdid, $clj, $npc);
                    $otherExits .= ob_get_clean();
                }
            }
        }
        // 四个方向链接一律按“上 → 下 → 左 → 右”自上而下横排，各占一行
        foreach (array('up', 'down', 'left', 'right') as $dk) {
            if (!empty($crossBuf[$dk])) echo $crossBuf[$dk];
        }
        if ($otherExits !== '') echo $otherExits;


        // 参考：---更多操作--- / [查看地图(0)] | [快速回城]
        $cmid++; $cdid[] = $cmid; $clj[] = 750; $npc[] = 'map'; $mp = $cmid;
        $cmid++; $cdid[] = $cmid; $clj[] = 37; $npc[] = 1;
        echo "---更多操作---<br/><a href='xy.php?uid=$wjid&&cmd=$mp&&sid=$a1'>查看地图(0)</a>&nbsp;|&nbsp;<a href='xy.php?uid=$wjid&&cmd=$cmid&&sid=$a1'>快速回城</a><br/>";
        if (!empty($loc['desc']) && empty($loc['desc_after'])) {
            echo "<font color=black>{$loc['desc']}</font>" . "<br>";
        }
        if (!empty($loc['desc']) && !empty($loc['desc_after'])) {
            echo "<font color=black>{$loc['desc']}</font>" . "<br>";
        }

        // 冰晶塔：描述下方显示下一位怪物/守护者的战斗倒计时（参考服同为负数秒）
        require_once __DIR__ . '/../../lib/FubenAlign.php';
        echo FubenAlign::countdownHtml((int)$mapDtx, (int)$mapDty, (int)$wjid);

        self::$pendingNpcMarker = '';
        self::$villageChiefQuestArg = '';
        self::$isVillageChiefMap = false;
        self::$villageChiefLinkRendered = false;
    }

    private static function npcBaseName($name)
    {
        $nm = html_entity_decode(strip_tags((string)$name), ENT_QUOTES, 'UTF-8');
        $nm = preg_replace('/（.*$|\(.*$/u', '', $nm);
        return trim($nm);
    }

    /** 去掉旧 rwmap 里已经由 map_npc 画过的同名链接，以及紧挨在前面的叹号/问号。 */
    private static function stripAlreadyShownNpcs($html, $npcs)
    {
        if ($html === '' || $html === null) return $html;
        $names = array();
        foreach ((array)$npcs as $n) {
            $nm = self::npcBaseName(isset($n['name']) ? $n['name'] : '');
            if ($nm !== '') $names[$nm] = true;
        }
        if (!$names) return $html;
        $parts = array();
        foreach (array_keys($names) as $nm) $parts[] = preg_quote($nm, '/');
        $re = implode('|', $parts);
        $marker = '(?:(?:<img[^>]*(?:ts[12]\.png)[^>〉]*[>〉]\s*(?:<br\s*/?>\s*)?)|(?:<font[^>]*>\s*[！？!]\s*</font>\s*(?:<br\s*/?>\s*)?))*';
        $link = '<a\s[^>]*>\s*(?:<img[^>〉]*[>〉]\s*)?(?:<font[^>]*>\s*)?(?:' . $re . ')(?:（[^<]*）|\([^<]*\))?(?:\s*</font>)?\s*</a>\s*(?:<br\s*/?>)?';
        $out = preg_replace('/' . $marker . $link . '/iu', '', $html);
        return $out === null ? $html : $out;
    }

}
