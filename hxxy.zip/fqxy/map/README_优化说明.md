# 地图系统全面优化说明

## 已完成

- **92 张地图**全部自动转换为 data 驱动格式
- 约 **4288 个出口**，其中 **4224 个**已自动匹配目标坐标（98.5%）
- 显示引擎 `MapRenderer` + 移动引擎 `MapMover`
- 未匹配的 64 个出口多为跨地图传送，需手工补 `dtx`

## 目录结构

```
fqxy/map/
├── MapRenderer.php       # 显示渲染
├── MapMover.php          # 移动引擎
├── map_loader.php        # 加载入口
├── mapid.php             # 替换原文件
├── move_handler.php      # xy003～006 统一入口
├── map_file_map.php      # dtx→文件名映射
├── data/                 # 92 个地图数据文件
│   ├── xsc.php           # 新手村
│   ├── cac.php           # 长安城（131个点）
│   ├── hd.php            # 海底
│   ├── dhyc.php          # 东海渔村（手工按文档调整）
│   └── ...
└── ...

fqxy/template/
├── xy003.php ~ xy006.php # 新（极简）
└── xy003_old.php ~ ...   # 部署时自行备份原文件
```

## 部署步骤

```bash
# 1. 备份
cp map/mapid.php map/mapid.php.bak
cp template/xy003.php template/xy003_old.php
cp template/xy004.php template/xy004_old.php
cp template/xy005.php template/xy005_old.php
cp template/xy006.php template/xy006_old.php

# 2. 复制整个 map/ 目录新文件 + data/ 全部
# 3. 覆盖 template/xy003～006.php
```

## 注意

1. **跨地图出口**：自动转换时若目标不在本地图，不会带 `dtx`。需要的话在 data 文件里手工补：
   ```php
   'right' => ['name' => '长安城', 'dtx' => 1, 'dty' => 0],
   ```

2. **复杂地图**（如长安 cac、天宫 tg）可能有活动、NPC、图片等原文件里的特殊逻辑，自动转换只提取了名称/出口/描述/gw/rwmap。若发现缺失，可在对应 data 的地点下加：
   - `include_before`
   - `gw`
   - `npcs`
   - `before_exits` / `after`

3. **东海渔村 dhyc** 按你提供的文档布局手工维护（村长家在底部）。

4. 原 PHP 地图文件建议保留作备份，新系统失败时会自动 include 旧文件。
