# 新地图系统：如何添加图片

图片文件请放在网站可访问目录，一般用原来的：

- `pic/npc/xxx.png`  NPC 头像
- `pic/map/xxx.png`  场景图
- `pic/gz/xxx.gif`   活动/装饰图

路径相对于网站根（与旧代码 `pic/...` 一致）。

---

## 一、给某个地点加场景图

编辑对应地图数据，例如 `map/data/dhyc.php`：

```php
1 => array(
    'name' => '渔村广场',
    'desc' => '海风吹过广场……',
    // 单张图（受玩家「显示图片」开关 $tpbl 控制，与旧版一致）
    'img'  => 'pic/map/yucun_guangchang.png',
    // 或者多张：
    // 'imgs' => array('pic/map/a.png', 'pic/map/b.gif'),
    // 不关图片开关也强制显示：
    // 'img_always' => true,
    // 图片出现位置：after_name（默认）| before_desc | before_exits | after_map
    // 'img_pos' => 'after_name',
    'exits' => array(
        'up' => array('name' => '集市', 'dty' => 4),
        // ...
    ),
),
```

## 二、给 NPC 加头像

在地点的 `npcs` 里加 `img`：

```php
'npcs' => array(
    array(
        'id'   => 21,
        'name' => '张果老',
        'img'  => 'pic/npc/npc1.png',   // NPC 小图，显示在名字上方
        // 'img_always' => true,        // 可选：强制显示
        // 'pos' => 'after_name',       // 与原来 pos 一致
        // 'color' => 'blue',
        // 'cmd' => 7,
    ),
    array(
        'id'   => 20,
        'name' => '李白',
        'img'  => 'pic/npc/npc2.png',
    ),
),
```

## 三、与旧版 `$tpbl` 的关系

- 旧地图：`if ($tpbl==1) { echo <img ...> }`
- 新系统：同样尊重 `$tpbl`
  - `$tpbl == 0`：不显示（省流量）
  - `$tpbl == 1`：显示
  - 配置了 `'img_always' => true`：无视开关，始终显示

## 四、完整示例（东海渔村·村口）

```php
5 => array(
    'name'  => '村口',
    'desc'  => '东海渔村的入口。',
    'img'   => 'pic/map/yucun_kou.png',
    'exits' => array(
        'up'   => array('name' => '沙滩', 'dty' => 7),
        'down' => array('name' => '集市', 'dty' => 4),
    ),
    'npcs' => array(
        array(
            'id'   => 7,
            'name' => '船夫',
            'img'  => 'pic/npc/chuanfu.png',
            'pos'  => 'after_name',
        ),
    ),
),
```

## 五、部署

只需更新 `MapRenderer.php`（本说明同目录）。  
地图 data 按上面字段改完保存即可，无需改移动逻辑。

## 六、注意

1. 图片路径写错会裂图，请先浏览器直接打开 `http://域名/pic/...` 确认能访问。  
2. 大图注意体积，手机端宜用小图。  
3. 活动类临时图仍可用 `include_before` 引入旧脚本，与 data 图片可并存。
